import React, { useState } from "react";
import { Search, SlidersHorizontal, Heart, ShoppingBag, Tag, PackageX } from "lucide-react";
import { Product, Category, UserProfile } from "../types";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl, handleImageError } from "../utils/image";
import { stripDescriptionToText } from "../utils/descriptionCleaner";
import { StarRating } from "../components/StarRating";

interface CategoryListingViewProps {
  products: Product[];
  categories: Category[];
  selectedCategory: string | null;
  searchQuery: string;
  user: UserProfile | null;
  onNavigate: (view: string, param?: string) => void;
  onSelectCategory: (catName: string | null) => void;
  onSearchChange: (q: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  currency?: string;
  baseCurrency?: string;
}

export const CategoryListingView: React.FC<CategoryListingViewProps> = ({
  products,
  categories,
  selectedCategory,
  searchQuery,
  user,
  onNavigate,
  onSelectCategory,
  onSearchChange,
  onAddToCart,
  onToggleWishlist,
  currency = "PKR",
  baseCurrency = "PKR",
}) => {
  const [sortBy, setSortBy] = useState<"newest" | "price-low" | "price-high">("newest");

  // Filtering
  let filtered = products.filter((p) => {
    const matchesCategory = selectedCategory ? p.category.toLowerCase() === selectedCategory.toLowerCase() : true;
    const matchesSearch = searchQuery
      ? p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.category.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    return matchesCategory && matchesSearch;
  });

  // Sorting
  filtered = [...filtered].sort((a, b) => {
    const priceA = a.salePrice || a.price;
    const priceB = b.salePrice || b.price;
    if (sortBy === "price-low") return priceA - priceB;
    if (sortBy === "price-high") return priceB - priceA;
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <div className="space-y-8 pb-16">
      {/* Page Title & Search Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              {selectedCategory ? `${selectedCategory} Collection` : "All Products"}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Showing {filtered.length} items in catalog
            </p>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200">
              <SlidersHorizontal className="w-4 h-4 text-slate-400" />
              <span>Sort:</span>
              <select
                value={sortBy}
                onChange={(e: any) => setSortBy(e.target.value)}
                className="bg-transparent font-bold text-slate-900 focus:outline-none cursor-pointer"
              >
                <option value="newest">Newest Arrivals</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pt-2 pb-1 scrollbar-none">
          <button
            onClick={() => onSelectCategory(null)}
            className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              selectedCategory === null
                ? "bg-slate-900 text-white shadow-md"
                : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
          >
            All Items
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.name)}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
                selectedCategory?.toLowerCase() === cat.name.toLowerCase()
                  ? "bg-indigo-600 text-white shadow-md"
                  : "bg-slate-100 text-slate-600 hover:bg-slate-200"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Catalog Grid */}
      {filtered.length === 0 ? (
        <div className="p-16 text-center bg-white rounded-3xl border border-dashed border-slate-300 space-y-4">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
            <PackageX className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800">No Products Found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {searchQuery
                ? `No products match your search query "${searchQuery}".`
                : "There are no products listed under this filter."}
            </p>
          </div>
          {(searchQuery || selectedCategory) && (
            <button
              onClick={() => {
                onSelectCategory(null);
                onSearchChange("");
              }}
              className="px-4 py-2 text-xs font-bold bg-slate-900 text-white rounded-xl shadow hover:bg-slate-800"
            >
              Reset Filters
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
          {filtered.map((product) => {
            const isWishlisted = user?.wishlist?.includes(product.id) || false;
            const hasDiscount = product.salePrice && product.salePrice < product.price;

            return (
              <div
                key={product.id}
                className="group bg-white rounded-xl sm:rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-lg transition-all duration-200 overflow-hidden flex flex-col"
              >
                {/* Image */}
                <div className="relative aspect-square bg-slate-100 overflow-hidden">
                  <img
                    src={optimizeImageUrl(product.images?.[0])}
                    alt={product.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                    onError={handleImageError}
                  />

                  {hasDiscount && (
                    <div className="absolute top-2 left-2 sm:top-3 sm:left-3 bg-indigo-600 text-white text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 sm:px-2.5 sm:py-1 rounded-full shadow-md flex items-center gap-0.5 sm:gap-1">
                      <Tag className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                      <span>SALE</span>
                    </div>
                  )}

                  <button
                    onClick={() => onToggleWishlist(product.id)}
                    className={`absolute top-2 right-2 sm:top-3 sm:right-3 p-1.5 sm:p-2 rounded-full backdrop-blur-md shadow-md transition-colors ${
                      isWishlisted
                        ? "bg-rose-50 text-rose-600 border border-rose-200"
                        : "bg-white/80 text-slate-600 hover:text-rose-600 hover:bg-white"
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isWishlisted ? "fill-current" : ""}`} />
                  </button>
                </div>

                {/* Info */}
                <div className="p-2.5 sm:p-4 flex-1 flex flex-col justify-between space-y-2 sm:space-y-3">
                  <div>
                    <span className="text-[9px] sm:text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                      {product.category || "General"}
                    </span>
                    <button
                      onClick={() => onNavigate("product", product.id)}
                      className="block text-xs sm:text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1 text-left mt-0.5"
                    >
                      {product.title}
                    </button>
                    <p className="text-[11px] sm:text-xs text-slate-500 line-clamp-2 mt-0.5 sm:mt-1 leading-tight sm:leading-relaxed">
                      {stripDescriptionToText(product.description)}
                    </p>
                    {!!product.reviewCount && (
                      <div className="mt-1">
                        <StarRating rating={product.avgRating || 0} reviewCount={product.reviewCount} size="xs" />
                      </div>
                    )}
                  </div>

                  <div className="pt-1.5 sm:pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 sm:gap-0">
                    <div>
                      {hasDiscount ? (
                        <div className="flex items-baseline gap-1">
                          <span className="text-xs sm:text-base font-extrabold text-slate-900">
                            {formatPrice(product.salePrice, currency, baseCurrency)}
                          </span>
                          <span className="text-[10px] sm:text-xs text-slate-400 line-through">
                            {formatPrice(product.price, currency, baseCurrency)}
                          </span>
                        </div>
                      ) : (
                        <span className="text-xs sm:text-base font-extrabold text-slate-900">
                          {formatPrice(product.price, currency, baseCurrency)}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => onAddToCart(product)}
                      className="w-full sm:w-auto px-2.5 py-1 sm:px-3 sm:py-1.5 bg-slate-900 hover:bg-indigo-600 text-white text-[10px] sm:text-xs font-semibold rounded-lg sm:rounded-xl shadow transition-colors flex items-center justify-center gap-1"
                    >
                      <ShoppingBag className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                      <span>Add</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
