import type { VercelRequest, VercelResponse } from "@vercel/node";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { phone } = req.body || {};
  if (!phone || String(phone).trim().length < 7) {
    return res.status(400).json({ error: "Please enter a valid mobile phone number." });
  }

  const cleanPhone = String(phone).trim().replace(/\s+/g, "");
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

  const { error } = await supabaseAdmin.from("otp_codes").upsert({ phone: cleanPhone, code, expires_at: expiresAt });
  if (error) return res.status(500).json({ error: error.message });

  console.log(`[SMS OTP SERVICE] Verification code for ${cleanPhone}: ${code}`);

  // NOTE: no real SMS gateway wired up — code is returned here so the UI can display it for testing.
  // Wire an SMS provider before going live, and stop returning otpCode in the response.
  return res.json({ success: true, message: `OTP code dispatched to ${cleanPhone}.`, otpCode: code });
}
