import type { VercelRequest, VercelResponse } from "@vercel/node";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!);

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { phone, code } = req.body || {};
  if (!phone || !code) {
    return res.status(400).json({ verified: false, message: "Phone number and OTP code are required." });
  }

  const cleanPhone = String(phone).trim().replace(/\s+/g, "");
  const { data: record, error } = await supabaseAdmin.from("otp_codes").select("*").eq("phone", cleanPhone).maybeSingle();
  if (error) return res.status(500).json({ verified: false, message: error.message });
  if (!record) return res.status(400).json({ verified: false, message: "No OTP request found for this phone number." });

  if (new Date(record.expires_at) < new Date()) {
    await supabaseAdmin.from("otp_codes").delete().eq("phone", cleanPhone);
    return res.status(400).json({ verified: false, message: "OTP code has expired. Please request a new code." });
  }

  if (record.code !== String(code).trim()) {
    return res.status(400).json({ verified: false, message: "Invalid OTP code. Please check and try again." });
  }

  await supabaseAdmin.from("otp_codes").delete().eq("phone", cleanPhone);
  return res.json({ verified: true, message: "Phone number successfully verified!" });
}
