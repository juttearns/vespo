import React, { useState } from "react";
import { LogIn, UserPlus, ShieldCheck, AlertCircle } from "lucide-react";
import { GoogleAuthButton } from "../components/GoogleAuthButton";
import { api } from "../services/api";
import { StoreInfo, AuthState } from "../types";

interface AuthViewProps {
  storeInfo: StoreInfo;
  onAuthSuccess: (token: string, user: any) => void;
  onNavigate: (view: string) => void;
  redirectView?: string;
}

export const AuthView: React.FC<AuthViewProps> = ({ storeInfo, onAuthSuccess, onNavigate, redirectView }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      if (isSignUp) {
        const res = await api.register(email, password, name);
        onAuthSuccess(res.token, res.user);
      } else {
        const res = await api.login(email, password);
        onAuthSuccess(res.token, res.user);
      }
      onNavigate(redirectView || "home");
    } catch (err: any) {
      setError(err.message || "Authentication failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSuccess = async (googleUser: { googleId: string; email: string; name: string; avatar?: string }) => {
    setLoading(true);
    setError(null);

    try {
      const res = await api.loginGoogle(googleUser);
      onAuthSuccess(res.token, res.user);
      onNavigate(redirectView || "home");
    } catch (err: any) {
      setError(err.message || "Google authentication failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto py-12 px-4 space-y-6">
      <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xl space-y-6">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white font-black text-xl flex items-center justify-center mx-auto shadow-md">
            V
          </div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            {isSignUp ? "Create Your Vespo Account" : "Welcome Back"}
          </h1>
          <p className="text-xs text-slate-500">
            {isSignUp
              ? "Join Vespo to save delivery pins, wishlist items & order history."
              : "Sign in to access your orders, wishlist, and saved GPS address."}
          </p>
        </div>

        {error && (
          <div className="p-3 text-xs text-rose-800 bg-rose-50 rounded-xl border border-rose-200 flex items-center gap-2 font-medium">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Google OAuth Button Integration Point */}
        <div className="space-y-3">
          <GoogleAuthButton
            onSuccess={handleGoogleSuccess}
            clientId={storeInfo.googleClientId}
          />

          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink mx-3 text-[11px] text-slate-400 font-bold uppercase tracking-wider">
              Or with email
            </span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>
        </div>

        {/* Email / Password Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          {isSignUp && (
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required={isSignUp}
                placeholder="Alex Morgan"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="alex@example.com"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 mb-1">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              placeholder="••••••••"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-md transition-colors text-xs flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSignUp ? <UserPlus className="w-4 h-4" /> : <LogIn className="w-4 h-4" />}
            <span>{loading ? "Authenticating..." : isSignUp ? "Create Account" : "Sign In"}</span>
          </button>
        </form>

        {/* Toggle between Sign In & Sign Up */}
        <div className="text-center pt-2 border-t border-slate-100 text-xs text-slate-500">
          {isSignUp ? (
            <p>
              Already have an account?{" "}
              <button
                type="button"
                onClick={() => setIsSignUp(false)}
                className="font-bold text-indigo-600 hover:underline"
              >
                Sign In
              </button>
            </p>
          ) : (
            <p>
              Don't have an account yet?{" "}
              <button
                type="button"
                onClick={() => setIsSignUp(true)}
                className="font-bold text-indigo-600 hover:underline font-semibold"
              >
                Create One Now
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
