import React, { useState } from "react";
import { ShoppingBag, Heart, ArrowLeft, Shield, Truck, Tag, CheckCircle2, Maximize2, X, ChevronLeft, ChevronRight, AlertCircle } from "lucide-react";
import { Product, UserProfile } from "../types";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl, handleImageError } from "../utils/image";
import { ProductDescriptionDisplay } from "../utils/descriptionCleaner";

interface ProductDetailViewProps {
  product: Product;
  user: UserProfile | null;
  onNavigate: (view: string, param?: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onToggleWishlist: (productId: string) => void;
  currency?: string;
  baseCurrency?: string;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({
  product,
  user,
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  currency = "PKR",
  baseCurrency = "USD",
}) => {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const rawImages = product.images && product.images.length > 0
    ? product.images
    : ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=85&w=1400"];

  const images = rawImages.map((img) => optimizeImageUrl(img));

  const isWishlisted = user?.wishlist?.includes(product.id) || false;
  const hasDiscount = product.salePrice && product.salePrice < product.price;
  const currentPrice = product.salePrice || product.price;

  const handleNextImage = () => {
    setSelectedImage((prev) => (prev + 1) % images.length);
  };

  const handlePrevImage = () => {
    setSelectedImage((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleAdd = () => {
    onAddToCart(product, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2500);
  };

  const handleBuyNow = () => {
    onAddToCart(product, quantity);
    onNavigate("checkout");
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Back Button */}
      <button
        onClick={() => onNavigate("categories")}
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Catalog</span>
      </button>

      {/* Main Container */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md overflow-hidden grid grid-cols-1 lg:grid-cols-2 gap-8 p-6 sm:p-10">
        {/* Left: Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square bg-slate-100 rounded-2xl overflow-hidden border border-slate-200 group">
            <img
              src={images[selectedImage]}
              alt={product.title}
              className="w-full h-full object-cover cursor-zoom-in group-hover:scale-105 transition-transform duration-300"
              onClick={() => setLightboxOpen(true)}
              referrerPolicy="no-referrer"
              onError={handleImageError}
            />
            {hasDiscount && (
              <div className="absolute top-4 left-4 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1 z-10">
                <Tag className="w-3.5 h-3.5" />
                <span>SAVE {formatPrice(product.price - product.salePrice!, currency, baseCurrency)}</span>
              </div>
            )}

            {/* Click to Zoom Overlay Button */}
            <button
              onClick={() => setLightboxOpen(true)}
              className="absolute bottom-4 right-4 bg-slate-900/80 hover:bg-slate-900 text-white text-xs font-bold px-3 py-2 rounded-xl backdrop-blur-md shadow-lg flex items-center gap-1.5 transition-all opacity-90 hover:opacity-100"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Zoom HD</span>
            </button>

            {/* Next / Prev overlay for gallery */}
            {images.length > 1 && (
              <>
                <button
                  onClick={handlePrevImage}
                  className="absolute left-3 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-slate-800 p-2 rounded-full shadow-md backdrop-blur-md transition-all"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextImage}
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-slate-800 p-2 rounded-full shadow-md backdrop-blur-md transition-all"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            )}
          </div>

          {/* Image Thumbnails */}
          {images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-all shrink-0 ${
                    selectedImage === idx ? "border-indigo-600 ring-2 ring-indigo-500/20" : "border-slate-200 opacity-70 hover:opacity-100"
                  }`}
                >
                  <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" onError={handleImageError} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Product Details & Purchase Controls */}
        <div className="flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <span className="text-xs font-extrabold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
                {product.category || "General"}
              </span>

              <button
                onClick={() => onToggleWishlist(product.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-colors ${
                  isWishlisted
                    ? "bg-rose-50 text-rose-600 border border-rose-200"
                    : "bg-slate-100 text-slate-600 hover:text-rose-600 hover:bg-slate-200"
                }`}
              >
                <Heart className={`w-4 h-4 ${isWishlisted ? "fill-current text-rose-600" : ""}`} />
                <span>{isWishlisted ? "Saved" : "Save to Wishlist"}</span>
              </button>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
              {product.title}
            </h1>

            {/* Price Row */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-extrabold text-slate-900">
                {formatPrice(currentPrice, currency, baseCurrency)}
              </span>
              {hasDiscount && (
                <span className="text-lg text-slate-400 line-through">
                  {formatPrice(product.price, currency, baseCurrency)}
                </span>
              )}
            </div>

            {/* Stock status indicator */}
            <div className="flex items-center gap-2 text-xs font-semibold">
              {product.stock > 0 ? (
                <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>In Stock ({product.stock} units available)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-rose-700 bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>Out of Stock</span>
                </div>
              )}
            </div>

            <ProductDescriptionDisplay
              description={product.description}
              className="border-t border-b border-slate-100 py-4"
            />
          </div>

          {/* Action Box */}
          <div className="space-y-4 pt-2">
            {/* Quantity Selector */}
            <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Quantity</span>
              <div className="flex items-center bg-slate-100 rounded-xl border border-slate-200 p-1">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 flex items-center justify-center font-extrabold text-slate-700 hover:bg-white rounded-lg transition-colors"
                >
                  -
                </button>
                <span className="w-10 text-center text-sm font-bold text-slate-900">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(product.stock || 99, quantity + 1))}
                  className="w-8 h-8 flex items-center justify-center font-extrabold text-slate-700 hover:bg-white rounded-lg transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Added Notice Toast */}
            {addedNotice && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Added {quantity} x {product.title} to your cart!</span>
              </div>
            )}

            {/* Add & Buy Now Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleAdd}
                disabled={product.stock <= 0}
                className="flex-1 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold rounded-xl border border-slate-300 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart</span>
              </button>
              <button
                onClick={handleBuyNow}
                disabled={product.stock <= 0}
                className="flex-1 py-3.5 px-6 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>Buy Now</span>
              </button>
            </div>

            {/* Guarantees */}
            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-100 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-indigo-600" />
                <span>GPS Pin Verified Shipping</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-600" />
                <span>COD & Manual Bank Transfer</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Lightbox High-Resolution Full-Screen Modal */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in">
          <button
            onClick={() => setLightboxOpen(false)}
            className="absolute top-4 right-4 text-white hover:text-slate-300 p-2 rounded-full bg-slate-800/60 hover:bg-slate-800 transition-colors z-50"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="relative max-w-5xl max-h-[85vh] flex flex-col items-center justify-center space-y-4">
            <img
              src={images[selectedImage]}
              alt={product.title}
              className="max-w-full max-h-[75vh] object-contain rounded-2xl shadow-2xl border border-slate-700/50"
              referrerPolicy="no-referrer"
              onError={handleImageError}
            />

            <div className="flex items-center justify-between w-full text-white text-xs px-2">
              <span className="font-bold text-slate-300">
                {product.title} - High Resolution ({selectedImage + 1}/{images.length})
              </span>
              {images.length > 1 && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrevImage}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
