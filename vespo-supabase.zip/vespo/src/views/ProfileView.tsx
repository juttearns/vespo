import React, { useState, useEffect } from "react";
import { Package, Heart, MapPin, HelpCircle, LogOut, CheckCircle2, Clock, MessageSquare, Send, ShoppingBag } from "lucide-react";
import { UserProfile, Order, Product, Ticket, UserLocation } from "../types";
import { MapPicker } from "../components/MapPicker";
import { api } from "../services/api";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl } from "../utils/image";

interface ProfileViewProps {
  user: UserProfile;
  activeTab?: string; // 'orders' | 'wishlist' | 'address' | 'help'
  allProducts: Product[];
  onLogout: () => void;
  onNavigate: (view: string, param?: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  onUpdateUserProfile: (data: any) => Promise<any>;
  currency?: string;
  baseCurrency?: string;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  activeTab = "orders",
  allProducts,
  onLogout,
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  onUpdateUserProfile,
  currency = "PKR",
  baseCurrency = "USD",
}) => {
  const [tab, setTab] = useState<"orders" | "wishlist" | "address" | "help">(
    (activeTab as any) || "orders"
  );

  // Address sub-section state
  const [addressText, setAddressText] = useState(user.addressText || "");
  const [locationPin, setLocationPin] = useState<UserLocation>(
    user.locationPin || { lat: 37.7749, lng: -122.4194 }
  );
  const [savingAddress, setSavingAddress] = useState(false);
  const [addressSavedNotice, setAddressSavedNotice] = useState(false);

  // Orders sub-section state
  const [orders, setOrders] = useState<Order[]>([]);
  const [loadingOrders, setLoadingOrders] = useState(false);

  // Help & Support sub-section state
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loadingTickets, setLoadingTickets] = useState(false);
  const [ticketSubject, setTicketSubject] = useState("");
  const [ticketCategory, setTicketCategory] = useState("Order Status");
  const [ticketMessage, setTicketMessage] = useState("");
  const [submittingTicket, setSubmittingTicket] = useState(false);
  const [replyInputs, setReplyInputs] = useState<{ [ticketId: string]: string }>({});

  // Sync tab if activeTab prop changes
  useEffect(() => {
    if (activeTab && ["orders", "wishlist", "address", "help"].includes(activeTab)) {
      setTab(activeTab as any);
    }
  }, [activeTab]);

  // Fetch orders and tickets for current user
  useEffect(() => {
    if (user && user.id) {
      setLoadingOrders(true);
      api.getOrders(user.id)
        .then((res) => setOrders(res))
        .catch(console.error)
        .finally(() => setLoadingOrders(false));

      setLoadingTickets(true);
      api.getTickets(user.id)
        .then((res) => setTickets(res))
        .catch(console.error)
        .finally(() => setLoadingTickets(false));
    }
  }, [user]);

  // Save Address & GPS pin handler
  const handleSaveAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingAddress(true);
    try {
      await onUpdateUserProfile({
        userId: user.id,
        addressText,
        locationPin,
      });
      setAddressSavedNotice(true);
      setTimeout(() => setAddressSavedNotice(false), 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setSavingAddress(false);
    }
  };

  // Submit new ticket handler
  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketMessage.trim()) return;

    setSubmittingTicket(true);
    try {
      const newTicket = await api.createTicket({
        customerId: user.id,
        customerName: user.name,
        customerEmail: user.email,
        subject: ticketSubject.trim(),
        category: ticketCategory,
        message: ticketMessage.trim(),
      });
      setTickets([newTicket, ...tickets]);
      setTicketSubject("");
      setTicketMessage("");
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingTicket(false);
    }
  };

  // Reply to ticket from customer view
  const handleCustomerReply = async (ticketId: string) => {
    const text = replyInputs[ticketId];
    if (!text || !text.trim()) return;

    try {
      const updated = await api.replyTicket(ticketId, text.trim(), "customer", user.name);
      setTickets(tickets.map(t => t.id === ticketId ? updated : t));
      setReplyInputs({ ...replyInputs, [ticketId]: "" });
    } catch (err) {
      console.error(err);
    }
  };

  const wishlistedProducts = allProducts.filter((p) => user.wishlist?.includes(p.id));

  return (
    <div className="space-y-8 pb-16">
      {/* Profile Header */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white font-extrabold text-xl flex items-center justify-center shadow-md">
            {user.name ? user.name.charAt(0).toUpperCase() : "U"}
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              {user.name}
            </h1>
            <div className="flex flex-wrap items-center gap-2 mt-0.5 text-xs text-slate-500">
              <span>{user.email}</span>
              {user.phone && (
                <>
                  <span>•</span>
                  <span className="font-mono text-slate-700">{user.phone}</span>
                  {user.phoneVerified ? (
                    <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-100 text-emerald-800 rounded-md border border-emerald-200 inline-flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      OTP Verified
                    </span>
                  ) : (
                    <span className="text-[10px] text-amber-600 font-semibold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      Unverified Phone
                    </span>
                  )}
                </>
              )}
            </div>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="px-4 py-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-600 font-bold rounded-xl text-xs border border-slate-200 transition-colors flex items-center gap-1.5"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </button>
      </div>

      {/* Navigation Sub-section Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto border-b border-slate-200 pb-2 scrollbar-none">
        <button
          onClick={() => setTab("orders")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            tab === "orders"
              ? "bg-slate-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Package className="w-4 h-4" />
          <span>My Orders ({orders.length})</span>
        </button>

        <button
          onClick={() => setTab("wishlist")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            tab === "wishlist"
              ? "bg-slate-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Wishlist ({wishlistedProducts.length})</span>
        </button>

        <button
          onClick={() => setTab("address")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            tab === "address"
              ? "bg-slate-900 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <MapPin className="w-4 h-4" />
          <span>Address & GPS Pin</span>
        </button>

        <button
          onClick={() => setTab("help")}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 whitespace-nowrap ${
            tab === "help"
              ? "bg-indigo-600 text-white shadow-md"
              : "bg-white text-slate-600 hover:bg-slate-100 border border-slate-200"
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Help & Support ({tickets.length})</span>
        </button>
      </div>

      {/* Tab 1: Orders History */}
      {tab === "orders" && (
        <div className="space-y-4">
          <h2 className="text-lg font-extrabold text-slate-900">Order History & Tracking</h2>

          {loadingOrders ? (
            <div className="p-12 text-center text-xs text-slate-400">Loading orders...</div>
          ) : orders.length === 0 ? (
            <div className="p-12 bg-white rounded-3xl border border-dashed border-slate-300 text-center space-y-3">
              <Package className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-700">No Orders Found</p>
              <p className="text-xs text-slate-500">You haven't placed any orders with Vespo yet.</p>
              <button
                onClick={() => onNavigate("categories")}
                className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold shadow"
              >
                Browse Shop
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <div
                  key={order.id}
                  className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
                    <div>
                      <span className="font-mono text-xs font-extrabold text-slate-900">
                        {order.orderCode}
                      </span>
                      <p className="text-[11px] text-slate-400">
                        Placed on {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 text-[11px] font-bold rounded-full uppercase tracking-wider ${
                        order.status === "delivered"
                          ? "bg-emerald-100 text-emerald-800"
                          : order.status === "shipped"
                          ? "bg-indigo-100 text-indigo-800"
                          : "bg-amber-100 text-amber-800"
                      }`}>
                        {order.status}
                      </span>
                      <button
                        onClick={() => onNavigate("order-confirmation", order.id)}
                        className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-colors"
                      >
                        Track Details
                      </button>
                    </div>
                  </div>

                  {/* Order items */}
                  <div className="space-y-2 text-xs">
                    {order.items?.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center text-slate-700">
                        <span>{item.quantity}x {item.productTitle}</span>
                        <span className="font-bold text-slate-900">{formatPrice(item.quantity * item.price, currency, baseCurrency)}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-xs">
                    <span className="text-slate-500">
                      Payment: <strong className="text-slate-800 uppercase">{order.paymentMethod}</strong>
                    </span>
                    <span className="text-base font-extrabold text-slate-900">
                      Total: {formatPrice(order.totalAmount, currency, baseCurrency)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Saved Wishlist */}
      {tab === "wishlist" && (
        <div className="space-y-4">
          <h2 className="text-lg font-extrabold text-slate-900">Your Saved Wishlist</h2>

          {wishlistedProducts.length === 0 ? (
            <div className="p-12 bg-white rounded-3xl border border-dashed border-slate-300 text-center space-y-3">
              <Heart className="w-8 h-8 text-rose-400 mx-auto" />
              <p className="text-xs font-bold text-slate-700">Wishlist is Empty</p>
              <p className="text-xs text-slate-500">Tap the heart icon on any product to save it for later.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {wishlistedProducts.map((product) => (
                <div
                  key={product.id}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col justify-between space-y-3"
                >
                  <div className="relative aspect-square bg-slate-100 rounded-xl overflow-hidden">
                    <img
                      src={optimizeImageUrl(product.images?.[0])}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                    <button
                      onClick={() => onToggleWishlist(product.id)}
                      className="absolute top-2 right-2 p-1.5 bg-white/90 text-rose-600 rounded-full shadow"
                    >
                      <Heart className="w-4 h-4 fill-current" />
                    </button>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-slate-900">{product.title}</h4>
                    <span className="text-sm font-extrabold text-indigo-600">{formatPrice(product.salePrice || product.price, currency, baseCurrency)}</span>
                  </div>

                  <button
                    onClick={() => onAddToCart(product)}
                    className="w-full py-2 bg-slate-900 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Move to Cart</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Single Free-Text Address & Map Pin */}
      {tab === "address" && (
        <form onSubmit={handleSaveAddress} className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h2 className="text-base font-extrabold text-slate-900">Delivery Address & GPS Location Pin</h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Single free-text address field + device GPS pin used to cross-check delivery dispatch.
              </p>
            </div>
          </div>

          {addressSavedNotice && (
            <div className="p-3 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Delivery address and GPS map pin saved successfully!</span>
            </div>
          )}

          {/* Single Free-Text Address Field */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Full Delivery Address (Free-Text Field)
            </label>
            <textarea
              rows={3}
              value={addressText}
              onChange={(e) => setAddressText(e.target.value)}
              placeholder="Enter your complete street, house number, apartment, city, and landmark..."
              className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Map Pin Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              Exact GPS Map Location Pin
            </label>
            <MapPicker
              value={locationPin}
              onChange={(newLoc) => setLocationPin(newLoc)}
              height="h-64"
            />
          </div>

          <button
            type="submit"
            disabled={savingAddress}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition-colors disabled:opacity-50"
          >
            {savingAddress ? "Saving..." : "Save Address & Pin"}
          </button>
        </form>
      )}

      {/* Tab 4: Customer Support / Help Tickets */}
      {tab === "help" && (
        <div className="space-y-6">
          {/* New Ticket Form */}
          <form onSubmit={handleCreateTicket} className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
            <h2 className="text-base font-extrabold text-slate-900">Submit Support Ticket</h2>
            <p className="text-xs text-slate-500">
              Submitted tickets go directly to the Vespo admin support view. Admin replies will display right here!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Subject</label>
                <input
                  type="text"
                  value={ticketSubject}
                  onChange={(e) => setTicketSubject(e.target.value)}
                  required
                  placeholder="e.g. Order Delivery Status Query"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={ticketCategory}
                  onChange={(e) => setTicketCategory(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                >
                  <option value="Order Status">Order Status</option>
                  <option value="Bank Transfer Verification">Bank Transfer Verification</option>
                  <option value="Returns & Refunds">Returns & Refunds</option>
                  <option value="General Query">General Query</option>
                </select>
              </div>

              <div className="sm:col-span-2">
                <label className="block font-semibold text-slate-700 mb-1">Message Detail</label>
                <textarea
                  rows={3}
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  required
                  placeholder="Describe your issue or question..."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={submittingTicket}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow transition-colors disabled:opacity-50"
            >
              {submittingTicket ? "Submitting..." : "Submit Ticket"}
            </button>
          </form>

          {/* Submitted Tickets & Admin Reply Threads */}
          <div className="space-y-4">
            <h3 className="text-base font-extrabold text-slate-900">Your Support Ticket History</h3>

            {loadingTickets ? (
              <div className="p-8 text-center text-xs text-slate-400">Loading support tickets...</div>
            ) : tickets.length === 0 ? (
              <div className="p-8 bg-white rounded-3xl border border-dashed border-slate-300 text-center text-xs text-slate-500">
                No support tickets submitted yet.
              </div>
            ) : (
              tickets.map((tkt) => (
                <div key={tkt.id} className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div>
                      <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">{tkt.category}</span>
                      <h4 className="text-sm font-bold text-slate-900">{tkt.subject}</h4>
                    </div>

                    <span className={`px-2.5 py-1 text-[10px] font-bold rounded-full ${
                      tkt.status === "replied"
                        ? "bg-emerald-100 text-emerald-800"
                        : tkt.status === "open"
                        ? "bg-amber-100 text-amber-800"
                        : "bg-slate-100 text-slate-600"
                    }`}>
                      {tkt.status === "replied" ? "Admin Replied" : tkt.status}
                    </span>
                  </div>

                  {/* Messages Thread */}
                  <div className="space-y-3 pl-2 border-l-2 border-slate-200">
                    {tkt.messages?.map((msg) => (
                      <div key={msg.id} className="text-xs space-y-1">
                        <div className="flex items-center gap-2">
                          <span className={`font-bold ${msg.senderRole === "admin" ? "text-indigo-600" : "text-slate-900"}`}>
                            {msg.senderName} ({msg.senderRole === "admin" ? "Support Admin" : "You"})
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {new Date(msg.timestamp).toLocaleString()}
                          </span>
                        </div>
                        <p className="p-3 bg-slate-50 rounded-xl text-slate-700 leading-relaxed">
                          {msg.message}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Reply Input */}
                  <div className="pt-2 flex gap-2">
                    <input
                      type="text"
                      placeholder="Type a response to support..."
                      value={replyInputs[tkt.id] || ""}
                      onChange={(e) => setReplyInputs({ ...replyInputs, [tkt.id]: e.target.value })}
                      className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button
                      onClick={() => handleCustomerReply(tkt.id)}
                      className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Send</span>
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};
