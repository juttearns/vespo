export interface CurrencyInfo {
  code: string;
  symbol: string;
  name: string;
  rateFromUSD: number; // Exchange rate relative to 1 USD base
}

export const CURRENCIES: Record<string, CurrencyInfo> = {
  USD: { code: "USD", symbol: "$", name: "US Dollar", rateFromUSD: 1.0 },
  PKR: { code: "PKR", symbol: "Rs. ", name: "Pakistani Rupee", rateFromUSD: 278.5 },
  EUR: { code: "EUR", symbol: "€", name: "Euro", rateFromUSD: 0.92 },
  GBP: { code: "GBP", symbol: "£", name: "British Pound", rateFromUSD: 0.78 },
  INR: { code: "INR", symbol: "₹", name: "Indian Rupee", rateFromUSD: 83.5 },
  AED: { code: "AED", symbol: "AED ", name: "UAE Dirham", rateFromUSD: 3.67 },
  SAR: { code: "SAR", symbol: "SAR ", name: "Saudi Riyal", rateFromUSD: 3.75 },
  CAD: { code: "CAD", symbol: "C$", name: "Canadian Dollar", rateFromUSD: 1.36 },
  AUD: { code: "AUD", symbol: "A$", name: "Australian Dollar", rateFromUSD: 1.52 },
};

export const COUNTRY_TO_CURRENCY: Record<string, string> = {
  PK: "PKR",
  US: "USD",
  GB: "GBP",
  IN: "INR",
  AE: "AED",
  SA: "SAR",
  CA: "CAD",
  AU: "AUD",
  DE: "EUR",
  FR: "EUR",
  ES: "EUR",
  IT: "EUR",
  NL: "EUR",
  BE: "EUR",
  AT: "EUR",
};

/**
 * Converts a numerical price from a source base currency to a target currency.
 * Default base currency for prices stored in DB is USD.
 */
export function convertPrice(
  amount: number | undefined | null,
  toCurrency: string = "USD",
  fromCurrency: string = "USD"
): number {
  if (amount === undefined || amount === null || isNaN(amount)) return 0;
  const fromRate = CURRENCIES[fromCurrency]?.rateFromUSD || 1;
  const toRate = CURRENCIES[toCurrency]?.rateFromUSD || 1;
  const amountInUSD = amount / fromRate;
  return amountInUSD * toRate;
}

/**
 * Formats a price into the target currency representation with proper exchange conversion.
 */
export function formatPrice(
  amount: number | undefined | null,
  currencyCode: string = "USD",
  fromCurrency: string = "USD"
): string {
  if (amount === undefined || amount === null || isNaN(amount)) {
    amount = 0;
  }
  const curr = CURRENCIES[currencyCode] || CURRENCIES.USD;
  const converted = convertPrice(amount, currencyCode, fromCurrency);

  return `${curr.symbol}${converted.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export async function detectUserCurrency(): Promise<{ country: string; countryName: string; currency: string }> {
  try {
    const res = await fetch("https://ipapi.co/json/").catch(() => null);
    if (res && res.ok) {
      const data = await res.json();
      const countryCode = data.country_code || data.country;
      const currencyCode = data.currency || COUNTRY_TO_CURRENCY[countryCode];
      if (currencyCode && CURRENCIES[currencyCode]) {
        return {
          country: countryCode || "PK",
          countryName: data.country_name || "Pakistan",
          currency: currencyCode,
        };
      }
    }
  } catch (err) {
    console.warn("Geolocation fetch failed, defaulting to PKR:", err);
  }

  return {
    country: "PK",
    countryName: "Pakistan",
    currency: "PKR",
  };
}

