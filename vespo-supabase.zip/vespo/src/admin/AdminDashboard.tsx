import React, { useEffect, useState } from "react";
import { DollarSign, ShoppingBag, Clock, MessageSquare, AlertTriangle, ArrowUpRight, Sparkles } from "lucide-react";
import { api } from "../services/api";
import { Order, Product, Ticket } from "../types";
import { formatPrice } from "../utils/currency";

interface AdminDashboardProps {
  onNavigateTab: (tab: string) => void;
  currency?: string;
  baseCurrency?: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  onNavigateTab,
  currency = "PKR",
  baseCurrency = "USD",
}) => {
  const [stats, setStats] = useState<any>(null);
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [lowStockList, setLowStockList] = useState<Product[]>([]);
  const [openTicketsList, setOpenTicketsList] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api.getAdminStats(),
      api.getOrders(),
      api.getProducts(),
      api.getTickets(),
    ]).then(([statsRes, ordersRes, productsRes, ticketsRes]) => {
      setStats(statsRes);
      setRecentOrders(ordersRes.slice(0, 5));
      setLowStockList(productsRes.filter(p => (p.stock || 0) <= 5));
      setOpenTicketsList(ticketsRes.filter(t => t.status === "open"));
      setLoading(false);
    }).catch(console.error);
  }, []);

  if (loading) {
    return <div className="p-8 text-center text-xs text-slate-400">Loading admin dashboard analytics...</div>;
  }

  return (
    <div className="space-y-8 pb-12">
      {/* Top Welcome Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 text-white p-6 sm:p-8 rounded-3xl shadow-lg">
        <div>
          <span className="text-xs font-bold text-indigo-400 uppercase tracking-wider">Store Administration</span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight mt-1">
            Vespo Overview & Control Center
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Monitor real-time sales, order fulfillments, low stock alerts & customer tickets.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab("products")}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow transition-colors"
          >
            + Add New Product
          </button>
        </div>
      </div>

      {/* Metrics Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Total Revenue</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">
            {formatPrice(stats?.totalRevenue || 0, currency, baseCurrency)}
          </div>
          <p className="text-[11px] text-slate-400">Excludes cancelled orders</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Total Orders</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">
            {stats?.totalOrders || 0}
          </div>
          <p className="text-[11px] text-indigo-600 font-semibold">{stats?.pendingOrders || 0} pending dispatch</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Open Tickets</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <MessageSquare className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">
            {stats?.openTickets || 0}
          </div>
          <p className="text-[11px] text-amber-600 font-semibold">Requires support reply</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Low Stock Items</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">
            {stats?.lowStockProducts || 0}
          </div>
          <p className="text-[11px] text-rose-600 font-semibold">Stock &le; 5 units</p>
        </div>
      </div>

      {/* Grid Row: Recent Orders & Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Recent Orders */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-extrabold text-slate-900">Recent Customer Orders</h3>
            <button
              onClick={() => onNavigateTab("orders")}
              className="text-xs font-semibold text-indigo-600 hover:underline flex items-center gap-1"
            >
              <span>Manage All ({stats?.totalOrders})</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentOrders.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-2xl">
              No orders placed yet. Orders will appear here live when submitted at storefront checkout.
            </div>
          ) : (
            <div className="divide-y divide-slate-100 text-xs">
              {recentOrders.map((ord) => (
                <div key={ord.id} className="py-3 flex items-center justify-between gap-4">
                  <div>
                    <span className="font-mono font-bold text-slate-900">{ord.orderCode}</span>
                    <p className="text-slate-500">{ord.customerName} &bull; {ord.paymentMethod.toUpperCase()}</p>
                  </div>
                  <div className="text-right">
                    <span className="font-extrabold text-slate-900">{formatPrice(ord.totalAmount, currency, baseCurrency)}</span>
                    <div className="mt-0.5">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                        ord.status === "delivered" ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                      }`}>
                        {ord.status}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right: Low Stock & Open Tickets Notifications */}
        <div className="space-y-6">
          {/* Low Stock Widget */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>Low Stock Warning</span>
            </h3>

            {lowStockList.length === 0 ? (
              <p className="text-xs text-slate-500">All inventory levels are healthy.</p>
            ) : (
              <div className="space-y-2 text-xs">
                {lowStockList.slice(0, 4).map((item) => (
                  <div key={item.id} className="flex justify-between items-center p-2 bg-rose-50 rounded-xl text-rose-900 border border-rose-100 font-medium">
                    <span className="truncate pr-2">{item.title}</span>
                    <span className="font-bold shrink-0">{item.stock} left</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Open Tickets Widget */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
            <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-amber-600" />
              <span>Unanswered Help Tickets</span>
            </h3>

            {openTicketsList.length === 0 ? (
              <p className="text-xs text-slate-500">No pending customer tickets.</p>
            ) : (
              <div className="space-y-2 text-xs">
                {openTicketsList.slice(0, 4).map((tkt) => (
                  <button
                    key={tkt.id}
                    onClick={() => onNavigateTab("tickets")}
                    className="w-full text-left p-2.5 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors"
                  >
                    <span className="font-bold text-slate-900 block truncate">{tkt.subject}</span>
                    <span className="text-[11px] text-slate-500">{tkt.customerName} &bull; {tkt.category}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
