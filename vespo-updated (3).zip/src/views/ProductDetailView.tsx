import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShoppingBag, Heart, ArrowLeft, Shield, Truck, Tag, CheckCircle2, Maximize2, X, ChevronLeft, ChevronRight, AlertCircle, Users, MessageSquareText } from "lucide-react";
import { Product, UserProfile, Review } from "../types";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl, handleImageError } from "../utils/image";
import { ProductDescriptionDisplay } from "../utils/descriptionCleaner";
import { StarRating, StarRatingInput } from "../components/StarRating";
import { api } from "../services/api";

interface ProductDetailViewProps {
  product: Product;
  user: UserProfile | null;
  onNavigate: (view: string, param?: string) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  onToggleWishlist: (productId: string) => void;
  currency?: string;
  baseCurrency?: string;
}

export const ProductDetailView: React.FC<ProductDetailViewProps> = ({
  product,
  user,
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  currency = "PKR",
  baseCurrency = "PKR",
}) => {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  const [reviews, setReviews] = useState<Review[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setReviewsLoading(true);
    api
      .getProductReviews(product.id)
      .then((r) => {
        if (!cancelled) setReviews(r);
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setReviewsLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [product.id]);

  const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0;

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!reviewComment.trim()) {
      setReviewError("Please write a short comment.");
      return;
    }
    setSubmittingReview(true);
    setReviewError("");
    try {
      const created = await api.createReview({
        productId: product.id,
        customerId: user.id,
        customerName: user.name || "Customer",
        rating: reviewRating,
        comment: reviewComment.trim(),
      });
      setReviews((prev) => [created, ...prev]);
      setReviewComment("");
      setReviewRating(5);
    } catch (err: any) {
      setReviewError(err.message || "Failed to submit review");
    } finally {
      setSubmittingReview(false);
    }
  };

  const rawImages = product.images && product.images.length > 0
    ? product.images
    : ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=85&w=1400"];

  const images = rawImages.map((img) => optimizeImageUrl(img));

  const isWishlisted = user?.wishlist?.includes(product.id) || false;
  const hasDiscount = product.salePrice && product.salePrice < product.price;
  const currentPrice = product.salePrice || product.price;

  const handleNextImage = () => {
    setSelectedImage((prev) => (prev + 1) % images.length);
  };

  const handlePrevImage = () => {
    setSelectedImage((prev) => (prev - 1 + images.length) % images.length);
  };

  const handleAdd = () => {
    onAddToCart(product, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2500);
  };

  const handleBuyNow = () => {
    onAddToCart(product, quantity);
    onNavigate("checkout");
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Back Button */}
      <button
        onClick={() => onNavigate("categories")}
        className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Catalog</span>
      </button>

      {/* Main Container */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md overflow-hidden grid grid-cols-1 lg:grid-cols-2 gap-8 p-6 sm:p-10">
        {/* Left: Image Gallery */}
        <div className="space-y-4">
          <div className="relative aspect-square bg-slate-100 rounded-2xl overflow-hidden border border-slate-200 group">
            <AnimatePresence mode="wait">
              <motion.img
                key={selectedImage}
                src={images[selectedImage]}
                alt={product.title}
                initial={{ opacity: 0, scale: 1.02 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.25, ease: "easeOut" }}
                className="w-full h-full object-cover cursor-zoom-in"
                onClick={() => setLightboxOpen(true)}
                referrerPolicy="no-referrer"
                onError={handleImageError}
              />
            </AnimatePresence>
            {hasDiscount && (
              <div className="absolute top-4 left-4 bg-indigo-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1 z-10">
                <Tag className="w-3.5 h-3.5" />
                <span>SAVE {formatPrice(product.price - product.salePrice!, currency, baseCurrency)}</span>
              </div>
            )}

            {/* Click to Zoom Overlay Button */}
            <button
              onClick={() => setLightboxOpen(true)}
              className="absolute bottom-4 right-4 bg-slate-900/80 hover:bg-slate-900 text-white text-xs font-bold px-3 py-2 rounded-xl backdrop-blur-md shadow-lg flex items-center gap-1.5 transition-all opacity-90 hover:opacity-100 z-10"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Zoom HD</span>
            </button>

            {/* Next / Prev overlay for gallery */}
            {images.length > 1 && (
              <>
                <button
                  onClick={handlePrevImage}
                  className="absolute left-3 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-slate-800 p-2 rounded-full shadow-md backdrop-blur-md transition-all z-10"
                  aria-label="Previous image"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextImage}
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-slate-800 p-2 rounded-full shadow-md backdrop-blur-md transition-all z-10"
                  aria-label="Next image"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            )}
          </div>

          {/* Image Thumbnails */}
          {images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto pb-1">
              {images.map((img, idx) => (
                <motion.button
                  key={idx}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedImage(idx)}
                  className={`w-20 h-20 rounded-xl overflow-hidden border-2 transition-colors shrink-0 ${
                    selectedImage === idx ? "border-indigo-600 ring-2 ring-indigo-500/20" : "border-slate-200 opacity-70 hover:opacity-100"
                  }`}
                >
                  <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" referrerPolicy="no-referrer" onError={handleImageError} />
                </motion.button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Product Details & Purchase Controls */}
        <div className="flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <span className="text-xs font-extrabold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
                {product.category || "General"}
              </span>

              <motion.button
                whileTap={{ scale: 0.93 }}
                onClick={() => onToggleWishlist(product.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-colors ${
                  isWishlisted
                    ? "bg-rose-50 text-rose-600 border border-rose-200"
                    : "bg-slate-100 text-slate-600 hover:text-rose-600 hover:bg-slate-200"
                }`}
              >
                <motion.span
                  key={isWishlisted ? "on" : "off"}
                  initial={{ scale: 0.6 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 500, damping: 12 }}
                  className="block"
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? "fill-current text-rose-600" : ""}`} />
                </motion.span>
                <span>{isWishlisted ? "Saved" : "Save to Wishlist"}</span>
              </motion.button>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
              {product.title}
            </h1>

            {/* Rating & Social Proof Row */}
            {(reviews.length > 0 || (product.orderCount || 0) > 0) && (
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
                {reviews.length > 0 && (
                  <StarRating rating={avgRating} reviewCount={reviews.length} size="sm" />
                )}
                {(product.orderCount || 0) > 0 && (
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
                    <Users className="w-3.5 h-3.5 text-slate-400" />
                    <span>{product.orderCount} people ordered this</span>
                  </div>
                )}
              </div>
            )}

            {/* Price Row */}
            <div className="flex items-baseline gap-3">
              <span className="text-3xl font-extrabold text-slate-900">
                {formatPrice(currentPrice, currency, baseCurrency)}
              </span>
              {hasDiscount && (
                <span className="text-lg text-slate-400 line-through">
                  {formatPrice(product.price, currency, baseCurrency)}
                </span>
              )}
            </div>

            {/* Stock status indicator */}
            <div className="flex items-center gap-2 text-xs font-semibold">
              {product.stock > 0 ? (
                <div className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>In Stock ({product.stock} units available)</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-rose-700 bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>Out of Stock</span>
                </div>
              )}
            </div>

            <ProductDescriptionDisplay
              description={product.description}
              className="border-t border-b border-slate-100 py-4"
            />
          </div>

          {/* Action Box */}
          <div className="space-y-4 pt-2">
            {/* Quantity Selector */}
            <div className="flex items-center gap-4">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Quantity</span>
              <div className="flex items-center bg-slate-100 rounded-xl border border-slate-200 p-1">
                <button
                  type="button"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-8 h-8 flex items-center justify-center font-extrabold text-slate-700 hover:bg-white rounded-lg transition-colors"
                >
                  -
                </button>
                <span className="w-10 text-center text-sm font-bold text-slate-900">{quantity}</span>
                <button
                  type="button"
                  onClick={() => setQuantity(Math.min(product.stock || 99, quantity + 1))}
                  className="w-8 h-8 flex items-center justify-center font-extrabold text-slate-700 hover:bg-white rounded-lg transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            {/* Added Notice Toast */}
            <AnimatePresence>
              {addedNotice && (
                <motion.div
                  initial={{ opacity: 0, y: -8, height: 0 }}
                  animate={{ opacity: 1, y: 0, height: "auto" }}
                  exit={{ opacity: 0, y: -8, height: 0 }}
                  transition={{ duration: 0.25, ease: "easeOut" }}
                  className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center gap-2 overflow-hidden"
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Added {quantity} x {product.title} to your cart!</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Add & Buy Now Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={handleAdd}
                disabled={product.stock <= 0}
                className="flex-1 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold rounded-xl border border-slate-300 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Cart</span>
              </motion.button>
              <motion.button
                whileTap={{ scale: 0.97 }}
                onClick={handleBuyNow}
                disabled={product.stock <= 0}
                className="flex-1 py-3.5 px-6 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <span>Buy Now</span>
              </motion.button>
            </div>

            {/* Guarantees */}
            <div className="grid grid-cols-2 gap-3 pt-4 border-t border-slate-100 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-indigo-600" />
                <span>GPS Pin Verified Shipping</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-indigo-600" />
                <span>COD & Manual Bank Transfer</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-md p-6 sm:p-10 space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2">
            <MessageSquareText className="w-5 h-5 text-indigo-600" />
            <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
              Customer Reviews
            </h2>
          </div>
          {reviews.length > 0 && <StarRating rating={avgRating} reviewCount={reviews.length} size="md" />}
        </div>

        {/* Leave a Review */}
        {user ? (
          <form onSubmit={handleSubmitReview} className="bg-slate-50 rounded-2xl border border-slate-200 p-4 sm:p-5 space-y-3">
            <p className="text-xs font-bold text-slate-700 uppercase tracking-wider">Write a Review</p>
            <StarRatingInput value={reviewRating} onChange={setReviewRating} />
            <textarea
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
              placeholder="Share your experience with this product..."
              rows={3}
              className="w-full text-sm rounded-xl border border-slate-200 p-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/40"
            />
            {reviewError && <p className="text-xs font-semibold text-rose-600">{reviewError}</p>}
            <button
              type="submit"
              disabled={submittingReview}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow transition-colors disabled:opacity-50"
            >
              {submittingReview ? "Submitting..." : "Submit Review"}
            </button>
          </form>
        ) : (
          <div className="bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-4 text-xs text-slate-500 text-center">
            <button onClick={() => onNavigate("auth")} className="font-bold text-indigo-600 hover:underline">
              Sign in
            </button>{" "}
            to leave a review.
          </div>
        )}

        {/* Review List */}
        {reviewsLoading ? (
          <p className="text-xs text-slate-400">Loading reviews...</p>
        ) : reviews.length === 0 ? (
          <p className="text-xs text-slate-400">No reviews yet. Be the first to review this product!</p>
        ) : (
          <div className="space-y-4">
            {reviews.map((rev) => (
              <div key={rev.id} className="border-t border-slate-100 pt-4 first:border-t-0 first:pt-0">
                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <span className="text-sm font-bold text-slate-900">{rev.customerName}</span>
                  <span className="text-[11px] text-slate-400">
                    {new Date(rev.createdAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}
                  </span>
                </div>
                <StarRating rating={rev.rating} reviewCount={1} showCount={false} size="xs" />
                <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">{rev.comment}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Lightbox High-Resolution Full-Screen Modal */}
      {lightboxOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 sm:p-8 animate-in fade-in">
          <button
            onClick={() => setLightboxOpen(false)}
            className="absolute top-4 right-4 text-white hover:text-slate-300 p-2 rounded-full bg-slate-800/60 hover:bg-slate-800 transition-colors z-50"
          >
            <X className="w-6 h-6" />
          </button>

          <div className="relative max-w-5xl max-h-[85vh] flex flex-col items-center justify-center space-y-4">
            <img
              src={images[selectedImage]}
              alt={product.title}
              className="max-w-full max-h-[75vh] object-contain rounded-2xl shadow-2xl border border-slate-700/50"
              referrerPolicy="no-referrer"
              onError={handleImageError}
            />

            <div className="flex items-center justify-between w-full text-white text-xs px-2">
              <span className="font-bold text-slate-300">
                {product.title} - High Resolution ({selectedImage + 1}/{images.length})
              </span>
              {images.length > 1 && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrevImage}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
