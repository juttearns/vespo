// Fetches one or more product page URLs server-side and extracts structured
// product info from Open Graph tags, Twitter meta tags, and JSON-LD
// (schema.org Product) data. Runs server-side to avoid browser CORS limits.

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

function decodeEntities(str: string): string {
  if (!str) return str;
  return str
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .trim();
}

function metaRegex(prop: string): RegExp {
  return new RegExp(
    `<meta[^>]+(?:property|name)=["']${prop}["'][^>]+content=["']([^"']*)["']`,
    "i"
  );
}

function getMeta(html: string, props: string[]): string | null {
  for (const prop of props) {
    const m = html.match(metaRegex(prop));
    if (m && m[1]) return decodeEntities(m[1]);
  }
  return null;
}

function extractAllMeta(html: string, prop: string): string[] {
  const results: string[] = [];
  const re = new RegExp(`<meta[^>]+(?:property|name)=["']${prop}["'][^>]+content=["']([^"']*)["']`, "gi");
  let m;
  while ((m = re.exec(html)) !== null) {
    if (m[1]) results.push(decodeEntities(m[1]));
  }
  return results;
}

function extractJsonLdProduct(html: string): any | null {
  const scriptRe = /<script[^>]+type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = scriptRe.exec(html)) !== null) {
    try {
      const json = JSON.parse(m[1].trim());
      const candidates: any[] = Array.isArray(json) ? json : json["@graph"] ? json["@graph"] : [json];
      for (const c of candidates) {
        const type = c?.["@type"];
        const types = Array.isArray(type) ? type : [type];
        if (types.includes("Product")) return c;
      }
    } catch {
      // not valid/parseable JSON-LD block, skip it
      continue;
    }
  }
  return null;
}

function resolveUrl(src: string, base: string): string {
  try {
    return new URL(src, base).toString();
  } catch {
    return src;
  }
}

async function scrapeUrl(url: string) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 15000);
  let res: Response;
  try {
    res = await fetch(url, {
      signal: controller.signal,
      redirect: "follow",
      headers: {
        "User-Agent": UA,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
    });
  } finally {
    clearTimeout(timeout);
  }

  if (!res.ok) {
    throw new Error(`The page returned status ${res.status}. It may block automated requests.`);
  }

  const contentType = res.headers.get("content-type") || "";
  if (!contentType.includes("text/html") && !contentType.includes("xml")) {
    throw new Error("That URL did not return a webpage (HTML).");
  }

  const html = await res.text();
  const jsonLd = extractJsonLdProduct(html);

  const titleTagMatch = html.match(/<title[^>]*>([^<]*)<\/title>/i);
  const title =
    (jsonLd && jsonLd.name) ||
    getMeta(html, ["og:title", "twitter:title"]) ||
    (titleTagMatch ? decodeEntities(titleTagMatch[1]) : null);

  const description =
    (jsonLd && jsonLd.description) ||
    getMeta(html, ["og:description", "description", "twitter:description"]);

  let images: string[] = [];
  if (jsonLd && jsonLd.image) {
    images = Array.isArray(jsonLd.image) ? jsonLd.image : [jsonLd.image];
  }
  images = [...images, ...extractAllMeta(html, "og:image")];
  const twImage = getMeta(html, ["twitter:image", "twitter:image:src"]);
  if (twImage) images.push(twImage);
  images = Array.from(new Set(images.filter(Boolean).map((src: string) => resolveUrl(src, url))));

  let price: number | null = null;
  let currency: string | null = null;
  if (jsonLd && jsonLd.offers) {
    const offer = Array.isArray(jsonLd.offers) ? jsonLd.offers[0] : jsonLd.offers;
    if (offer) {
      if (offer.price) price = parseFloat(String(offer.price).replace(/[^0-9.]/g, ""));
      if (offer.priceCurrency) currency = String(offer.priceCurrency);
    }
  }
  if (price === null) {
    const metaPrice = getMeta(html, ["product:price:amount", "og:price:amount", "twitter:data1"]);
    if (metaPrice) {
      const parsed = parseFloat(metaPrice.replace(/[^0-9.]/g, ""));
      if (!isNaN(parsed)) price = parsed;
    }
  }
  if (currency === null) {
    currency = getMeta(html, ["product:price:currency", "og:price:currency"]);
  }

  let category: string | null = null;
  if (jsonLd && jsonLd.category) category = String(jsonLd.category);
  if (!category) category = getMeta(html, ["product:category"]);

  const siteName = getMeta(html, ["og:site_name"]);

  return {
    sourceUrl: url,
    siteName,
    title: title || null,
    description: description || null,
    images,
    price,
    currency,
    category,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS_HEADERS });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: CORS_HEADERS });
  }

  const body = await req.json().catch(() => ({}));
  const rawUrls: string[] = Array.isArray(body.urls) ? body.urls : body.url ? [body.url] : [];
  const urls = Array.from(new Set(rawUrls.map((u: string) => String(u || "").trim()).filter(Boolean))).slice(0, 20);

  if (urls.length === 0) {
    return new Response(JSON.stringify({ error: "Provide at least one product URL." }), {
      status: 400,
      headers: CORS_HEADERS,
    });
  }

  const results = await Promise.all(
    urls.map(async (url) => {
      let parsed: URL;
      try {
        parsed = new URL(url);
      } catch {
        return { url, success: false, error: "Invalid URL." };
      }
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
        return { url, success: false, error: "Only http:// or https:// URLs are supported." };
      }
      try {
        const data = await scrapeUrl(url);
        return { url, success: true, data };
      } catch (e) {
        return { url, success: false, error: String((e as Error)?.message || e) };
      }
    })
  );

  return new Response(JSON.stringify({ success: true, results }), {
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
});
