-- ============================================================
-- VESPO — Supabase schema
-- Run this whole file once in Supabase SQL Editor (Project > SQL Editor > New query)
-- ============================================================

create extension if not exists "pgcrypto";

-- ------------------------------------------------------------
-- PROFILES (extends Supabase Auth users)
-- ------------------------------------------------------------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  name text not null default '',
  role text not null default 'customer' check (role in ('customer','admin')),
  phone text,
  phone_verified boolean not null default false,
  address_text text not null default '',
  location_lat double precision,
  location_lng double precision,
  wishlist uuid[] not null default '{}',
  avatar text,
  created_at timestamptz not null default now()
);

-- auto-create a profile row whenever someone signs up via Supabase Auth
create function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', split_part(new.email,'@',1)));
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- helper: is the current user an admin? (security definer avoids RLS recursion)
create function public.is_admin()
returns boolean as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and role = 'admin'
  );
$$ language sql security definer stable;

-- ------------------------------------------------------------
-- CATEGORIES
-- ------------------------------------------------------------
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique
);

-- ------------------------------------------------------------
-- PRODUCTS
-- ------------------------------------------------------------
create table public.products (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  price numeric not null default 0,
  sale_price numeric,
  category text not null default 'General',
  images text[] not null default '{}',
  stock int not null default 10,
  is_featured boolean not null default false,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- DISCOUNT CODES
-- ------------------------------------------------------------
create table public.discount_codes (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('percentage','fixed')),
  value numeric not null default 0,
  min_purchase numeric not null default 0,
  expiry_date date,
  usage_limit int,
  times_used int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- ORDERS
-- ------------------------------------------------------------
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_code text not null unique,
  customer_id uuid references public.profiles(id),
  customer_name text not null,
  customer_email text not null,
  customer_phone text,
  customer_phone_verified boolean default false,
  items jsonb not null default '[]',
  subtotal numeric not null default 0,
  delivery_fee numeric not null default 0,
  discount_code text,
  discount_amount numeric not null default 0,
  cod_charge numeric not null default 0,
  total_amount numeric not null default 0,
  payment_method text not null check (payment_method in ('cod','bank_transfer','jazzcash','easypaisa')),
  payment_details jsonb,
  bank_transaction_id text,
  payment_confirmed boolean not null default false,
  shipping_address_text text not null default '',
  shipping_lat double precision,
  shipping_lng double precision,
  gps_check jsonb,
  status text not null default 'pending' check (status in ('pending','processing','shipped','delivered','cancelled')),
  email_receipt_sent boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- SUPPORT TICKETS
-- ------------------------------------------------------------
create table public.tickets (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references public.profiles(id),
  customer_name text not null,
  customer_email text not null,
  subject text not null,
  category text not null default 'General',
  status text not null default 'open' check (status in ('open','replied','closed')),
  messages jsonb not null default '[]',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ------------------------------------------------------------
-- STORE INFO / POLICIES (singleton rows)
-- ------------------------------------------------------------
create table public.store_info (
  id int primary key default 1,
  store_name text not null default 'Vespo',
  tagline text not null default '',
  banner_title text not null default '',
  banner_subtitle text not null default '',
  hero_image_url text not null default '',
  delivery_fee numeric not null default 5,
  cod_fee numeric not null default 3.5,
  bank_name text default '',
  account_name text default '',
  account_number text default '',
  iban_routing text default '',
  jazzcash_title text,
  jazzcash_number text,
  easypaisa_title text,
  easypaisa_number text,
  support_email text default '',
  support_phone text default '',
  google_client_id text default '',
  base_currency text default 'PKR',
  constraint singleton check (id = 1)
);
insert into public.store_info (id) values (1);

create table public.policies (
  id int primary key default 1,
  privacy_policy text default '',
  shipping_policy text default '',
  return_policy text default '',
  terms_of_service text default '',
  updated_at timestamptz not null default now(),
  constraint singleton check (id = 1)
);
insert into public.policies (id) values (1);

-- ------------------------------------------------------------
-- OTP CODES (phone verification — server-only access)
-- ------------------------------------------------------------
create table public.otp_codes (
  phone text primary key,
  code text not null,
  expires_at timestamptz not null
);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.discount_codes enable row level security;
alter table public.orders enable row level security;
alter table public.tickets enable row level security;
alter table public.store_info enable row level security;
alter table public.policies enable row level security;
alter table public.otp_codes enable row level security; -- no policies = only service_role can touch it

-- PROFILES: read own row or admin reads all; update own row (role is protected below)
create policy "profiles_select" on public.profiles
  for select using (auth.uid() = id or public.is_admin());

create policy "profiles_update_own" on public.profiles
  for update using (auth.uid() = id);

-- prevent a customer from promoting themselves to admin
create function public.protect_role_column()
returns trigger as $$
begin
  if new.role <> old.role and not public.is_admin() then
    new.role := old.role;
  end if;
  return new;
end;
$$ language plpgsql security definer;

create trigger protect_profile_role
  before update on public.profiles
  for each row execute procedure public.protect_role_column();

-- CATEGORIES: public read, admin write
create policy "categories_select" on public.categories for select using (true);
create policy "categories_write" on public.categories for insert with check (public.is_admin());
create policy "categories_update" on public.categories for update using (public.is_admin());
create policy "categories_delete" on public.categories for delete using (public.is_admin());

-- PRODUCTS: public read, admin write
create policy "products_select" on public.products for select using (true);
create policy "products_write" on public.products for insert with check (public.is_admin());
create policy "products_update" on public.products for update using (public.is_admin());
create policy "products_delete" on public.products for delete using (public.is_admin());

-- DISCOUNT CODES: public read (needed to validate codes at checkout), admin write
create policy "discounts_select" on public.discount_codes for select using (true);
create policy "discounts_write" on public.discount_codes for insert with check (public.is_admin());
create policy "discounts_update" on public.discount_codes for update using (public.is_admin());
create policy "discounts_delete" on public.discount_codes for delete using (public.is_admin());

-- ORDERS: customer creates their own, reads their own; admin reads/updates all
create policy "orders_select" on public.orders
  for select using (auth.uid() = customer_id or public.is_admin());
create policy "orders_insert" on public.orders
  for insert with check (auth.uid() = customer_id);
create policy "orders_update" on public.orders
  for update using (public.is_admin());

-- TICKETS: customer creates/reads their own, admin all; both can append to messages via update
create policy "tickets_select" on public.tickets
  for select using (auth.uid() = customer_id or public.is_admin());
create policy "tickets_insert" on public.tickets
  for insert with check (auth.uid() = customer_id);
create policy "tickets_update" on public.tickets
  for update using (auth.uid() = customer_id or public.is_admin());

-- STORE INFO / POLICIES: public read, admin write
create policy "store_info_select" on public.store_info for select using (true);
create policy "store_info_update" on public.store_info for update using (public.is_admin());
create policy "policies_select" on public.policies for select using (true);
create policy "policies_update" on public.policies for update using (public.is_admin());

-- ============================================================
-- AFTER RUNNING THIS FILE:
-- 1. Sign up once through the deployed app (normal email/password signup).
-- 2. Then run this ONE line (with your real email) to make yourself admin:
--    update public.profiles set role = 'admin' where email = 'YOUR_EMAIL_HERE';
-- ============================================================
