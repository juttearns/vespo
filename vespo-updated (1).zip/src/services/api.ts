import { supabase } from "./supabaseClient";
import { StoreInfo, Policies, Product, Category, DiscountCode, Order, Ticket, UserProfile } from "../types";

// ---------- mapping helpers (DB snake_case <-> app camelCase) ----------

function mapProduct(r: any): Product {
  return {
    id: r.id,
    title: r.title,
    description: r.description,
    price: Number(r.price),
    salePrice: r.sale_price !== null && r.sale_price !== undefined ? Number(r.sale_price) : undefined,
    category: r.category,
    images: r.images || [],
    stock: r.stock,
    isFeatured: r.is_featured,
    createdAt: r.created_at,
  };
}
function productToRow(p: Partial<Product>) {
  const row: any = {};
  if (p.title !== undefined) row.title = p.title;
  if (p.description !== undefined) row.description = p.description;
  if (p.price !== undefined) row.price = p.price;
  if (p.salePrice !== undefined) row.sale_price = p.salePrice;
  if (p.category !== undefined) row.category = p.category;
  if (p.images !== undefined) row.images = p.images;
  if (p.stock !== undefined) row.stock = p.stock;
  if (p.isFeatured !== undefined) row.is_featured = p.isFeatured;
  return row;
}

function mapCategory(r: any): Category {
  return { id: r.id, name: r.name, slug: r.slug };
}

function mapDiscount(r: any): DiscountCode {
  return {
    id: r.id,
    code: r.code,
    discountType: r.discount_type,
    value: Number(r.value),
    minPurchase: Number(r.min_purchase || 0),
    expiryDate: r.expiry_date || undefined,
    usageLimit: r.usage_limit || undefined,
    timesUsed: r.times_used,
    isActive: r.is_active,
    createdAt: r.created_at,
  };
}
function discountToRow(d: Partial<DiscountCode>) {
  const row: any = {};
  if (d.code !== undefined) row.code = d.code.toUpperCase();
  if (d.discountType !== undefined) row.discount_type = d.discountType;
  if (d.value !== undefined) row.value = d.value;
  if (d.minPurchase !== undefined) row.min_purchase = d.minPurchase;
  if (d.expiryDate !== undefined) row.expiry_date = d.expiryDate || null;
  if (d.usageLimit !== undefined) row.usage_limit = d.usageLimit;
  if (d.isActive !== undefined) row.is_active = d.isActive;
  return row;
}

function mapOrder(r: any): Order {
  return {
    id: r.id,
    orderCode: r.order_code,
    customerId: r.customer_id,
    customerName: r.customer_name,
    customerEmail: r.customer_email,
    customerPhone: r.customer_phone,
    customerPhoneVerified: r.customer_phone_verified,
    items: r.items || [],
    subtotal: Number(r.subtotal),
    deliveryFee: Number(r.delivery_fee),
    discountCode: r.discount_code || undefined,
    discountAmount: Number(r.discount_amount || 0),
    codCharge: Number(r.cod_charge || 0),
    totalAmount: Number(r.total_amount),
    paymentMethod: r.payment_method,
    paymentDetails: r.payment_details || undefined,
    bankTransactionId: r.bank_transaction_id || undefined,
    paymentConfirmed: r.payment_confirmed,
    shippingAddressText: r.shipping_address_text,
    shippingPin: { lat: r.shipping_lat, lng: r.shipping_lng },
    gpsCheck: r.gps_check || { matched: false, distanceKm: 0 },
    status: r.status,
    emailReceiptSent: r.email_receipt_sent,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

function mapTicket(r: any): Ticket {
  return {
    id: r.id,
    customerId: r.customer_id,
    customerName: r.customer_name,
    customerEmail: r.customer_email,
    subject: r.subject,
    category: r.category,
    status: r.status,
    messages: r.messages || [],
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

function mapStoreInfo(r: any): StoreInfo {
  return {
    storeName: r.store_name,
    tagline: r.tagline,
    bannerTitle: r.banner_title,
    bannerSubtitle: r.banner_subtitle,
    heroImageUrl: r.hero_image_url,
    deliveryFee: Number(r.delivery_fee),
    codFee: Number(r.cod_fee),
    bankName: r.bank_name,
    accountName: r.account_name,
    accountNumber: r.account_number,
    ibanRouting: r.iban_routing,
    jazzCashTitle: r.jazzcash_title || undefined,
    jazzCashNumber: r.jazzcash_number || undefined,
    easyPaisaTitle: r.easypaisa_title || undefined,
    easyPaisaNumber: r.easypaisa_number || undefined,
    supportEmail: r.support_email,
    supportPhone: r.support_phone,
    googleClientId: r.google_client_id,
    baseCurrency: r.base_currency,
  };
}
function storeInfoToRow(s: Partial<StoreInfo>) {
  const row: any = {};
  if (s.storeName !== undefined) row.store_name = s.storeName;
  if (s.tagline !== undefined) row.tagline = s.tagline;
  if (s.bannerTitle !== undefined) row.banner_title = s.bannerTitle;
  if (s.bannerSubtitle !== undefined) row.banner_subtitle = s.bannerSubtitle;
  if (s.heroImageUrl !== undefined) row.hero_image_url = s.heroImageUrl;
  if (s.deliveryFee !== undefined) row.delivery_fee = s.deliveryFee;
  if (s.codFee !== undefined) row.cod_fee = s.codFee;
  if (s.bankName !== undefined) row.bank_name = s.bankName;
  if (s.accountName !== undefined) row.account_name = s.accountName;
  if (s.accountNumber !== undefined) row.account_number = s.accountNumber;
  if (s.ibanRouting !== undefined) row.iban_routing = s.ibanRouting;
  if (s.jazzCashTitle !== undefined) row.jazzcash_title = s.jazzCashTitle;
  if (s.jazzCashNumber !== undefined) row.jazzcash_number = s.jazzCashNumber;
  if (s.easyPaisaTitle !== undefined) row.easypaisa_title = s.easyPaisaTitle;
  if (s.easyPaisaNumber !== undefined) row.easypaisa_number = s.easyPaisaNumber;
  if (s.supportEmail !== undefined) row.support_email = s.supportEmail;
  if (s.supportPhone !== undefined) row.support_phone = s.supportPhone;
  if (s.googleClientId !== undefined) row.google_client_id = s.googleClientId;
  if (s.baseCurrency !== undefined) row.base_currency = s.baseCurrency;
  return row;
}

function mapPolicies(r: any): Policies {
  return {
    privacyPolicy: r.privacy_policy,
    shippingPolicy: r.shipping_policy,
    returnPolicy: r.return_policy,
    termsOfService: r.terms_of_service,
    updatedAt: r.updated_at,
  };
}

function mapUser(r: any): UserProfile {
  return {
    id: r.id,
    email: r.email,
    name: r.name,
    role: r.role,
    phone: r.phone || undefined,
    phoneVerified: r.phone_verified,
    addressText: r.address_text,
    locationPin: r.location_lat !== null && r.location_lat !== undefined ? { lat: r.location_lat, lng: r.location_lng } : null,
    wishlist: r.wishlist || [],
    googleId: undefined,
    createdAt: r.created_at,
  };
}

function must<T>(data: T | null, error: any): T {
  if (error) throw new Error(error.message || "Request failed");
  return data as T;
}

// supabase-js wraps a non-2xx Edge Function response in a generic error whose
// .message doesn't include the actual JSON body the function returned.
// This pulls the real { error: "..." } or { message: "..." } out of it.
async function extractFunctionErrorMessage(error: any, fallback: string): Promise<string> {
  try {
    if (error?.context && typeof error.context.json === "function") {
      const body = await error.context.json();
      if (body?.error) return body.error;
      if (body?.message) return body.message;
    }
  } catch {
    // response wasn't JSON or already consumed — fall through
  }
  return error?.message || fallback;
}

export const api = {
  // ---------------- Store Info ----------------
  getStoreInfo: async () => {
    const { data, error } = await supabase.from("store_info").select("*").eq("id", 1).single();
    return mapStoreInfo(must(data, error));
  },
  updateStoreInfo: async (info: Partial<StoreInfo>) => {
    const { data, error } = await supabase.from("store_info").update(storeInfoToRow(info)).eq("id", 1).select().single();
    return { success: true, storeInfo: mapStoreInfo(must(data, error)) };
  },

  // ---------------- Policies ----------------
  getPolicies: async () => {
    const { data, error } = await supabase.from("policies").select("*").eq("id", 1).single();
    return mapPolicies(must(data, error));
  },
  updatePolicies: async (policies: Partial<Policies>) => {
    const row: any = { updated_at: new Date().toISOString() };
    if (policies.privacyPolicy !== undefined) row.privacy_policy = policies.privacyPolicy;
    if (policies.shippingPolicy !== undefined) row.shipping_policy = policies.shippingPolicy;
    if (policies.returnPolicy !== undefined) row.return_policy = policies.returnPolicy;
    if (policies.termsOfService !== undefined) row.terms_of_service = policies.termsOfService;
    const { data, error } = await supabase.from("policies").update(row).eq("id", 1).select().single();
    return { success: true, policies: mapPolicies(must(data, error)) };
  },

  // ---------------- Products & Categories ----------------
  getProducts: async () => {
    const { data, error } = await supabase.from("products").select("*").order("created_at", { ascending: false });
    return must(data, error).map(mapProduct);
  },
  createProduct: async (product: Partial<Product>) => {
    const { data, error } = await supabase.from("products").insert(productToRow(product)).select().single();
    return mapProduct(must(data, error));
  },
  fetchProductsFromUrls: async (urls: string[]) => {
    const { data, error } = await supabase.functions.invoke("fetch-product", { body: { urls } });
    if (error) throw new Error(await extractFunctionErrorMessage(error, "Failed to fetch product details"));
    return data as {
      success: boolean;
      results: {
        url: string;
        success: boolean;
        data?: {
          sourceUrl: string;
          siteName: string | null;
          title: string | null;
          description: string | null;
          images: string[];
          price: number | null;
          currency: string | null;
          category: string | null;
        };
        error?: string;
      }[];
    };
  },
  importBatchProducts: async (products: Partial<Product>[]) => {
    const rows = products
      .filter((p) => p.title && p.price !== undefined && p.price !== null)
      .map((p) => ({
        title: String(p.title).trim(),
        description: p.description ? String(p.description).trim() : "",
        price: Number(p.price) || 0,
        sale_price: p.salePrice ? Number(p.salePrice) : null,
        category: p.category ? String(p.category).trim() : "General",
        stock: typeof p.stock === "number" ? p.stock : parseInt(p.stock as any) || 10,
        is_featured: Boolean(p.isFeatured),
        images: p.images && p.images.length ? p.images : ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800"],
      }));
    const { data, error } = await supabase.from("products").insert(rows).select();
    const inserted = must(data, error);

    // auto-create any new categories
    const categories = Array.from(new Set(inserted.map((p: any) => p.category)));
    for (const name of categories) {
      await supabase.from("categories").upsert({ name, slug: (name as string).toLowerCase().replace(/\s+/g, "-") }, { onConflict: "name", ignoreDuplicates: true });
    }

    return { success: true, addedCount: inserted.length, products: inserted.map(mapProduct) };
  },
  updateProduct: async (id: string, product: Partial<Product>) => {
    const { data, error } = await supabase.from("products").update(productToRow(product)).eq("id", id).select().single();
    return mapProduct(must(data, error));
  },
  deleteProduct: async (id: string) => {
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) throw new Error(error.message);
    return { success: true };
  },

  getCategories: async () => {
    const { data, error } = await supabase.from("categories").select("*").order("name");
    return must(data, error).map(mapCategory);
  },
  createCategory: async (name: string) => {
    const slug = name.toLowerCase().replace(/\s+/g, "-");
    const { data, error } = await supabase.from("categories").upsert({ name, slug }, { onConflict: "name" }).select().single();
    return mapCategory(must(data, error));
  },
  deleteCategory: async (id: string) => {
    const { error } = await supabase.from("categories").delete().eq("id", id);
    if (error) throw new Error(error.message);
    return { success: true };
  },

  // ---------------- Discount Codes ----------------
  getDiscounts: async () => {
    const { data, error } = await supabase.from("discount_codes").select("*").order("created_at", { ascending: false });
    return must(data, error).map(mapDiscount);
  },
  createDiscount: async (discount: Partial<DiscountCode>) => {
    const { data, error } = await supabase.from("discount_codes").insert(discountToRow(discount)).select().single();
    return mapDiscount(must(data, error));
  },
  updateDiscount: async (id: string, discount: Partial<DiscountCode>) => {
    const { data, error } = await supabase.from("discount_codes").update(discountToRow(discount)).eq("id", id).select().single();
    return mapDiscount(must(data, error));
  },
  deleteDiscount: async (id: string) => {
    const { error } = await supabase.from("discount_codes").delete().eq("id", id);
    if (error) throw new Error(error.message);
    return { success: true };
  },
  validateDiscount: async (code: string, subtotal: number) => {
    const { data, error } = await supabase.from("discount_codes").select("*").ilike("code", code).eq("is_active", true).maybeSingle();
    if (error) throw new Error(error.message);
    if (!data) return { valid: false, message: "Invalid or inactive discount code." };
    if (data.expiry_date && new Date(data.expiry_date) < new Date()) return { valid: false, message: "This discount code has expired." };
    if (data.usage_limit && data.times_used >= data.usage_limit) return { valid: false, message: "This discount code has reached its usage limit." };
    if (data.min_purchase && subtotal < data.min_purchase) return { valid: false, message: `Minimum order subtotal of Rs. ${Number(data.min_purchase).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} required for this code.` };
    let discountAmount = data.discount_type === "percentage" ? (subtotal * data.value) / 100 : data.value;
    discountAmount = Math.min(discountAmount, subtotal);
    return { valid: true, code: data.code, discountType: data.discount_type, value: Number(data.value), discountAmount };
  },

  // ---------------- Orders ----------------
  getOrders: async (userId?: string) => {
    let query = supabase.from("orders").select("*").order("created_at", { ascending: false });
    if (userId) query = query.eq("customer_id", userId);
    const { data, error } = await query;
    return must(data, error).map(mapOrder);
  },
  createOrder: async (orderData: Partial<Order>) => {
    const orderCode = "VESPO-PK-" + Math.floor(100000 + Math.random() * 900000);
    const row: any = {
      order_code: orderCode,
      customer_id: orderData.customerId,
      customer_name: orderData.customerName,
      customer_email: orderData.customerEmail,
      customer_phone: orderData.customerPhone,
      customer_phone_verified: orderData.customerPhoneVerified || false,
      items: orderData.items || [],
      subtotal: orderData.subtotal || 0,
      delivery_fee: orderData.deliveryFee || 0,
      discount_code: orderData.discountCode,
      discount_amount: orderData.discountAmount || 0,
      cod_charge: orderData.codCharge || 0,
      total_amount: orderData.totalAmount || 0,
      payment_method: orderData.paymentMethod,
      payment_details: orderData.paymentDetails || null,
      bank_transaction_id: orderData.bankTransactionId,
      shipping_address_text: orderData.shippingAddressText,
      shipping_lat: orderData.shippingPin?.lat,
      shipping_lng: orderData.shippingPin?.lng,
      gps_check: orderData.gpsCheck || null,
    };
    const { data, error } = await supabase.from("orders").insert(row).select().single();
    const order = must(data, error);

    // bump discount usage
    if (orderData.discountCode) {
      const { data: disc } = await supabase.from("discount_codes").select("id,times_used").ilike("code", orderData.discountCode).maybeSingle();
      if (disc) await supabase.from("discount_codes").update({ times_used: (disc.times_used || 0) + 1 }).eq("id", disc.id);
    }

    // deduct stock
    if (Array.isArray(orderData.items)) {
      for (const item of orderData.items) {
        const { data: prod } = await supabase.from("products").select("stock").eq("id", item.productId).maybeSingle();
        if (prod) await supabase.from("products").update({ stock: Math.max(0, (prod.stock || 0) - item.quantity) }).eq("id", item.productId);
      }
    }

    return mapOrder(order);
  },
  updateOrderStatus: async (id: string, status: string, paymentConfirmed?: boolean) => {
    const row: any = { status, updated_at: new Date().toISOString() };
    if (paymentConfirmed !== undefined) row.payment_confirmed = paymentConfirmed;
    const { data, error } = await supabase.from("orders").update(row).eq("id", id).select().single();
    return mapOrder(must(data, error));
  },

  // ---------------- Support Tickets ----------------
  getTickets: async (userId?: string) => {
    let query = supabase.from("tickets").select("*").order("created_at", { ascending: false });
    if (userId) query = query.eq("customer_id", userId);
    const { data, error } = await query;
    return must(data, error).map(mapTicket);
  },
  createTicket: async (ticket: { customerId?: string; customerName?: string; customerEmail?: string; subject: string; category: string; message: string }) => {
    const messages = [{ id: "msg-1", senderRole: "customer", senderName: ticket.customerName || "Customer", message: ticket.message, timestamp: new Date().toISOString() }];
    const { data, error } = await supabase
      .from("tickets")
      .insert({
        customer_id: ticket.customerId,
        customer_name: ticket.customerName || "Customer",
        customer_email: ticket.customerEmail || "",
        subject: ticket.subject,
        category: ticket.category || "General",
        messages,
      })
      .select()
      .single();
    return mapTicket(must(data, error));
  },
  replyTicket: async (id: string, message: string, senderRole: "customer" | "admin", senderName: string) => {
    const { data: existing, error: readErr } = await supabase.from("tickets").select("messages").eq("id", id).single();
    if (readErr) throw new Error(readErr.message);
    const newMessage = { id: "msg-" + Date.now(), senderRole, senderName, message, timestamp: new Date().toISOString() };
    const messages = [...(existing.messages || []), newMessage];
    const { data, error } = await supabase
      .from("tickets")
      .update({ messages, status: senderRole === "admin" ? "replied" : "open", updated_at: new Date().toISOString() })
      .eq("id", id)
      .select()
      .single();
    return mapTicket(must(data, error));
  },

  // ---------------- Auth & Profile ----------------
  register: async (email: string, password: string, name?: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password, options: { data: { name } } });
    if (error) throw new Error(error.message);
    if (!data.session) {
      throw new Error("Account created. Check your email to confirm, then log in.");
    }
    const { data: profile, error: pErr } = await supabase.from("profiles").select("*").eq("id", data.user!.id).single();
    if (pErr) throw new Error(pErr.message);
    return { token: data.session.access_token, user: mapUser(profile) };
  },
  login: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);
    const { data: profile, error: pErr } = await supabase.from("profiles").select("*").eq("id", data.user.id).single();
    if (pErr) throw new Error(pErr.message);
    return { token: data.session.access_token, user: mapUser(profile) };
  },
  loginGoogle: async () => {
    // Redirects the whole page to Google's consent screen. There is no
    // user/token to return synchronously here — Supabase completes the
    // handshake when the browser is redirected back to this app, at
    // which point App.tsx's onAuthStateChange listener picks up the new
    // session (see api.getSessionUser below).
    const redirectTo = `${window.location.origin}${window.location.pathname}`;
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo },
    });
    if (error) throw new Error(error.message);
  },
  // Reads whatever Supabase session is currently active (used right after
  // an OAuth redirect completes) and maps it to the same { token, user }
  // shape that login()/register() return, so callers don't need to care
  // whether the session came from email/password or Google.
  getSessionUser: async (): Promise<{ token: string; user: UserProfile } | null> => {
    const { data: { session }, error: sessErr } = await supabase.auth.getSession();
    if (sessErr) throw new Error(sessErr.message);
    if (!session) return null;
    const { data: profile, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", session.user.id)
      .single();
    if (error) throw new Error(error.message);
    return { token: session.access_token, user: mapUser(profile) };
  },
  logout: async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw new Error(error.message);
  },
  updateProfile: async (data: { userId: string; addressText?: string; locationPin?: { lat: number; lng: number } | null; name?: string; email?: string; phone?: string; phoneVerified?: boolean }) => {
    const row: any = {};
    if (data.addressText !== undefined) row.address_text = data.addressText;
    if (data.locationPin !== undefined) {
      row.location_lat = data.locationPin?.lat ?? null;
      row.location_lng = data.locationPin?.lng ?? null;
    }
    if (data.name !== undefined) row.name = data.name;
    if (data.phone !== undefined) row.phone = data.phone;
    if (data.phoneVerified !== undefined) row.phone_verified = data.phoneVerified;
    const { data: updated, error } = await supabase.from("profiles").update(row).eq("id", data.userId).select().single();
    return mapUser(must(updated, error));
  },
  resendOrderEmail: async (_orderId: string) => {
    return { success: false, message: "Email receipts are turned off for now." };
  },
  getOrderEmailPreview: async (_orderId: string) => {
    throw new Error("Email receipts are turned off for now.");
  },
  toggleWishlist: async (userId: string, productId: string) => {
    const { data: profile, error: readErr } = await supabase.from("profiles").select("wishlist").eq("id", userId).single();
    if (readErr) throw new Error(readErr.message);
    let wishlist: string[] = profile.wishlist || [];
    wishlist = wishlist.includes(productId) ? wishlist.filter((id) => id !== productId) : [...wishlist, productId];
    const { error } = await supabase.from("profiles").update({ wishlist }).eq("id", userId);
    if (error) throw new Error(error.message);
    return { wishlist };
  },

  // ---------------- Admin Stats & Utilities ----------------
  getAdminStats: async () => {
    const [{ data: orders }, { data: tickets }, { data: products }, { data: users }] = await Promise.all([
      supabase.from("orders").select("total_amount,status"),
      supabase.from("tickets").select("status"),
      supabase.from("products").select("stock"),
      supabase.from("profiles").select("role"),
    ]);
    const validOrders = (orders || []).filter((o: any) => o.status !== "cancelled");
    return {
      totalRevenue: validOrders.reduce((sum: number, o: any) => sum + (Number(o.total_amount) || 0), 0),
      totalOrders: (orders || []).length,
      pendingOrders: (orders || []).filter((o: any) => o.status === "pending").length,
      cancelledOrders: (orders || []).filter((o: any) => o.status === "cancelled").length,
      openTickets: (tickets || []).filter((t: any) => t.status === "open").length,
      lowStockProducts: (products || []).filter((p: any) => (p.stock || 0) <= 5).length,
      totalProducts: (products || []).length,
      totalCustomers: (users || []).filter((u: any) => u.role !== "admin").length,
    };
  },
  seedDemoCatalog: async () => {
    const sampleCategories = [
      { name: "Apparel", slug: "apparel" },
      { name: "Footwear", slug: "footwear" },
      { name: "Accessories", slug: "accessories" },
      { name: "Home & Living", slug: "home-living" },
    ];
    await supabase.from("categories").upsert(sampleCategories, { onConflict: "name" });

    const sampleProducts = [
      { title: "Vespo Sculpted Organic Cotton Tee", description: "Heavyweight 240GSM organic cotton shirt with a subtle drop-shoulder fit.", price: 48.0, sale_price: 38.0, category: "Apparel", images: ["https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=800"], stock: 35, is_featured: true },
      { title: "Minimalist Leather Card Holder", description: "Crafted from full-grain Tuscan leather with hand-waxed edge burnishing.", price: 65.0, category: "Accessories", images: ["https://images.unsplash.com/photo-1627123424574-724758594e93?auto=format&fit=crop&q=80&w=800"], stock: 20, is_featured: true },
      { title: "Monochrome Canvas Studio Sneaker", description: "Vulcanized rubber sole, ergonomic orthotic insole.", price: 110.0, sale_price: 89.0, category: "Footwear", images: ["https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=800"], stock: 14, is_featured: true },
      { title: "Japanese Ceramic Pour-Over Dripper", description: "Artisanal stoneware kettle set.", price: 52.0, category: "Home & Living", images: ["https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&q=80&w=800"], stock: 25, is_featured: false },
      { title: "Structure Knit Merino Beanie", description: "100% extra-fine Australian Merino wool.", price: 36.0, category: "Accessories", images: ["https://images.unsplash.com/photo-1576871337622-98d48d1cf531?auto=format&fit=crop&q=80&w=800"], stock: 50, is_featured: true },
    ];
    await supabase.from("products").insert(sampleProducts);

    const sampleDiscounts = [
      { code: "WELCOME10", discount_type: "percentage", value: 10, min_purchase: 30, usage_limit: 100 },
      { code: "VESPO50", discount_type: "fixed", value: 15, min_purchase: 100, usage_limit: 50 },
    ];
    await supabase.from("discount_codes").upsert(sampleDiscounts, { onConflict: "code" });

    return { success: true, message: "Sample catalog seeded successfully." };
  },
};
