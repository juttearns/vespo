export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  salePrice?: number;
  category: string;
  images: string[];
  stock: number;
  isFeatured: boolean;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface CartItem {
  productId: string;
  product: Product;
  quantity: number;
}

export interface UserLocation {
  lat: number;
  lng: number;
}

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  role: 'customer' | 'admin';
  phone?: string;
  phoneVerified?: boolean;
  addressText: string;
  locationPin: UserLocation | null;
  wishlist: string[];
  googleId?: string;
  createdAt: string;
}

export interface GpsCheckResult {
  matched: boolean;
  distanceKm: number;
  userGps?: UserLocation;
  savedPin?: UserLocation;
}

export interface OrderItem {
  productId: string;
  productTitle: string;
  price: number;
  quantity: number;
  image?: string;
}

export interface Order {
  id: string;
  orderCode: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  customerPhoneVerified?: boolean;
  items: OrderItem[];
  subtotal: number;
  deliveryFee: number;
  discountCode?: string;
  discountAmount: number;
  codCharge: number;
  totalAmount: number;
  paymentMethod: 'cod' | 'bank_transfer' | 'jazzcash' | 'easypaisa';
  paymentDetails?: {
    senderMobile?: string;
    transactionId?: string;
    accountName?: string;
  };
  bankTransactionId?: string;
  paymentConfirmed: boolean;
  shippingAddressText: string;
  shippingPin: UserLocation;
  gpsCheck: GpsCheckResult;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  emailReceiptSent?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DiscountCode {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  minPurchase?: number;
  expiryDate?: string;
  usageLimit?: number;
  timesUsed: number;
  isActive: boolean;
  createdAt: string;
}

export interface TicketMessage {
  id: string;
  senderRole: 'customer' | 'admin';
  senderName: string;
  message: string;
  timestamp: string;
}

export interface Ticket {
  id: string;
  customerId: string;
  customerName: string;
  customerEmail: string;
  subject: string;
  category: string;
  status: 'open' | 'replied' | 'closed';
  messages: TicketMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface StoreInfo {
  storeName: string;
  tagline: string;
  bannerTitle: string;
  bannerSubtitle: string;
  heroImageUrl: string;
  deliveryFee: number;
  codFee: number;
  bankName: string;
  accountName: string;
  accountNumber: string;
  ibanRouting: string;
  jazzCashTitle?: string;
  jazzCashNumber?: string;
  easyPaisaTitle?: string;
  easyPaisaNumber?: string;
  supportEmail: string;
  supportPhone: string;
  googleClientId: string;
  baseCurrency?: string;
}

export interface Policies {
  privacyPolicy: string;
  shippingPolicy: string;
  returnPolicy: string;
  termsOfService: string;
  updatedAt: string;
}

export interface AuthState {
  user: UserProfile | null;
  token: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
}
