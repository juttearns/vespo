import React from "react";

/**
 * Cleans product descriptions imported from suppliers (Markaz, Shopify, WooCommerce, AliExpress, etc.)
 * Strips out promotional links, affiliate text, product code lists, and cleans HTML formatting.
 */
export function cleanProductDescription(desc: string | undefined | null): string {
  if (!desc || typeof desc !== "string") return "";

  let clean = desc;

  // 1. Remove <li>Product Code: ...</li> or <li>SKU: ...</li> or <li>Code: ...</li>
  clean = clean.replace(/<li[^>]*>\s*(?:Product Code|SKU|Item Code|Product SKU|Code|Model Code|Ref Code)\s*:\s*[^<]*<\/li>/gi, "");

  // 2. Remove supplier promotion paragraphs and referral links (e.g., Markaz, Shopify, WooCommerce promos)
  clean = clean.replace(/<p[^>]*>\s*Delivered across[^<]*<\/p>/gi, "");
  clean = clean.replace(/<p[^>]*>\s*Free shipping across[^<]*<\/p>/gi, "");
  clean = clean.replace(/<p[^>]*>\s*Cash on delivery available[^<]*<\/p>/gi, "");
  clean = clean.replace(/<p[^>]*>\s*<a [^>]*href="[^"]*(?:markaz|shopify|wordpress|express|referral|ref=)[^"]*"[^>]*>.*?<\/a>\s*<\/p>/gi, "");
  clean = clean.replace(/<p[^>]*>\s*<a [^>]*>View this product on [^<]+<\/a>\s*<\/p>/gi, "");
  clean = clean.replace(/<a [^>]*href="[^"]*markaz\.app[^"]*"[^>]*>.*?<\/a>/gi, "");
  clean = clean.replace(/View this product on Markaz/gi, "");
  clean = clean.replace(/Delivered across Pakistan with cash on delivery\.?/gi, "");

  // 3. Remove orphaned empty HTML tags left after stripping
  clean = clean.replace(/<ul[^>]*>\s*<\/ul>/gi, "");
  clean = clean.replace(/<ol[^>]*>\s*<\/ol>/gi, "");
  clean = clean.replace(/<p[^>]*>\s*<\/p>/gi, "");

  return clean.trim();
}

/**
 * Strips HTML tags and decodes entities for short plain-text previews
 * (product cards, search results) — use this anywhere the full HTML
 * formatting from ProductDescriptionDisplay isn't wanted, just a clean snippet.
 */
export function stripDescriptionToText(desc: string | undefined | null): string {
  const cleaned = cleanProductDescription(desc);
  if (!cleaned) return "";
  return cleaned
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * Helper to check if string contains HTML tags
 */
export function isHtmlString(str: string): boolean {
  return /<[a-z][\s\S]*>/i.test(str);
}

interface ProductDescriptionDisplayProps {
  description?: string;
  className?: string;
}

/**
 * Renders product description safely with full HTML compilation/formatting support.
 * Automatically cleans promotional noise and formats tags like <p>, <ul>, <li>, <strong> cleanly.
 */
export function ProductDescriptionDisplay({
  description,
  className = "",
}: ProductDescriptionDisplayProps) {
  const cleaned = cleanProductDescription(description);

  if (!cleaned) {
    return <p className={`text-slate-400 italic text-sm ${className}`}>No description provided.</p>;
  }

  if (isHtmlString(cleaned)) {
    return (
      <div
        className={`text-slate-600 text-sm leading-relaxed 
          [&_p]:mb-3 [&_p:last-child]:mb-0 
          [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:my-3 
          [&_ol]:list-decimal [&_ol]:pl-5 [&_ol]:my-3 
          [&_li]:mb-1.5 [&_li]:text-slate-600 
          [&_strong]:font-bold [&_strong]:text-slate-900 
          [&_b]:font-bold [&_b]:text-slate-900 
          [&_h1]:font-extrabold [&_h1]:text-slate-900 [&_h1]:text-lg [&_h1]:mb-2 
          [&_h2]:font-bold [&_h2]:text-slate-900 [&_h2]:text-base [&_h2]:mb-2 
          [&_h3]:font-bold [&_h3]:text-slate-900 [&_h3]:text-sm [&_h3]:mb-1 
          ${className}`}
        dangerouslySetInnerHTML={{ __html: cleaned }}
      />
    );
  }

  return (
    <div className={`text-slate-600 text-sm leading-relaxed whitespace-pre-line ${className}`}>
      {cleaned}
    </div>
  );
}
