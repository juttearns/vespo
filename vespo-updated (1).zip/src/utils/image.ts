import React from "react";

export const DEFAULT_PRODUCT_IMAGE =
  "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=85&w=1200";

/**
 * Optimizes image URLs for crystal-clear display across high-DPI screens.
 * Automatically converts low-resolution CDN params, protocol-relative links (//cdn...),
 * Google Drive view links, and cleans html/quote wrappers into high-resolution images.
 */
export function optimizeImageUrl(url: string | undefined | null): string {
  if (!url || typeof url !== "string") {
    return DEFAULT_PRODUCT_IMAGE;
  }

  // 1. Clean HTML tags and surrounding quotes/spaces
  let trimmed = url.trim().replace(/^["']|["']$/g, "");

  if (trimmed.includes("<img") || trimmed.includes("src=")) {
    const match = trimmed.match(/src=["']([^"']+)["']/i);
    if (match && match[1]) {
      trimmed = match[1].trim();
    }
  }

  if (!trimmed) {
    return DEFAULT_PRODUCT_IMAGE;
  }

  // 2. Handle Google Drive preview/view URLs
  if (trimmed.includes("drive.google.com")) {
    const fileIdMatch =
      trimmed.match(/\/file\/d\/([a-zA-Z0-9_-]+)/) ||
      trimmed.match(/id=([a-zA-Z0-9_-]+)/);
    if (fileIdMatch && fileIdMatch[1]) {
      return `https://lh3.googleusercontent.com/d/${fileIdMatch[1]}`;
    }
  }

  // 3. Handle Shopify / WooCommerce protocol-relative links (e.g. //cdn.shopify.com/...)
  if (trimmed.startsWith("//")) {
    trimmed = `https:${trimmed}`;
  } else if (
    !trimmed.startsWith("http://") &&
    !trimmed.startsWith("https://") &&
    !trimmed.startsWith("data:") &&
    !trimmed.startsWith("blob:")
  ) {
    if (trimmed.includes(".") && !trimmed.includes(" ")) {
      trimmed = `https://${trimmed}`;
    } else {
      return DEFAULT_PRODUCT_IMAGE;
    }
  }

  // 4. Handle Unsplash images
  if (trimmed.includes("images.unsplash.com")) {
    try {
      const urlObj = new URL(trimmed);
      const currentW = parseInt(urlObj.searchParams.get("w") || "0", 10);
      if (currentW < 1000) {
        urlObj.searchParams.set("w", "1400");
      }
      urlObj.searchParams.set("q", "85");
      urlObj.searchParams.set("auto", "format");
      return urlObj.toString();
    } catch {
      return trimmed.replace(/w=\d+/, "w=1400").replace(/q=\d+/, "q=85");
    }
  }

  // 5. Handle Imgur thumbnails (e.g. i.imgur.com/abc_s.jpg -> i.imgur.com/abc.jpg)
  if (trimmed.includes("imgur.com")) {
    return trimmed.replace(/([a-zA-Z0-9]+)[stml]\.(jpg|png|jpeg|webp|gif)$/i, "$1.$2");
  }

  // 6. Handle Shopify image thumbnails (_100x100.jpg -> _1200x1200.jpg)
  if (trimmed.includes("cdn.shopify.com")) {
    return trimmed.replace(/_\d+x\d*/g, "_1200x1200");
  }

  return trimmed;
}

/**
 * Global fallback handler for broken <img> loads (CORS, 404, blocked hotlinks).
 * Replaces the broken src with a crisp, reliable fallback product image safely.
 */
export function handleImageError(
  e: React.SyntheticEvent<HTMLImageElement, Event>,
  fallbackUrl: string = DEFAULT_PRODUCT_IMAGE
) {
  const target = e.currentTarget;
  if (target.src !== fallbackUrl) {
    target.onerror = null; // Prevents infinite recursion loop
    target.src = fallbackUrl;
  }
}

