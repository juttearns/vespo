import React from "react";
import { ShieldCheck, Truck, RefreshCw, FileText } from "lucide-react";
import { Policies, StoreInfo } from "../types";

interface PoliciesViewProps {
  policies: Policies;
  storeInfo: StoreInfo;
}

export const PoliciesView: React.FC<PoliciesViewProps> = ({ policies, storeInfo }) => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16">
      <div className="bg-white p-8 sm:p-10 rounded-3xl border border-slate-200/80 shadow-md space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-bold border border-indigo-100">
          <ShieldCheck className="w-4 h-4" />
          <span>Verified Store Policies</span>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">
          {storeInfo.storeName || "Vespo"} Legal Policies & Delivery Terms
        </h1>

        <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
          Please review our official policies regarding data privacy, order fulfillment, map pin location cross-checks, returns, and customer service terms.
        </p>
      </div>

      <div className="space-y-6">
        {/* 1. Privacy Policy */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
          <div className="flex items-center gap-2.5 text-indigo-600 font-extrabold text-base border-b border-slate-100 pb-3">
            <ShieldCheck className="w-5 h-5" />
            <h2>Privacy Policy</h2>
          </div>
          <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
            {policies.privacyPolicy || "Our standard privacy policy protects your personal information."}
          </div>
        </section>

        {/* 2. Shipping & Location Policy */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
          <div className="flex items-center gap-2.5 text-indigo-600 font-extrabold text-base border-b border-slate-100 pb-3">
            <Truck className="w-5 h-5" />
            <h2>Shipping & GPS Verification Policy</h2>
          </div>
          <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
            {policies.shippingPolicy || "Standard delivery terms with GPS cross-check."}
          </div>
        </section>

        {/* 3. Return & Refund Policy */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
          <div className="flex items-center gap-2.5 text-indigo-600 font-extrabold text-base border-b border-slate-100 pb-3">
            <RefreshCw className="w-5 h-5" />
            <h2>Returns & Refund Policy</h2>
          </div>
          <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
            {policies.returnPolicy || "Returns policy managed through our support desk."}
          </div>
        </section>

        {/* 4. Terms of Service */}
        <section className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-3">
          <div className="flex items-center gap-2.5 text-indigo-600 font-extrabold text-base border-b border-slate-100 pb-3">
            <FileText className="w-5 h-5" />
            <h2>Terms of Service</h2>
          </div>
          <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
            {policies.termsOfService || "Standard store terms."}
          </div>
        </section>
      </div>
    </div>
  );
};
