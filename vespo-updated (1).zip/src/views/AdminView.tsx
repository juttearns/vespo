import React, { useState, useEffect } from "react";
import { LayoutDashboard, ShoppingBag, PackageCheck, Tag, HelpCircle, Store, ShieldCheck, ArrowLeft, LogOut, CheckCircle2 } from "lucide-react";
import { AdminDashboard } from "../admin/AdminDashboard";
import { AdminProducts } from "../admin/AdminProducts";
import { AdminOrders } from "../admin/AdminOrders";
import { AdminOffers } from "../admin/AdminOffers";
import { AdminTickets } from "../admin/AdminTickets";
import { AdminStoreInfo } from "../admin/AdminStoreInfo";
import { AdminPolicies } from "../admin/AdminPolicies";
import { StoreInfo, Product, Category, Order } from "../types";
import { api } from "../services/api";

interface AdminViewProps {
  storeInfo: StoreInfo;
  onRefreshStoreInfo: () => void;
  onNavigateStorefront: () => void;
  onLogout: () => void;
  currency?: string;
}

export const AdminView: React.FC<AdminViewProps> = ({
  storeInfo,
  onRefreshStoreInfo,
  onNavigateStorefront,
  onLogout,
  currency = "PKR",
}) => {
  const [activeTab, setActiveTab] = useState<
    "dashboard" | "products" | "orders" | "offers" | "tickets" | "storeinfo" | "policies"
  >("dashboard");

  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);

  const refreshData = async () => {
    try {
      const [pRes, cRes, oRes] = await Promise.all([
        api.getProducts(),
        api.getCategories(),
        api.getOrders(),
      ]);
      setProducts(pRes);
      setCategories(cRes);
      setOrders(oRes);
      onRefreshStoreInfo();
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    refreshData();
  }, []);

  const navItems = [
    { key: "dashboard", label: "Overview", icon: LayoutDashboard },
    { key: "products", label: "Products & Catalog", icon: ShoppingBag, count: products.length },
    { key: "orders", label: "Orders & GPS Audit", icon: PackageCheck, count: orders.length },
    { key: "offers", label: "Coupons & Offers", icon: Tag },
    { key: "tickets", label: "Support Tickets", icon: HelpCircle },
    { key: "storeinfo", label: "Store Info & Branding", icon: Store },
    { key: "policies", label: "Legal Policies", icon: ShieldCheck },
  ];

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col md:flex-row">
      {/* Admin Sidebar Navigation */}
      <aside className="w-full md:w-64 bg-white border-r border-slate-200/80 p-6 flex flex-col justify-between shrink-0 shadow-sm">
        <div className="space-y-6">
          {/* Admin Header / Logo */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-slate-900 text-white font-black text-sm flex items-center justify-center">
                V
              </div>
              <div>
                <span className="font-extrabold text-sm tracking-tight text-slate-900">Vespo Admin</span>
                <span className="block text-[10px] text-emerald-600 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  Storefront Live
                </span>
              </div>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.key;
              return (
                <button
                  key={item.key}
                  onClick={() => setActiveTab(item.key as any)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                    isActive
                      ? "bg-slate-900 text-white shadow-sm"
                      : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {item.count !== undefined && (
                    <span className={`px-2 py-0.5 text-[10px] font-mono rounded-full ${
                      isActive ? "bg-slate-800 text-slate-200" : "bg-slate-100 text-slate-600"
                    }`}>
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Actions: Return to Storefront & Logout */}
        <div className="pt-6 border-t border-slate-100 space-y-2 text-xs">
          <button
            onClick={onNavigateStorefront}
            className="w-full px-3.5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl transition-colors flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Go to Customer Storefront</span>
          </button>

          <button
            onClick={onLogout}
            className="w-full px-3.5 py-2 bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 font-bold rounded-xl transition-colors flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out Admin</span>
          </button>
        </div>
      </aside>

      {/* Main Admin Content Canvas */}
      <main className="flex-1 p-6 sm:p-10 max-w-6xl overflow-y-auto">
        {activeTab === "dashboard" && (
          <AdminDashboard
            onNavigateTab={(tab) => setActiveTab(tab as any)}
            currency={currency}
            baseCurrency={storeInfo.baseCurrency || "PKR"}
          />
        )}

        {activeTab === "products" && (
          <AdminProducts
            products={products}
            categories={categories}
            onRefresh={refreshData}
            currency={currency}
            baseCurrency={storeInfo.baseCurrency || "PKR"}
          />
        )}

        {activeTab === "orders" && (
          <AdminOrders
            orders={orders}
            onRefresh={refreshData}
            currency={currency}
            baseCurrency={storeInfo.baseCurrency || "PKR"}
          />
        )}

        {activeTab === "offers" && (
          <AdminOffers currency={currency} baseCurrency={storeInfo.baseCurrency || "PKR"} />
        )}

        {activeTab === "tickets" && (
          <AdminTickets />
        )}

        {activeTab === "storeinfo" && (
          <AdminStoreInfo
            storeInfo={storeInfo}
            onRefreshStoreInfo={() => {
              onRefreshStoreInfo();
              refreshData();
            }}
          />
        )}

        {activeTab === "policies" && (
          <AdminPolicies />
        )}
      </main>
    </div>
  );
};
