import React from "react";
import { ShoppingBag, Heart, ArrowRight, Tag, Sparkles, Layers, PackageCheck } from "lucide-react";
import { StoreInfo, Product, Category, UserProfile } from "../types";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl, handleImageError } from "../utils/image";
import { stripDescriptionToText } from "../utils/descriptionCleaner";

interface HomeViewProps {
  storeInfo: StoreInfo;
  categories: Category[];
  featuredProducts: Product[];
  allProducts: Product[];
  user: UserProfile | null;
  onNavigate: (view: string, param?: string) => void;
  onAddToCart: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  currency?: string;
}

export const HomeView: React.FC<HomeViewProps> = ({
  storeInfo,
  categories,
  featuredProducts,
  allProducts,
  user,
  onNavigate,
  onAddToCart,
  onToggleWishlist,
  currency = "PKR",
}) => {
  const productsToShow = allProducts;

  return (
    <div className="space-y-12 pb-16">
      {/* Hero Banner Area */}
      <section className="relative bg-slate-900 text-white rounded-3xl overflow-hidden shadow-xl border border-slate-800">
        <div className="absolute inset-0 z-0 opacity-40 mix-blend-overlay">
          <img
            src={optimizeImageUrl(storeInfo.heroImageUrl)}
            alt="Vespo Hero Banner"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
            onError={handleImageError}
          />
        </div>

        <div className="relative z-10 max-w-3xl px-6 sm:px-12 py-16 sm:py-24 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 text-xs font-semibold backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{storeInfo.tagline || "Elevated Daily Essentials"}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight text-white">
            {storeInfo.bannerTitle || "Modern Lifestyle Essentials"}
          </h1>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-xl">
            {storeInfo.bannerSubtitle ||
              "Discover handcrafted minimalist pieces designed for effortless daily living."}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4">
            <button
              onClick={() => onNavigate("categories")}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-bold rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-2 transition-all hover:translate-x-0.5"
            >
              <span>Explore Collection</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate("policies")}
              className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white text-sm font-semibold rounded-xl backdrop-blur-md transition-colors border border-white/10"
            >
              Shipping & Policies
            </button>
          </div>
        </div>
      </section>

      {/* Featured Categories Grid */}
      {categories.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-indigo-600" />
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                Shop by Category
              </h2>
            </div>
            <button
              onClick={() => onNavigate("categories")}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => onNavigate("categories", cat.name)}
                className="group p-5 bg-white rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-md hover:border-indigo-300 text-left transition-all"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-base mb-3 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  {cat.name.charAt(0)}
                </div>
                <h3 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">
                  {cat.name}
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">Explore catalog &rarr;</p>
              </button>
            ))}
          </div>
        </section>
      )}

      {/* Products Showcase */}
      <section className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              Products & New Arrivals
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Handcrafted minimalist items ready for immediate GPS-verified dispatch.
            </p>
          </div>
          <button
            onClick={() => onNavigate("categories")}
            className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
          >
            <span>Browse Full Catalog ({allProducts.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Empty Catalog State */}
        {productsToShow.length === 0 ? (
          <div className="p-12 text-center bg-white rounded-2xl border border-dashed border-slate-300 space-y-4">
            <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
              <PackageCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-800">Catalog Currently Empty</h3>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                No products have been created in the store catalog yet. Products entered through the admin portal will appear here live!
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
            {productsToShow.slice(0, 8).map((product) => {
              const isWishlisted = user?.wishlist?.includes(product.id) || false;
              const hasDiscount = product.salePrice && product.salePrice < product.price;

              return (
                <div
                  key={product.id}
                  className="group bg-white rounded-xl sm:rounded-2xl border border-slate-200/80 shadow-sm hover:shadow-lg transition-all duration-200 overflow-hidden flex flex-col"
                >
                  {/* Image Container */}
                  <div className="relative aspect-square bg-slate-100 overflow-hidden">
                    <img
                      src={optimizeImageUrl(product.images?.[0])}
                      alt={product.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      referrerPolicy="no-referrer"
                      onError={handleImageError}
                    />

                    {/* Badges Container */}
                    <div className="absolute top-2 left-2 sm:top-3 sm:left-3 flex flex-col gap-1 items-start">
                      {hasDiscount && (
                        <div className="bg-indigo-600 text-white text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 sm:px-2.5 sm:py-1 rounded-full shadow-md flex items-center gap-0.5 sm:gap-1">
                          <Tag className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                          <span>SALE</span>
                        </div>
                      )}
                      {product.isFeatured && (
                        <div className="bg-amber-500 text-white text-[9px] sm:text-[10px] font-bold px-1.5 py-0.5 sm:px-2.5 sm:py-1 rounded-full shadow-md flex items-center gap-0.5 sm:gap-1">
                          <Sparkles className="w-2.5 h-2.5 sm:w-3 sm:h-3" />
                          <span className="hidden xs:inline">FEATURED</span>
                        </div>
                      )}
                    </div>

                    {/* Wishlist Button */}
                    <button
                      onClick={() => onToggleWishlist(product.id)}
                      className={`absolute top-2 right-2 sm:top-3 sm:right-3 p-1.5 sm:p-2 rounded-full backdrop-blur-md shadow-md transition-colors ${
                        isWishlisted
                          ? "bg-rose-50 text-rose-600 border border-rose-200"
                          : "bg-white/80 text-slate-600 hover:text-rose-600 hover:bg-white"
                      }`}
                    >
                      <Heart className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${isWishlisted ? "fill-current" : ""}`} />
                    </button>
                  </div>

                  {/* Content Details */}
                  <div className="p-2.5 sm:p-4 flex-1 flex flex-col justify-between space-y-2 sm:space-y-3">
                    <div>
                      <span className="text-[9px] sm:text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                        {product.category || "General"}
                      </span>
                      <button
                        onClick={() => onNavigate("product", product.id)}
                        className="block text-xs sm:text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1 text-left mt-0.5"
                      >
                        {product.title}
                      </button>
                      <p className="text-[11px] sm:text-xs text-slate-500 line-clamp-2 mt-0.5 sm:mt-1 leading-tight sm:leading-relaxed">
                        {stripDescriptionToText(product.description)}
                      </p>
                    </div>

                    <div className="pt-1.5 sm:pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1 sm:gap-0">
                      <div>
                        {hasDiscount ? (
                          <div className="flex items-baseline gap-1">
                            <span className="text-xs sm:text-base font-extrabold text-slate-900">
                              {formatPrice(product.salePrice, currency, storeInfo.baseCurrency || "PKR")}
                            </span>
                            <span className="text-[10px] sm:text-xs text-slate-400 line-through">
                              {formatPrice(product.price, currency, storeInfo.baseCurrency || "PKR")}
                            </span>
                          </div>
                        ) : (
                          <span className="text-xs sm:text-base font-extrabold text-slate-900">
                            {formatPrice(product.price, currency, storeInfo.baseCurrency || "PKR")}
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => onAddToCart(product)}
                        className="w-full sm:w-auto px-2.5 py-1 sm:px-3 sm:py-1.5 bg-slate-900 hover:bg-indigo-600 text-white text-[10px] sm:text-xs font-semibold rounded-lg sm:rounded-xl shadow transition-colors flex items-center justify-center gap-1"
                      >
                        <ShoppingBag className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                        <span>Add</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
};
