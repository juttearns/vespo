import React, { useState } from "react";
import { CheckCircle2, Package, MapPin, CreditCard, Banknote, Clock, ArrowRight, ShieldCheck, Mail, Smartphone, RefreshCw, Send, Printer, FileText, X } from "lucide-react";
import { Order } from "../types";
import { formatPrice } from "../utils/currency";
import { api } from "../services/api";

interface OrderConfirmationViewProps {
  order: Order;
  onNavigate: (view: string, param?: string) => void;
  currency?: string;
  baseCurrency?: string;
}

export const OrderConfirmationView: React.FC<OrderConfirmationViewProps> = ({
  order,
  onNavigate,
  currency = "PKR",
  baseCurrency = "PKR",
}) => {
  const [resendingEmail, setResendingEmail] = useState(false);
  const [emailStatus, setEmailStatus] = useState<string | null>(null);
  const [showReceiptModal, setShowReceiptModal] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailPreviewData, setEmailPreviewData] = useState<{ subject: string; recipientEmail: string; isSmtpConfigured: boolean; html: string } | null>(null);
  const [loadingEmailPreview, setLoadingEmailPreview] = useState(false);

  const steps = [
    { key: "pending", label: "Order Received", desc: "Awaiting confirmation" },
    { key: "processing", label: "Processing", desc: "Preparing in warehouse" },
    { key: "shipped", label: "Out for Delivery", desc: "En route to GPS location" },
    { key: "delivered", label: "Delivered", desc: "Fulfilled successfully" },
  ];

  const currentStepIndex = steps.findIndex((s) => s.key === order.status);

  const handleResendReceipt = async () => {
    setResendingEmail(true);
    setEmailStatus(null);
    try {
      const res = await api.resendOrderEmail(order.id);
      setEmailStatus(res.message);
    } catch (err: any) {
      setEmailStatus("Failed to send receipt email: " + err.message);
    } finally {
      setResendingEmail(false);
    }
  };

  const handleOpenEmailPreview = async () => {
    setShowEmailModal(true);
    setLoadingEmailPreview(true);
    try {
      const data = await api.getOrderEmailPreview(order.id);
      setEmailPreviewData(data);
    } catch (err) {
      console.error("Failed to load email preview", err);
    } finally {
      setLoadingEmailPreview(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const getPaymentMethodLabel = () => {
    if (order.paymentMethod === "cod") return "Cash on Delivery (COD)";
    if (order.paymentMethod === "jazzcash") return "JazzCash Manual Transfer";
    if (order.paymentMethod === "easypaisa") return "EasyPaisa Manual Transfer";
    return "Manual Bank Transfer";
  };

  const subtotal = Number(order.subtotal || 0);
  const codCharge = Number(order.codCharge || 0);
  const discountAmount = Number(order.discountAmount || 0);
  const totalAmount = Number(order.totalAmount || (subtotal + codCharge - discountAmount));
  const deliveryFee = Number(
    order.deliveryFee !== undefined
      ? order.deliveryFee
      : Math.max(0, totalAmount - (subtotal + codCharge - discountAmount))
  );

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-16">
      {/* Success Hero Header */}
      <div className="bg-white p-8 sm:p-10 rounded-3xl border border-slate-200/80 shadow-md text-center space-y-4">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto border border-emerald-200">
          <CheckCircle2 className="w-9 h-9" />
        </div>
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100">
            Order Confirmed & Logged
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-2">
            Thank You For Your Order!
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mt-1">
            Order Code: <strong className="text-slate-900 font-mono text-indigo-600 font-black">{order.orderCode}</strong><br/>
            Receipt dispatched to <strong className="text-slate-900">{order.customerEmail}</strong>.
          </p>
        </div>

        {/* Email Receipt & On-Screen Print Action Buttons */}
        <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={() => setShowReceiptModal(true)}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs shadow-md transition-colors flex items-center gap-2"
          >
            <FileText className="w-4 h-4 text-indigo-400" />
            <span>View & Print Official Receipt</span>
          </button>

          <button
            onClick={handleOpenEmailPreview}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow-md transition-colors flex items-center gap-2"
          >
            <Mail className="w-4 h-4 text-white" />
            <span>View E-Receipt Email</span>
          </button>

          <button
            onClick={handleResendReceipt}
            disabled={resendingEmail}
            className="px-4 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-xl text-xs border border-indigo-200 transition-colors flex items-center gap-2"
          >
            {resendingEmail ? (
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-600" />
            ) : (
              <Send className="w-4 h-4 text-indigo-600" />
            )}
            <span>{resendingEmail ? "Dispatching..." : "Resend Email"}</span>
          </button>
        </div>

        {emailStatus && (
          <div className="text-xs font-bold text-slate-700 bg-slate-50 p-3 rounded-2xl border border-slate-200 max-w-lg mx-auto text-left leading-relaxed flex items-start gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>{emailStatus}</span>
          </div>
        )}
      </div>

      {/* Visual Timeline Tracker */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
        <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-600" />
          <span>Live Fulfillment Status Tracker</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 relative">
          {steps.map((step, idx) => {
            const isCompleted = currentStepIndex >= idx;
            const isCurrent = currentStepIndex === idx;

            return (
              <div
                key={step.key}
                className={`p-4 rounded-2xl border text-left transition-all ${
                  isCurrent
                    ? "bg-indigo-50/80 border-indigo-300 ring-2 ring-indigo-500/20"
                    : isCompleted
                    ? "bg-slate-50 border-slate-200"
                    : "bg-white border-slate-100 opacity-50"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`w-6 h-6 rounded-full text-[11px] font-bold flex items-center justify-center ${
                    isCompleted ? "bg-indigo-600 text-white" : "bg-slate-200 text-slate-600"
                  }`}>
                    {idx + 1}
                  </span>
                  {isCompleted && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </div>
                <h4 className="text-xs font-bold text-slate-900">{step.label}</h4>
                <p className="text-[10px] text-slate-500 mt-0.5">{step.desc}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Order Breakdown Details */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/80 shadow-sm space-y-6">
        <h3 className="text-base font-extrabold text-slate-900 border-b border-slate-100 pb-3">
          Order Summary & Delivery Location
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs">
          {/* Address & GPS Pin */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-indigo-600" />
              <span>Delivery Address & Contact</span>
            </h4>
            <p className="text-slate-700 leading-relaxed font-medium">{order.shippingAddressText}</p>
            {order.shippingPin && (
              <p className="text-[10px] text-slate-500 font-mono">
                Pin Coordinates: {order.shippingPin.lat.toFixed(4)}, {order.shippingPin.lng.toFixed(4)}
              </p>
            )}
            {order.customerPhone && (
              <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-slate-700">
                <span className="font-medium flex items-center gap-1">
                  <Smartphone className="w-3.5 h-3.5 text-slate-500" />
                  {order.customerPhone}
                </span>
                <span className="text-[10px] text-slate-400">Phone Provided</span>
              </div>
            )}
          </div>

          {/* Payment Status */}
          <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <h4 className="font-bold text-slate-900 flex items-center gap-1.5">
              {order.paymentMethod === "cod" ? (
                <Banknote className="w-4 h-4 text-emerald-600" />
              ) : order.paymentMethod === "jazzcash" ? (
                <Smartphone className="w-4 h-4 text-red-600" />
              ) : order.paymentMethod === "easypaisa" ? (
                <Smartphone className="w-4 h-4 text-emerald-600" />
              ) : (
                <CreditCard className="w-4 h-4 text-indigo-600" />
              )}
              <span>Payment Details</span>
            </h4>
            <p className="text-slate-800 font-bold">
              Method: {getPaymentMethodLabel()}
            </p>
            {order.paymentDetails?.transactionId ? (
              <p className="text-[11px] text-slate-600">
                TID: <strong className="font-mono text-indigo-600 font-extrabold">{order.paymentDetails.transactionId}</strong>
                {order.paymentDetails.senderMobile && ` (Sender: ${order.paymentDetails.senderMobile})`}
              </p>
            ) : order.bankTransactionId ? (
              <p className="text-[11px] text-slate-600">
                TID: <strong className="font-mono text-indigo-600 font-extrabold">{order.bankTransactionId}</strong>
              </p>
            ) : null}
            <div className="pt-1">
              <span className={`inline-block px-2.5 py-1 text-[10px] font-bold rounded-full ${
                order.paymentConfirmed
                  ? "bg-emerald-100 text-emerald-800"
                  : "bg-amber-100 text-amber-800"
              }`}>
                {order.paymentConfirmed ? "Payment Confirmed by Store Admin" : "Awaiting Store Admin Payment Audit"}
              </span>
            </div>
          </div>
        </div>

        {/* Ordered Items Table */}
        <div className="border-t border-slate-100 pt-4 space-y-3">
          <h4 className="text-xs font-bold text-slate-900">Items Ordered ({order.items?.length})</h4>
          <div className="space-y-2">
            {order.items?.map((item, i) => (
              <div key={i} className="flex items-center justify-between text-xs py-1.5 border-b border-slate-50">
                <div className="flex items-center gap-3">
                  {item.image && (
                    <img src={item.image} alt="" className="w-10 h-10 rounded-lg object-cover bg-slate-100" />
                  )}
                  <div>
                    <span className="font-bold text-slate-900">{item.productTitle}</span>
                    <p className="text-[11px] text-slate-500">{item.quantity} x {formatPrice(item.price, currency, baseCurrency)}</p>
                  </div>
                </div>
                <span className="font-extrabold text-slate-900">{formatPrice(item.quantity * item.price, currency, baseCurrency)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Complete Calculation Breakdown */}
        <div className="border-t border-slate-200 pt-4 space-y-2 text-xs text-slate-600">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span className="font-semibold text-slate-900">{formatPrice(subtotal, currency, baseCurrency)}</span>
          </div>

          {deliveryFee > 0 && (
            <div className="flex justify-between">
              <span>Delivery Fee</span>
              <span className="font-semibold text-slate-900">{formatPrice(deliveryFee, currency, baseCurrency)}</span>
            </div>
          )}

          {codCharge > 0 && (
            <div className="flex justify-between">
              <span>COD Handling Fee</span>
              <span className="font-semibold text-slate-900">{formatPrice(codCharge, currency, baseCurrency)}</span>
            </div>
          )}

          {discountAmount > 0 && (
            <div className="flex justify-between text-emerald-600 font-bold">
              <span>Promo Discount ({order.discountCode || "DISCOUNT"})</span>
              <span>-{formatPrice(discountAmount, currency, baseCurrency)}</span>
            </div>
          )}

          <div className="border-t border-slate-200 pt-3 flex justify-between items-baseline text-sm font-bold">
            <span className="text-slate-900">Grand Total Charged</span>
            <span className="text-2xl font-black text-indigo-600">{formatPrice(totalAmount, currency, baseCurrency)}</span>
          </div>
        </div>
      </div>

      {/* Return Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={() => onNavigate("profile", "orders")}
          className="flex-1 py-3.5 px-6 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs shadow-md transition-colors flex items-center justify-center gap-2"
        >
          <Package className="w-4 h-4" />
          <span>View All Orders in Profile</span>
        </button>
        <button
          onClick={() => onNavigate("categories")}
          className="flex-1 py-3.5 px-6 bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold rounded-xl text-xs border border-slate-300 transition-colors flex items-center justify-center gap-2"
        >
          <span>Continue Shopping</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* Printable Official Receipt Modal */}
      {showReceiptModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white max-w-2xl w-full rounded-3xl shadow-2xl border border-slate-200 overflow-hidden space-y-6 p-6 sm:p-8 relative my-8 print:m-0 print:p-0 print:border-none print:shadow-none">
            {/* Modal Controls Bar (Hidden during printing) */}
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 print:hidden">
              <div className="flex items-center gap-2 font-extrabold text-slate-900 text-sm">
                <FileText className="w-5 h-5 text-indigo-600" />
                <span>Official Sales Invoice & Receipt</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-sm transition-colors flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print Receipt</span>
                </button>
                <button
                  onClick={() => setShowReceiptModal(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Actual Receipt Print Header */}
            <div className="flex justify-between items-start border-b border-slate-200 pb-6">
              <div>
                <h2 className="text-2xl font-black text-slate-900 tracking-tight">VESPO</h2>
                <p className="text-xs text-slate-500 mt-0.5">Official Sales Invoice & E-Receipt</p>
                <span className="inline-block mt-2 text-[10px] font-extrabold uppercase bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full border border-emerald-200">
                  {order.paymentConfirmed ? "Payment Verified" : "Order Confirmed / Pending Payment Audit"}
                </span>
              </div>
              <div className="text-right text-xs">
                <p className="text-slate-500">Order Code:</p>
                <p className="font-mono font-extrabold text-slate-900 text-sm">{order.orderCode}</p>
                <p className="text-slate-500 mt-1">Date Created:</p>
                <p className="font-semibold text-slate-700">{new Date(order.createdAt).toLocaleDateString()}</p>
              </div>
            </div>

            {/* Billed To & Shipped To */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200/80">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">Customer Info</span>
                <p className="font-bold text-slate-900 text-sm">{order.customerName}</p>
                <p className="text-slate-600 font-medium">{order.customerEmail}</p>
                <p className="text-slate-600 font-mono mt-0.5">{order.customerPhone}</p>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">Shipping & Payment</span>
                <p className="text-slate-700 font-medium">{order.shippingAddressText}</p>
                <p className="text-slate-600 font-bold mt-1">Method: {getPaymentMethodLabel()}</p>
                {(order.paymentDetails?.transactionId || order.bankTransactionId) && (
                  <p className="text-slate-500 font-mono text-[11px]">
                    TID: {order.paymentDetails?.transactionId || order.bankTransactionId}
                  </p>
                )}
              </div>
            </div>

            {/* Line Items Table */}
            <div>
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="py-2">Item Description</th>
                    <th className="py-2 text-center">Qty</th>
                    <th className="py-2 text-right">Price</th>
                    <th className="py-2 text-right">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {order.items?.map((item, idx) => (
                    <tr key={idx}>
                      <td className="py-3 font-bold text-slate-900">{item.productTitle}</td>
                      <td className="py-3 text-center text-slate-600">{item.quantity}</td>
                      <td className="py-3 text-right text-slate-600">{formatPrice(item.price, currency)}</td>
                      <td className="py-3 text-right font-bold text-slate-900">{formatPrice(item.quantity * item.price, currency)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Calculation Totals */}
            <div className="border-t border-slate-200 pt-4 space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-slate-900">{formatPrice(subtotal, currency)}</span>
              </div>
              {deliveryFee > 0 && (
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>{formatPrice(deliveryFee, currency)}</span>
                </div>
              )}
              {codCharge > 0 && (
                <div className="flex justify-between">
                  <span>COD Handling Fee</span>
                  <span>{formatPrice(codCharge, currency)}</span>
                </div>
              )}
              {discountAmount > 0 && (
                <div className="flex justify-between text-emerald-600 font-bold">
                  <span>Discount ({order.discountCode || "PROMO"})</span>
                  <span>-{formatPrice(discountAmount, currency)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-extrabold text-slate-900 border-t border-slate-200 pt-3">
                <span>Grand Total</span>
                <span className="text-indigo-600 font-black">{formatPrice(totalAmount, currency)}</span>
              </div>
            </div>

            {/* Footer Disclaimer */}
            <div className="text-[10px] text-slate-400 text-center border-t border-slate-100 pt-4 space-y-1">
              <p>Thank you for shopping with Vespo. This is an official computer-generated sales invoice.</p>
              <p>For any order queries or support, contact support@vespogear.com or call customer helpline.</p>
            </div>
          </div>
        </div>
      )}

      {/* HTML Email Inbox Preview Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white max-w-2xl w-full rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 flex items-center justify-center text-white font-bold">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Dispatched HTML Email Receipt</h3>
                  <p className="text-[11px] text-slate-400">Recipient: {order.customerEmail}</p>
                </div>
              </div>
              <button
                onClick={() => setShowEmailModal(false)}
                className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Email Metadata Bar */}
            <div className="bg-slate-50 p-4 border-b border-slate-200 text-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Subject:</span>
                <span className="font-bold text-slate-900">{emailPreviewData?.subject || `[Order Receipt] #${order.orderCode}`}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500 font-medium">Delivery Engine:</span>
                {emailPreviewData?.isSmtpConfigured ? (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    SMTP Live Mail Server Active
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-900">
                    Test Sandbox Engine (HTML Rendered Below)
                  </span>
                )}
              </div>
              {!emailPreviewData?.isSmtpConfigured && (
                <div className="mt-2 text-[11px] bg-amber-50 text-amber-800 p-2.5 rounded-xl border border-amber-200/70 leading-relaxed">
                  💡 <strong>Why isn't the email appearing in your personal Gmail inbox?</strong><br/>
                  This dev container runs without configured SMTP credentials. To send real emails to your personal inbox, set <code className="font-mono bg-amber-100 px-1 py-0.5 rounded">SMTP_HOST</code> and <code className="font-mono bg-amber-100 px-1 py-0.5 rounded">SMTP_USER</code> in <code className="font-mono">.env</code>. You can inspect the exact HTML email above and below!
                </div>
              )}
            </div>

            {/* Rendered HTML Email Container */}
            <div className="p-6 overflow-y-auto flex-1 bg-slate-100 min-h-[350px]">
              {loadingEmailPreview ? (
                <div className="flex flex-col items-center justify-center py-16 text-slate-500 text-xs space-y-3">
                  <RefreshCw className="w-6 h-6 animate-spin text-indigo-600" />
                  <span>Fetching exact HTML email receipt...</span>
                </div>
              ) : emailPreviewData ? (
                <div
                  className="bg-white rounded-2xl shadow-sm border border-slate-200 p-2 overflow-x-auto"
                  dangerouslySetInnerHTML={{ __html: emailPreviewData.html }}
                />
              ) : (
                <div className="text-center py-12 text-slate-400 text-xs">Failed to load email preview.</div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-white border-t border-slate-100 flex justify-end gap-2">
              <button
                onClick={() => setShowEmailModal(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl"
              >
                Close Preview
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
