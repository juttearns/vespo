import React, { useEffect, useRef, useState } from "react";
import L from "leaflet";
import { MapPin, Navigation, CheckCircle2, AlertTriangle } from "lucide-react";
import { UserLocation } from "../types";

export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 100) / 100;
}

interface MapPickerProps {
  value: UserLocation | null;
  onChange: (loc: UserLocation) => void;
  readOnly?: boolean;
  compareWithGps?: boolean;
  onGpsCheckResult?: (result: { matched: boolean; distanceKm: number; currentGps?: UserLocation }) => void;
  height?: string;
}

export const MapPicker: React.FC<MapPickerProps> = ({
  value,
  onChange,
  readOnly = false,
  compareWithGps = false,
  onGpsCheckResult,
  height = "h-72",
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerInstanceRef = useRef<L.Marker | null>(null);
  const gpsMarkerRef = useRef<L.Marker | null>(null);

  const defaultLocation: UserLocation = { lat: 37.7749, lng: -122.4194 };
  const currentLocation = value || defaultLocation;

  const [loadingGps, setLoadingGps] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [currentGps, setCurrentGps] = useState<UserLocation | null>(null);
  const [distance, setDistance] = useState<number | null>(null);

  // Custom Icon Fix for Leaflet in React
  const pinIcon = L.divIcon({
    className: "custom-map-pin",
    html: `<div class="bg-indigo-600 text-white p-2 rounded-full shadow-lg flex items-center justify-center border-2 border-white ring-4 ring-indigo-500/30 transform -translate-x-1/2 -translate-y-full">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
           </div>`,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
  });

  const gpsIcon = L.divIcon({
    className: "custom-gps-pin",
    html: `<div class="bg-emerald-500 text-white p-1.5 rounded-full shadow-md border-2 border-white ring-2 ring-emerald-400/40 animate-pulse">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="m12 2 3 6-3 4-3-4 3-6Z"/></svg>
           </div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });

  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current).setView(
        [currentLocation.lat, currentLocation.lng],
        13
      );

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);

      const marker = L.marker([currentLocation.lat, currentLocation.lng], {
        icon: pinIcon,
        draggable: !readOnly,
      }).addTo(map);

      if (!readOnly) {
        marker.on("dragend", () => {
          const latLng = marker.getLatLng();
          const newLoc = { lat: latLng.lat, lng: latLng.lng };
          onChange(newLoc);
        });

        map.on("click", (e: L.LeafletMouseEvent) => {
          const newLoc = { lat: e.latlng.lat, lng: e.latlng.lng };
          marker.setLatLng([newLoc.lat, newLoc.lng]);
          onChange(newLoc);
        });
      }

      mapInstanceRef.current = map;
      markerInstanceRef.current = marker;
    } else {
      mapInstanceRef.current.setView([currentLocation.lat, currentLocation.lng]);
      if (markerInstanceRef.current) {
        markerInstanceRef.current.setLatLng([currentLocation.lat, currentLocation.lng]);
      }
    }
  }, [currentLocation.lat, currentLocation.lng, readOnly]);

  const handleGetGpsLocation = () => {
    if (!navigator.geolocation) {
      setGpsError("Geolocation is not supported by your browser.");
      return;
    }

    setLoadingGps(true);
    setGpsError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLoadingGps(false);
        const gpsLoc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setCurrentGps(gpsLoc);

        if (!readOnly) {
          onChange(gpsLoc);
        }

        if (mapInstanceRef.current) {
          mapInstanceRef.current.setView([gpsLoc.lat, gpsLoc.lng], 15);
          if (markerInstanceRef.current) {
            markerInstanceRef.current.setLatLng([gpsLoc.lat, gpsLoc.lng]);
          }
        }

        if (value) {
          const dist = calculateDistanceKm(gpsLoc.lat, gpsLoc.lng, value.lat, value.lng);
          setDistance(dist);
          const matched = dist < 2.0; // matched within 2km tolerance
          if (onGpsCheckResult) {
            onGpsCheckResult({ matched, distanceKm: dist, currentGps: gpsLoc });
          }
        }
      },
      (err) => {
        setLoadingGps(false);
        setGpsError(`Unable to retrieve GPS: ${err.message}. Defaulting to map selection.`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  useEffect(() => {
    if (compareWithGps && !currentGps) {
      handleGetGpsLocation();
    }
  }, [compareWithGps]);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
          <MapPin className="w-4 h-4 text-indigo-600" />
          <span>
            Pin Coordinates: {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
          </span>
        </div>

        {!readOnly && (
          <button
            type="button"
            onClick={handleGetGpsLocation}
            disabled={loadingGps}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors border border-indigo-200"
          >
            <Navigation className={`w-3.5 h-3.5 ${loadingGps ? "animate-spin" : ""}`} />
            {loadingGps ? "Detecting GPS..." : "Set Pin via Device GPS"}
          </button>
        )}
      </div>

      {gpsError && (
        <div className="p-2.5 text-xs text-amber-800 bg-amber-50 rounded-lg border border-amber-200 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{gpsError}</span>
        </div>
      )}

      {/* Map Container */}
      <div className={`relative ${height} w-full rounded-xl overflow-hidden border border-slate-200 shadow-inner z-0`}>
        <div ref={mapContainerRef} className="w-full h-full z-0" />
      </div>

      {/* GPS Cross-Check Notice */}
      {distance !== null && (
        <div
          className={`p-3 text-xs rounded-xl border flex items-start gap-2.5 ${
            distance < 2.0
              ? "bg-emerald-50 border-emerald-200 text-emerald-900"
              : "bg-amber-50 border-amber-200 text-amber-900"
          }`}
        >
          {distance < 2.0 ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          )}
          <div>
            <p className="font-bold">
              {distance < 2.0
                ? "GPS Location Confirmed!"
                : "Location Difference Detected"}
            </p>
            <p className="mt-0.5 text-slate-600">
              {distance < 2.0
                ? `Your current GPS matches your delivery pin (${distance} km distance).`
                : `Your device GPS is ${distance} km away from your saved delivery pin. Please verify your address pin so your courier delivers to the right location.`}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
