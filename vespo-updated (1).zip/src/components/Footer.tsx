import React from "react";
import { Shield, Truck, RefreshCw, Headphones, MapPin } from "lucide-react";
import { StoreInfo } from "../types";

interface FooterProps {
  storeInfo: StoreInfo;
  onNavigate: (view: string, param?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ storeInfo, onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800">
      {/* Value Proposition Badges Bar */}
      <div className="border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-400 shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Fast Dispatch</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">GPS verified pin delivery</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-400 shrink-0">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Verified Checkout</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">COD & Direct Bank Transfer</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-400 shrink-0">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Hassle-Free Returns</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Managed via Support Desk</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-400 shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Help & Support</h4>
              <p className="text-[11px] text-slate-400 mt-0.5">Direct ticket response portal</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Summary */}
        <div className="space-y-4 md:col-span-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white font-black text-base flex items-center justify-center">
              V
            </div>
            <span className="text-xl font-extrabold text-white tracking-tight">
              {storeInfo.storeName || "Vespo"}
            </span>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed">
            {storeInfo.tagline || "Elevated Daily Essentials & Modern Lifestyle Goods"}
          </p>
          <div className="text-xs text-slate-400 space-y-1">
            <p className="flex items-center gap-1.5">
              <span className="font-semibold text-slate-300">Email:</span> {storeInfo.supportEmail}
            </p>
            <p className="flex items-center gap-1.5">
              <span className="font-semibold text-slate-300">Phone:</span> {storeInfo.supportPhone}
            </p>
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">Storefront</h4>
          <ul className="space-y-2.5 text-xs text-slate-400">
            <li>
              <button onClick={() => onNavigate("home")} className="hover:text-white transition-colors">
                Home Catalog
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("categories")} className="hover:text-white transition-colors">
                All Products
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("cart")} className="hover:text-white transition-colors">
                Shopping Cart
              </button>
            </li>
          </ul>
        </div>

        {/* Account & Support */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">Customer Account</h4>
          <ul className="space-y-2.5 text-xs text-slate-400">
            <li>
              <button onClick={() => onNavigate("profile", "orders")} className="hover:text-white transition-colors">
                My Orders & Tracking
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("profile", "wishlist")} className="hover:text-white transition-colors">
                Saved Wishlist
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("profile", "address")} className="hover:text-white transition-colors">
                Delivery Address & GPS Pin
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("profile", "help")} className="hover:text-white transition-colors">
                Support Tickets & Help Form
              </button>
            </li>
          </ul>
        </div>

        {/* Policies */}
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200 mb-4">Legal & Information</h4>
          <ul className="space-y-2.5 text-xs text-slate-400">
            <li>
              <button onClick={() => onNavigate("policies")} className="hover:text-white transition-colors">
                Privacy Policy
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("policies")} className="hover:text-white transition-colors">
                Shipping & Verification
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("policies")} className="hover:text-white transition-colors">
                Returns & Refund Policy
              </button>
            </li>
            <li>
              <button onClick={() => onNavigate("policies")} className="hover:text-white transition-colors">
                Terms of Service
              </button>
            </li>
          </ul>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-slate-800/60 py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>&copy; {new Date().getFullYear()} {storeInfo.storeName || "Vespo"} Inc. All rights reserved.</p>
          <p className="text-slate-400 text-[11px]">
            Mobile-First E-Commerce Architecture
          </p>
        </div>
      </div>
    </footer>
  );
};
