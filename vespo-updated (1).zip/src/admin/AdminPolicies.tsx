import React, { useState, useEffect } from "react";
import { Policies } from "../types";
import { api } from "../services/api";
import { Save, CheckCircle2, ShieldCheck, Truck, RefreshCw, FileText } from "lucide-react";

export const AdminPolicies: React.FC = () => {
  const [policies, setPolicies] = useState<Policies>({
    privacyPolicy: "",
    shippingPolicy: "",
    returnPolicy: "",
    termsOfService: "",
    updatedAt: "",
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    api.getPolicies()
      .then(res => setPolicies(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setNotice(null);
    try {
      const res = await api.updatePolicies(policies);
      setPolicies(res.policies);
      setNotice("Legal policies updated successfully!");
      setTimeout(() => setNotice(null), 3000);
    } catch (err: any) {
      setNotice("Error updating policies: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-xs text-slate-400">Loading store policies...</div>;
  }

  return (
    <div className="max-w-4xl space-y-6 pb-12">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Legal Policies & Terms Editor</h1>
        <p className="text-xs text-slate-500 mt-0.5">Edit store policies live for customer review on storefront footer links.</p>
      </div>

      {notice && (
        <div className="p-4 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-2xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>Privacy Policy</span>
          </h3>
          <textarea
            rows={4}
            value={policies.privacyPolicy}
            onChange={(e) => setPolicies({ ...policies, privacyPolicy: e.target.value })}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 leading-relaxed"
          />
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <Truck className="w-4 h-4 text-indigo-600" />
            <span>Shipping & GPS Cross-Check Policy</span>
          </h3>
          <textarea
            rows={4}
            value={policies.shippingPolicy}
            onChange={(e) => setPolicies({ ...policies, shippingPolicy: e.target.value })}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 leading-relaxed"
          />
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <RefreshCw className="w-4 h-4 text-indigo-600" />
            <span>Returns & Refund Policy</span>
          </h3>
          <textarea
            rows={4}
            value={policies.returnPolicy}
            onChange={(e) => setPolicies({ ...policies, returnPolicy: e.target.value })}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 leading-relaxed"
          />
        </div>

        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-600" />
            <span>Terms of Service</span>
          </h3>
          <textarea
            rows={4}
            value={policies.termsOfService}
            onChange={(e) => setPolicies({ ...policies, termsOfService: e.target.value })}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900 leading-relaxed"
          />
        </div>

        <button
          type="submit"
          disabled={saving}
          className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-lg transition-colors flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? "Saving..." : "Save Policy Documents"}</span>
        </button>
      </form>
    </div>
  );
};
