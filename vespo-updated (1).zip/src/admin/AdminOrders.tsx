import React, { useState } from "react";
import { Order } from "../types";
import { api } from "../services/api";
import { MapPin, CheckCircle2, Clock, AlertTriangle, Search, Filter, ShieldCheck, CreditCard, Banknote } from "lucide-react";
import { formatPrice } from "../utils/currency";

interface AdminOrdersProps {
  orders: Order[];
  onRefresh: () => void;
  currency?: string;
  baseCurrency?: string;
}

export const AdminOrders: React.FC<AdminOrdersProps> = ({
  orders,
  onRefresh,
  currency = "PKR",
  baseCurrency = "PKR",
}) => {
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const filteredOrders = orders.filter((ord) => {
    const matchesStatus = filterStatus === "all" || ord.status === filterStatus;
    const matchesSearch =
      ord.orderCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ord.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ord.customerEmail.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const handleUpdateStatus = async (orderId: string, newStatus: string, paymentConfirmed?: boolean) => {
    setUpdatingId(orderId);
    try {
      await api.updateOrderStatus(orderId, newStatus, paymentConfirmed);
      onRefresh();
    } catch (err: any) {
      alert("Failed to update status: " + err.message);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleConfirmPayment = async (order: Order) => {
    setUpdatingId(order.id);
    try {
      await api.updateOrderStatus(order.id, order.status, true);
      onRefresh();
    } catch (err: any) {
      alert("Failed to confirm payment: " + err.message);
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Order Fulfillment & GPS Audit</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Verify manual bank transfers, cross-check GPS pins & manage live fulfillment pipeline.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search order #, customer..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900"
            />
          </div>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 bg-white border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-slate-900"
          >
            <option value="all">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
          </select>
        </div>
      </div>

      {filteredOrders.length === 0 ? (
        <div className="p-12 bg-white rounded-3xl border border-dashed border-slate-200 text-center text-xs text-slate-400">
          No orders match your filter criteria.
        </div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((ord) => (
            <div
              key={ord.id}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4 hover:border-slate-300 transition-colors"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm font-extrabold text-slate-900">{ord.orderCode}</span>
                    <span className={`px-2.5 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-wider ${
                      ord.status === "delivered"
                        ? "bg-emerald-100 text-emerald-800"
                        : ord.status === "shipped"
                        ? "bg-indigo-100 text-indigo-800"
                        : "bg-amber-100 text-amber-800"
                    }`}>
                      {ord.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Customer: <strong className="text-slate-900 font-semibold">{ord.customerName}</strong> ({ord.customerEmail})
                    &bull; {new Date(ord.createdAt).toLocaleString()}
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  <span className="font-extrabold text-slate-900 text-base mr-2">
                    {formatPrice(ord.totalAmount, currency, baseCurrency)}
                  </span>
                  
                  {/* Status Dropdown */}
                  <select
                    disabled={updatingId === ord.id}
                    value={ord.status}
                    onChange={(e) => handleUpdateStatus(ord.id, e.target.value)}
                    className="px-3 py-1.5 bg-slate-900 text-white font-bold rounded-xl focus:outline-none text-xs"
                  >
                    <option value="pending">Mark Pending</option>
                    <option value="processing">Mark Processing</option>
                    <option value="shipped">Mark Shipped</option>
                    <option value="delivered">Mark Delivered</option>
                    <option value="cancelled">Mark Cancelled</option>
                  </select>
                </div>
              </div>

              {/* Grid Details: GPS Pin + Payment Audit + Items */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
                {/* 1. Address & GPS Verification */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/60 space-y-2">
                  <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4 text-slate-700" />
                    <span>GPS Verification & Shipping</span>
                  </h4>
                  <p className="text-slate-700 leading-relaxed">{ord.shippingAddressText}</p>

                  <div className="pt-2 border-t border-slate-200/80">
                    {ord.gpsCheck?.matched ? (
                      <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-[11px]">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>GPS Pin Verified (~{ord.gpsCheck.distanceKm?.toFixed(2)} km)</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-1.5 text-amber-700 font-bold text-[11px]">
                        <AlertTriangle className="w-4 h-4 text-amber-600" />
                        <span>Distance alert (~{ord.gpsCheck?.distanceKm?.toFixed(2)} km)</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* 2. Payment Audit & Manual Bank Transfer */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/60 space-y-2">
                  <h4 className="font-extrabold text-slate-900 flex items-center gap-1.5">
                    {ord.paymentMethod === "cod" ? (
                      <Banknote className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <CreditCard className="w-4 h-4 text-indigo-600" />
                    )}
                    <span>Payment Verification</span>
                  </h4>

                  <p className="text-slate-700">
                    Method: <strong className="font-semibold">{ord.paymentMethod === "cod" ? "Cash on Delivery" : "Manual Bank Transfer"}</strong>
                  </p>

                  {ord.paymentMethod === "bank_transfer" && (
                    <div className="p-2.5 bg-white rounded-xl border border-slate-200 font-mono text-[11px] text-slate-800">
                      Txn ID: <strong>{ord.bankTransactionId || "Not Provided"}</strong>
                    </div>
                  )}

                  <div className="pt-1 flex items-center justify-between">
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                      ord.paymentConfirmed ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"
                    }`}>
                      {ord.paymentConfirmed ? "Payment Verified" : "Unverified Payment"}
                    </span>

                    {!ord.paymentConfirmed && (
                      <button
                        onClick={() => handleConfirmPayment(ord)}
                        disabled={updatingId === ord.id}
                        className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold text-[10px] transition-colors"
                      >
                        Verify Payment Now
                      </button>
                    )}
                  </div>
                </div>

                {/* 3. Items Summary */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/60 space-y-2">
                  <h4 className="font-extrabold text-slate-900">Ordered Items ({ord.items?.length})</h4>
                  <div className="space-y-1.5 max-h-28 overflow-y-auto pr-1">
                    {ord.items?.map((item, idx) => (
                      <div key={idx} className="flex justify-between text-slate-700 text-[11px]">
                        <span className="truncate pr-2">{item.quantity}x {item.productTitle}</span>
                        <span className="font-bold text-slate-900">{formatPrice(item.quantity * item.price, currency, baseCurrency)}</span>
                      </div>
                    ))}
                  </div>

                  {ord.discountCode && (
                    <div className="pt-1 text-[11px] text-slate-500 font-medium border-t border-slate-200">
                      Discount applied: <span className="font-mono text-slate-900">{ord.discountCode}</span> (-{formatPrice(ord.discountAmount, currency, baseCurrency)})
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
