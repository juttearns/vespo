import React, { useState } from "react";
import { StoreInfo } from "../types";
import { api } from "../services/api";
import { CURRENCIES } from "../utils/currency";
import { Save, CheckCircle2, Sparkles, CreditCard, Image as ImageIcon, Smartphone, DollarSign } from "lucide-react";

interface AdminStoreInfoProps {
  storeInfo: StoreInfo;
  onRefreshStoreInfo: () => void;
}

export const AdminStoreInfo: React.FC<AdminStoreInfoProps> = ({ storeInfo, onRefreshStoreInfo }) => {
  const [formData, setFormData] = useState<StoreInfo>(storeInfo);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [seeding, setSeeding] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setNotice(null);

    try {
      await api.updateStoreInfo(formData);
      localStorage.setItem("vespo_store_info", JSON.stringify(formData));
      onRefreshStoreInfo();
      setNotice("Store settings and details updated live!");
      setTimeout(() => setNotice(null), 3000);
    } catch (err: any) {
      setNotice("Failed to update store settings: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleSeedDemoData = async () => {
    if (!window.confirm("Seed sample products, categories, and discount codes into catalog?")) return;
    setSeeding(true);
    try {
      await api.seedDemoCatalog();
      onRefreshStoreInfo();
      setNotice("Sample products catalog seeded successfully!");
      setTimeout(() => setNotice(null), 4000);
    } catch (err: any) {
      setNotice("Error seeding data: " + err.message);
    } finally {
      setSeeding(false);
    }
  };

  return (
    <div className="max-w-4xl space-y-8 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Store Info & Branding Editor</h1>
          <p className="text-xs text-slate-500 mt-1">
            Edits saved here reflect immediately across the customer storefront.
          </p>
        </div>

        <button
          type="button"
          onClick={handleSeedDemoData}
          disabled={seeding}
          className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl border border-indigo-200 transition-colors flex items-center gap-1.5"
        >
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <span>{seeding ? "Seeding..." : "Seed Demo Products Catalog"}</span>
        </button>
      </div>

      {notice && (
        <div className="p-4 bg-emerald-50 text-emerald-900 border border-emerald-200 rounded-2xl text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6 text-xs">
        {/* Section 1: General Branding */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900">General Brand Details</h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Store Name</label>
              <input
                type="text"
                value={formData.storeName}
                onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Tagline</label>
              <input
                type="text"
                value={formData.tagline}
                onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Support Email</label>
              <input
                type="email"
                value={formData.supportEmail}
                onChange={(e) => setFormData({ ...formData, supportEmail: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Support Phone</label>
              <input
                type="text"
                value={formData.supportPhone}
                onChange={(e) => setFormData({ ...formData, supportPhone: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Section: Store Base Pricing Currency */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            <span>Store Base Pricing Currency</span>
          </h3>
          <p className="text-xs text-slate-500">
            Set the official base currency for entering product prices in your store catalog. Prices will automatically convert into customer preferred currencies on storefront browsing.
          </p>

          <div className="max-w-md">
            <label className="block font-semibold text-slate-700 mb-1">Admin Catalog Base Currency</label>
            <select
              value={formData.baseCurrency || "PKR"}
              onChange={(e) => setFormData({ ...formData, baseCurrency: e.target.value })}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              {Object.values(CURRENCIES).map((c) => (
                <option key={c.code} value={c.code}>
                  {c.code} ({c.symbol.trim()}) — {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Section 2: Storefront Banner & Hero Media */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <ImageIcon className="w-4 h-4 text-indigo-600" />
            <span>Hero Banner Content & Media</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Hero Title</label>
              <input
                type="text"
                value={formData.bannerTitle}
                onChange={(e) => setFormData({ ...formData, bannerTitle: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Hero Subtitle</label>
              <input
                type="text"
                value={formData.bannerSubtitle}
                onChange={(e) => setFormData({ ...formData, bannerSubtitle: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block font-semibold text-slate-700 mb-1">Hero Banner Image URL</label>
              <input
                type="url"
                value={formData.heroImageUrl}
                onChange={(e) => setFormData({ ...formData, heroImageUrl: e.target.value })}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-[11px]"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Delivery Fees & Manual Bank Transfer Details */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-emerald-600" />
            <span>Delivery Fees & Bank Transfer Details</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block font-semibold text-slate-700 mb-1">Standard Delivery Fee ($)</label>
              <input
                type="number"
                step="0.01"
                value={formData.deliveryFee}
                onChange={(e) => setFormData({ ...formData, deliveryFee: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">COD Option Extra Fee ($)</label>
              <input
                type="number"
                step="0.01"
                value={formData.codFee}
                onChange={(e) => setFormData({ ...formData, codFee: Number(e.target.value) })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Bank Name</label>
              <input
                type="text"
                value={formData.bankName}
                onChange={(e) => setFormData({ ...formData, bankName: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Account Holder Name</label>
              <input
                type="text"
                value={formData.accountName}
                onChange={(e) => setFormData({ ...formData, accountName: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">Account Number</label>
              <input
                type="text"
                value={formData.accountNumber}
                onChange={(e) => setFormData({ ...formData, accountNumber: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 mb-1">IBAN / Routing Code</label>
              <input
                type="text"
                value={formData.ibanRouting}
                onChange={(e) => setFormData({ ...formData, ibanRouting: e.target.value })}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Section 3B: JazzCash & EasyPaisa Mobile Wallets */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-red-600" />
            <span>JazzCash & EasyPaisa Mobile Wallet Details</span>
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-red-50/60 p-4 rounded-2xl border border-red-100 space-y-3">
              <span className="font-bold text-red-900 flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-red-600"></span>
                JazzCash Account Settings
              </span>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">JazzCash Account Title</label>
                <input
                  type="text"
                  value={formData.jazzCashTitle || ""}
                  onChange={(e) => setFormData({ ...formData, jazzCashTitle: e.target.value })}
                  placeholder="e.g. Vespo Store (JazzCash)"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">JazzCash Mobile / Till Number</label>
                <input
                  type="text"
                  value={formData.jazzCashNumber || ""}
                  onChange={(e) => setFormData({ ...formData, jazzCashNumber: e.target.value })}
                  placeholder="e.g. 0300-1234567"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 font-mono"
                />
              </div>
            </div>

            <div className="bg-emerald-50/60 p-4 rounded-2xl border border-emerald-100 space-y-3">
              <span className="font-bold text-emerald-900 flex items-center gap-1.5 text-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                EasyPaisa Account Settings
              </span>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">EasyPaisa Account Title</label>
                <input
                  type="text"
                  value={formData.easyPaisaTitle || ""}
                  onChange={(e) => setFormData({ ...formData, easyPaisaTitle: e.target.value })}
                  placeholder="e.g. Vespo Store (EasyPaisa)"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 mb-1">EasyPaisa Mobile / Till Number</label>
                <input
                  type="text"
                  value={formData.easyPaisaNumber || ""}
                  onChange={(e) => setFormData({ ...formData, easyPaisaNumber: e.target.value })}
                  placeholder="e.g. 0345-7654321"
                  className="w-full px-3.5 py-2.5 bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 font-mono"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Section 4: OAuth Integration Point */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
          <h3 className="text-sm font-extrabold text-slate-900">Google OAuth Client Integration</h3>
          <div>
            <label className="block font-semibold text-slate-700 mb-1">Google OAuth Client ID</label>
            <input
              type="text"
              value={formData.googleClientId}
              onChange={(e) => setFormData({ ...formData, googleClientId: e.target.value })}
              placeholder="e.g. 1234567890-abc123def456.apps.googleusercontent.com"
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-[11px]"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Used by the storefront "Continue with Google" auth button.
            </p>
          </div>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow-lg transition-colors flex items-center gap-2"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? "Saving Changes..." : "Save All Store Settings"}</span>
        </button>
      </form>
    </div>
  );
};
