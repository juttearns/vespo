import React, { useState, useEffect } from "react";
import { Tag, Plus, Trash2, CheckCircle2, Ticket, Percent, DollarSign } from "lucide-react";
import { DiscountCode } from "../types";
import { api } from "../services/api";
import { formatPrice } from "../utils/currency";

interface AdminOffersProps {
  currency?: string;
  baseCurrency?: string;
}

export const AdminOffers: React.FC<AdminOffersProps> = ({ currency = "PKR", baseCurrency = "PKR" }) => {
  const [discounts, setDiscounts] = useState<DiscountCode[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);

  // Form state
  const [code, setCode] = useState("");
  const [discountType, setDiscountType] = useState<"percentage" | "fixed">("percentage");
  const [value, setValue] = useState("");
  const [minPurchase, setMinPurchase] = useState("");
  const [saving, setSaving] = useState(false);

  const fetchDiscounts = async () => {
    try {
      const res = await api.getDiscounts();
      setDiscounts(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDiscounts();
  }, []);

  const handleCreateDiscount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!code.trim() || !value) return;

    setSaving(true);
    try {
      await api.createDiscount({
        code: code.trim().toUpperCase(),
        discountType,
        value: parseFloat(value),
        minPurchase: minPurchase ? parseFloat(minPurchase) : 0,
        isActive: true,
      });
      setCode("");
      setValue("");
      setMinPurchase("");
      setModalOpen(false);
      fetchDiscounts();
    } catch (err: any) {
      alert("Failed to create coupon: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteDiscount = async (id: string) => {
    if (!window.confirm("Delete this coupon code?")) return;
    try {
      await api.deleteDiscount(id);
      fetchDiscounts();
    } catch (err: any) {
      alert("Error deleting coupon: " + err.message);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Promotional Offers & Coupons</h1>
          <p className="text-xs text-slate-500 mt-0.5">Create and manage discount codes, percentage cuts, and minimum thresholds.</p>
        </div>

        <button
          onClick={() => setModalOpen(true)}
          className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow transition-colors flex items-center gap-1.5"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Promo Code</span>
        </button>
      </div>

      {loading ? (
        <div className="p-8 text-center text-xs text-slate-400">Loading active promo codes...</div>
      ) : discounts.length === 0 ? (
        <div className="p-12 bg-white rounded-3xl border border-dashed border-slate-200 text-center space-y-3">
          <Tag className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No Active Promo Codes</h3>
          <p className="text-xs text-slate-500">Click "Create New Promo Code" above to launch a promotion.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {discounts.map((disc) => (
            <div
              key={disc.id}
              className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-sm space-y-3 flex flex-col justify-between"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold text-xs">
                    {disc.discountType === "percentage" ? "%" : "Rs"}
                  </div>
                  <div>
                    <span className="font-mono font-extrabold text-sm text-slate-900 tracking-wider">
                      {disc.code}
                    </span>
                    <p className="text-[10px] text-slate-400">Used {disc.timesUsed || 0} times</p>
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteDiscount(disc.id)}
                  className="p-1 text-slate-400 hover:text-rose-600 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-1 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Discount Value:</span>
                  <strong className="text-slate-900 font-extrabold">
                    {disc.discountType === "percentage" ? `${disc.value}% OFF` : `${formatPrice(disc.value, currency, baseCurrency)} OFF`}
                  </strong>
                </div>
                {disc.minPurchase ? (
                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>Min Purchase:</span>
                    <span>{formatPrice(disc.minPurchase, currency, baseCurrency)}</span>
                  </div>
                ) : null}
              </div>

              <div className="pt-2">
                <span className="inline-block px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full">
                  Active Code
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal: Create Discount */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white max-w-md w-full rounded-3xl p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-extrabold text-slate-900">Create New Coupon Code</h3>

            <form onSubmit={handleCreateDiscount} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Coupon Code</label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="e.g. VESPO20"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-mono uppercase focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Discount Type</label>
                  <select
                    value={discountType}
                    onChange={(e) => setDiscountType(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  >
                    <option value="percentage">Percentage (%)</option>
                    <option value="fixed">Fixed Amount ($)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold mb-1">Value</label>
                  <input
                    type="number"
                    step="0.01"
                    value={value}
                    onChange={(e) => setValue(e.target.value)}
                    placeholder={discountType === "percentage" ? "15" : "10.00"}
                    required
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Minimum Purchase Requirement ($)</label>
                <input
                  type="number"
                  step="0.01"
                  value={minPurchase}
                  onChange={(e) => setMinPurchase(e.target.value)}
                  placeholder="Optional (e.g. 50.00)"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div className="pt-3 flex gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl shadow"
                >
                  {saving ? "Saving..." : "Create Coupon"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
