import React, { useState, useEffect } from "react";
import { MessageSquare, Send, CheckCircle2, Clock, User } from "lucide-react";
import { Ticket } from "../types";
import { api } from "../services/api";

export const AdminTickets: React.FC = () => {
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [replyText, setReplyText] = useState<{ [ticketId: string]: string }>({});
  const [replyingId, setReplyingId] = useState<string | null>(null);

  const fetchTickets = async () => {
    try {
      const res = await api.getTickets();
      setTickets(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleAdminReply = async (ticketId: string) => {
    const text = replyText[ticketId];
    if (!text || !text.trim()) return;

    setReplyingId(ticketId);
    try {
      await api.replyTicket(ticketId, text.trim(), "admin", "Support Desk Admin");
      setReplyText({ ...replyText, [ticketId]: "" });
      fetchTickets();
    } catch (err: any) {
      alert("Failed to send reply: " + err.message);
    } finally {
      setReplyingId(null);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Support Tickets Help Desk</h1>
        <p className="text-xs text-slate-500 mt-0.5">Answer customer inquiries and track support resolution history.</p>
      </div>

      {loading ? (
        <div className="p-8 text-center text-xs text-slate-400">Loading support ticket threads...</div>
      ) : tickets.length === 0 ? (
        <div className="p-12 bg-white rounded-3xl border border-dashed border-slate-200 text-center space-y-3">
          <MessageSquare className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No Customer Tickets</h3>
          <p className="text-xs text-slate-500">When customers submit tickets from Profile or Help center, they display here.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {tickets.map((tkt) => (
            <div
              key={tkt.id}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider bg-indigo-50 px-2 py-0.5 rounded-full">
                      {tkt.category}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900">{tkt.subject}</h3>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    From: <strong className="text-slate-800">{tkt.customerName}</strong> ({tkt.customerEmail})
                  </p>
                </div>

                <span className={`px-2.5 py-1 text-[10px] font-bold rounded-full w-fit ${
                  tkt.status === "replied"
                    ? "bg-emerald-100 text-emerald-800"
                    : tkt.status === "open"
                    ? "bg-amber-100 text-amber-800"
                    : "bg-slate-100 text-slate-600"
                }`}>
                  {tkt.status === "replied" ? "Admin Replied" : tkt.status}
                </span>
              </div>

              {/* Message Thread */}
              <div className="space-y-3 pl-3 border-l-2 border-slate-200 text-xs">
                {tkt.messages?.map((msg) => (
                  <div key={msg.id} className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${msg.senderRole === "admin" ? "text-indigo-600" : "text-slate-900"}`}>
                        {msg.senderName} ({msg.senderRole === "admin" ? "Admin Support" : "Customer"})
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(msg.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="p-3 bg-slate-50 rounded-xl text-slate-700 leading-relaxed border border-slate-100">
                      {msg.message}
                    </p>
                  </div>
                ))}
              </div>

              {/* Admin Reply Box */}
              <div className="pt-2 flex gap-2 text-xs">
                <input
                  type="text"
                  placeholder="Type an official admin response..."
                  value={replyText[tkt.id] || ""}
                  onChange={(e) => setReplyText({ ...replyText, [tkt.id]: e.target.value })}
                  className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
                <button
                  onClick={() => handleAdminReply(tkt.id)}
                  disabled={replyingId === tkt.id}
                  className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-colors flex items-center gap-1.5"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Reply</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
