-- ============================================================
-- VESPO — Backfill fake reviews for EXISTING products
-- Run this once in Supabase SQL Editor, AFTER supabase_migration_reviews.sql
-- Only touches products that currently have zero reviews — safe to
-- re-run any time you add more products without reviews yet.
-- ============================================================

do $$
declare
  prod record;
  names text[] := array[
    'Ahmed Raza','Fatima Khan','Bilal Hussain','Ayesha Siddiqui','Usman Tariq',
    'Sana Malik','Hassan Sheikh','Zainab Chaudhry','Imran Baig','Mahnoor Iqbal',
    'Kashif Javed','Rabia Yousaf','Faizan Qureshi','Nida Aslam','Waqas Ahmed',
    'Sadia Pervez','Adeel Mirza','Hira Farooq','Junaid Butt','Mehwish Riaz',
    'Tayyab Shah','Amna Latif','Shoaib Anwar','Komal Nawaz'
  ];
  texts_good text[] := array[
    'Order time pe pohunch gaya, quality bhi achi thi. Recommended!',
    'Bilkul original product tha jaisa dikhaya gaya tha. Packaging bhi solid thi.',
    'First time order kiya Vespo se, experience acha raha. Dubara order karunga.',
    'Product as described tha, customer service ne bhi jaldi respond kiya.',
    'Delivery fast thi aur packaging bhi neat. Will buy again.',
    'Bohat acha laga, family ke liye order kiya tha sab ne pasand kiya.',
    'Honestly quality expectations se better nikli. Thanks Vespo team.',
    'COD option ki wja se order karna asaan hua, delivery bhi time pe hui.',
    'Website use karna easy tha aur tracking bhi clear thi.',
    'Vespo se pehli dafa order kiya aur bilkul satisfied hoon.',
    'Great service, order 3 din mein mil gaya.',
    'Packaging bohat mazboot thi, kuch damage nahi hua raste mein.',
    'Product genuine laga, price bhi reasonable hai market ke hisab se.',
    'Customer support responsive tha jab maine sawal poocha tha.',
    'Overall achi purchase thi, worth the money.',
    'Bahut zabardast, bilkul wesa hi jaisa photo mein tha.',
    'Value for money hai, aur baar baar order karunga is store se.',
    'Neat packaging aur quick response, acha tajurba raha.',
    'Quality bohat achi hai is price range mein, khush hoon.',
    'Sab kuch theek time pe mila, koi shikayat nahi.'
  ];
  texts_mixed text[] := array[
    'Quality achi hai lekin size thora tight nikla, next time ek size bara lunga.',
    'Product ok tha, packaging kholte waqt halki si scratch thi warna sab theek.',
    'Thora expensive laga par quality dekh kar sahi lagta hai.',
    'Delivery thori late hui warna baaki sab perfect tha.',
    'Thik thak product hai, kuch khaas nahi lekin price ke hisab se sahi hai.'
  ];
  review_count int;
  i int;
  pick_name text;
  pick_rating int;
  roll numeric;
begin
  for prod in
    select p.id from public.products p
    left join public.reviews r on r.product_id = p.id
    group by p.id
    having count(r.id) = 0
  loop
    review_count := 3 + floor(random() * 3)::int; -- 3 to 5

    for i in 1..review_count loop
      pick_name := names[1 + floor(random() * array_length(names,1))::int];
      roll := random();
      pick_rating := case when roll < 0.08 then 3 when roll < 0.45 then 4 else 5 end;

      insert into public.reviews (product_id, customer_name, rating, comment, is_seeded, created_at)
      values (
        prod.id,
        pick_name,
        pick_rating,
        case when pick_rating <= 3
          then texts_mixed[1 + floor(random() * array_length(texts_mixed,1))::int]
          else texts_good[1 + floor(random() * array_length(texts_good,1))::int]
        end,
        true,
        now() - (floor(random() * 75) || ' days')::interval - (floor(random() * 720) || ' minutes')::interval
      );
    end loop;

    update public.products
    set seeded_order_count = 25 + floor(random() * 140)::int
    where id = prod.id and seeded_order_count = 0;
  end loop;
end $$;
