-- ============================================================
-- VESPO — Restrict reviews to verified purchasers
-- Run this once in Supabase SQL Editor (after the reviews tables exist).
-- Admin can still insert seeded reviews; a real customer can only
-- insert a review for a product they have an order for.
-- ============================================================

drop policy if exists "reviews_insert" on public.reviews;

create policy "reviews_insert" on public.reviews
  for insert with check (
    public.is_admin()
    or (
      auth.uid() = customer_id
      and exists (
        select 1
        from public.orders o
        where o.customer_id = auth.uid()
          and o.status <> 'cancelled'
          and exists (
            select 1
            from jsonb_array_elements(o.items) elem
            where elem->>'productId' = reviews.product_id::text
          )
      )
    )
  );
