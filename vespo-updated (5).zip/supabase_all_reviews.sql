-- ============================================================
-- VESPO — Reviews & Ratings: full setup (run this whole file once)
-- Project > SQL Editor > New query > paste this whole file > Run
-- Safe to run on the existing database — only adds new things.
--
-- PART 1 — creates reviews/site_reviews tables + seeds testimonials
-- PART 2 — backfills 3-5 fake reviews onto every existing product
-- ============================================================

-- "X people ordered this" counter shown on the product page
alter table public.products add column if not exists seeded_order_count int not null default 0;

-- ------------------------------------------------------------
-- PRODUCT REVIEWS
-- ------------------------------------------------------------
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  customer_id uuid references public.profiles(id) on delete set null,
  customer_name text not null,
  rating int not null check (rating between 1 and 5),
  comment text not null default '',
  is_seeded boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists reviews_product_id_idx on public.reviews(product_id);

alter table public.reviews enable row level security;

create policy "reviews_select" on public.reviews for select using (true);
create policy "reviews_insert" on public.reviews
  for insert with check (auth.uid() = customer_id or public.is_admin());
create policy "reviews_delete_admin" on public.reviews for delete using (public.is_admin());

-- ------------------------------------------------------------
-- SITE TESTIMONIALS (general "the store is good" reviews)
-- ------------------------------------------------------------
create table if not exists public.site_reviews (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  rating int not null check (rating between 1 and 5),
  comment text not null default '',
  is_seeded boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.site_reviews enable row level security;

create policy "site_reviews_select" on public.site_reviews for select using (true);
create policy "site_reviews_insert_admin" on public.site_reviews for insert with check (public.is_admin());
create policy "site_reviews_delete_admin" on public.site_reviews for delete using (public.is_admin());

-- Seed a handful of general store testimonials (shown on the homepage).
insert into public.site_reviews (customer_name, rating, comment, is_seeded) values
  ('Ahmed Raza', 5, 'Vespo pe shopping ka experience bohat smooth raha, delivery bhi time pe hoti hai.', true),
  ('Fatima Khan', 5, 'Customer service is really responsive, unhon ne meri query jaldi solve ki.', true),
  ('Bilal Hussain', 4, 'Reliable store hai, ab main regular yahin se order karta hoon.', true),
  ('Ayesha Siddiqui', 5, 'COD available hone ki wja se trust ho gaya, product bhi genuine mila.', true),
  ('Usman Tariq', 4, 'Achi packaging, fair prices aur fast shipping, overall recommended.', true),
  ('Sana Malik', 5, 'Website navigate karna easy hai aur checkout process bhi simple hai.', true),
  ('Hassan Sheikh', 4, 'Maine 3 orders kiye hain ab tak, har baar acha experience raha.', true),
  ('Zainab Chaudhry', 5, 'Support team ne return process mein help ki, thankyou Vespo.', true)
on conflict do nothing;
-- ============================================================
-- PART 2 — Backfill fake reviews for EXISTING products
-- Only touches products that currently have zero reviews — safe to
-- re-run any time you add more products without reviews yet.
-- ============================================================

do $$
declare
  prod record;
  names text[] := array[
    'Ahmed Raza','Fatima Khan','Bilal Hussain','Ayesha Siddiqui','Usman Tariq',
    'Sana Malik','Hassan Sheikh','Zainab Chaudhry','Imran Baig','Mahnoor Iqbal',
    'Kashif Javed','Rabia Yousaf','Faizan Qureshi','Nida Aslam','Waqas Ahmed',
    'Sadia Pervez','Adeel Mirza','Hira Farooq','Junaid Butt','Mehwish Riaz',
    'Tayyab Shah','Amna Latif','Shoaib Anwar','Komal Nawaz'
  ];
  texts_good text[] := array[
    'Order time pe pohunch gaya, quality bhi achi thi. Recommended!',
    'Bilkul original product tha jaisa dikhaya gaya tha. Packaging bhi solid thi.',
    'First time order kiya Vespo se, experience acha raha. Dubara order karunga.',
    'Product as described tha, customer service ne bhi jaldi respond kiya.',
    'Delivery fast thi aur packaging bhi neat. Will buy again.',
    'Bohat acha laga, family ke liye order kiya tha sab ne pasand kiya.',
    'Honestly quality expectations se better nikli. Thanks Vespo team.',
    'COD option ki wja se order karna asaan hua, delivery bhi time pe hui.',
    'Website use karna easy tha aur tracking bhi clear thi.',
    'Vespo se pehli dafa order kiya aur bilkul satisfied hoon.',
    'Great service, order 3 din mein mil gaya.',
    'Packaging bohat mazboot thi, kuch damage nahi hua raste mein.',
    'Product genuine laga, price bhi reasonable hai market ke hisab se.',
    'Customer support responsive tha jab maine sawal poocha tha.',
    'Overall achi purchase thi, worth the money.',
    'Bahut zabardast, bilkul wesa hi jaisa photo mein tha.',
    'Value for money hai, aur baar baar order karunga is store se.',
    'Neat packaging aur quick response, acha tajurba raha.',
    'Quality bohat achi hai is price range mein, khush hoon.',
    'Sab kuch theek time pe mila, koi shikayat nahi.'
  ];
  texts_mixed text[] := array[
    'Quality achi hai lekin size thora tight nikla, next time ek size bara lunga.',
    'Product ok tha, packaging kholte waqt halki si scratch thi warna sab theek.',
    'Thora expensive laga par quality dekh kar sahi lagta hai.',
    'Delivery thori late hui warna baaki sab perfect tha.',
    'Thik thak product hai, kuch khaas nahi lekin price ke hisab se sahi hai.'
  ];
  review_count int;
  i int;
  pick_name text;
  pick_rating int;
  roll numeric;
begin
  for prod in
    select p.id from public.products p
    left join public.reviews r on r.product_id = p.id
    group by p.id
    having count(r.id) = 0
  loop
    review_count := 3 + floor(random() * 3)::int; -- 3 to 5

    for i in 1..review_count loop
      pick_name := names[1 + floor(random() * array_length(names,1))::int];
      roll := random();
      pick_rating := case when roll < 0.08 then 3 when roll < 0.45 then 4 else 5 end;

      insert into public.reviews (product_id, customer_name, rating, comment, is_seeded, created_at)
      values (
        prod.id,
        pick_name,
        pick_rating,
        case when pick_rating <= 3
          then texts_mixed[1 + floor(random() * array_length(texts_mixed,1))::int]
          else texts_good[1 + floor(random() * array_length(texts_good,1))::int]
        end,
        true,
        now() - (floor(random() * 75) || ' days')::interval - (floor(random() * 720) || ' minutes')::interval
      );
    end loop;

    update public.products
    set seeded_order_count = 25 + floor(random() * 140)::int
    where id = prod.id and seeded_order_count = 0;
  end loop;
end $$;
