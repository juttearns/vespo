-- ============================================================
-- VESPO — Reviews & Ratings migration
-- Run this once in Supabase SQL Editor (Project > SQL Editor > New query)
-- Safe to run on the existing database — only adds new things.
-- ============================================================

-- "X people ordered this" counter shown on the product page
alter table public.products add column if not exists seeded_order_count int not null default 0;

-- ------------------------------------------------------------
-- PRODUCT REVIEWS
-- ------------------------------------------------------------
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  customer_id uuid references public.profiles(id) on delete set null,
  customer_name text not null,
  rating int not null check (rating between 1 and 5),
  comment text not null default '',
  is_seeded boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists reviews_product_id_idx on public.reviews(product_id);

alter table public.reviews enable row level security;

create policy "reviews_select" on public.reviews for select using (true);
create policy "reviews_insert" on public.reviews
  for insert with check (auth.uid() = customer_id or public.is_admin());
create policy "reviews_delete_admin" on public.reviews for delete using (public.is_admin());

-- ------------------------------------------------------------
-- SITE TESTIMONIALS (general "the store is good" reviews)
-- ------------------------------------------------------------
create table if not exists public.site_reviews (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  rating int not null check (rating between 1 and 5),
  comment text not null default '',
  is_seeded boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.site_reviews enable row level security;

create policy "site_reviews_select" on public.site_reviews for select using (true);
create policy "site_reviews_insert_admin" on public.site_reviews for insert with check (public.is_admin());
create policy "site_reviews_delete_admin" on public.site_reviews for delete using (public.is_admin());

-- Seed a handful of general store testimonials (shown on the homepage).
insert into public.site_reviews (customer_name, rating, comment, is_seeded) values
  ('Ahmed Raza', 5, 'Vespo pe shopping ka experience bohat smooth raha, delivery bhi time pe hoti hai.', true),
  ('Fatima Khan', 5, 'Customer service is really responsive, unhon ne meri query jaldi solve ki.', true),
  ('Bilal Hussain', 4, 'Reliable store hai, ab main regular yahin se order karta hoon.', true),
  ('Ayesha Siddiqui', 5, 'COD available hone ki wja se trust ho gaya, product bhi genuine mila.', true),
  ('Usman Tariq', 4, 'Achi packaging, fair prices aur fast shipping, overall recommended.', true),
  ('Sana Malik', 5, 'Website navigate karna easy hai aur checkout process bhi simple hai.', true),
  ('Hassan Sheikh', 4, 'Maine 3 orders kiye hain ab tak, har baar acha experience raha.', true),
  ('Zainab Chaudhry', 5, 'Support team ne return process mein help ki, thankyou Vespo.', true)
on conflict do nothing;
