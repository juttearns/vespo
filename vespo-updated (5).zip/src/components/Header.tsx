import React, { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShoppingBag, Heart, User, Search, Menu, X, Shield, Globe, Truck, BadgeCheck, RotateCcw } from "lucide-react";
import { StoreInfo, UserProfile, CartItem } from "../types";
import { CURRENCIES } from "../utils/currency";

interface HeaderProps {
  storeInfo: StoreInfo;
  cart: CartItem[];
  user: UserProfile | null;
  onNavigate: (view: string, param?: string) => void;
  onOpenAdminTrigger: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isAdminMode?: boolean;
  onExitAdmin?: () => void;
  currency: string;
  onCurrencyChange: (code: string) => void;
  countryName: string;
}

export const Header: React.FC<HeaderProps> = ({
  storeInfo,
  cart,
  user,
  onNavigate,
  onOpenAdminTrigger,
  searchQuery,
  onSearchChange,
  isAdminMode = false,
  onExitAdmin,
  currency,
  onCurrencyChange,
  countryName,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  // Rotating announcement bar messages
  const announcements = [
    { icon: Truck, text: "Cash on Delivery Available Nationwide" },
    { icon: BadgeCheck, text: "100% Genuine Products, GPS-Verified Delivery" },
    { icon: RotateCcw, text: "Easy Returns on Eligible Orders" },
  ];
  const [announceIdx, setAnnounceIdx] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setAnnounceIdx((i) => (i + 1) % announcements.length), 3500);
    return () => clearInterval(t);
  }, []);

  // Hidden 7-tap trigger state
  const tapCountRef = useRef(0);
  const tapTimerRef = useRef<NodeJS.Timeout | null>(null);

  const handleLogoTap = () => {
    tapCountRef.current += 1;

    if (!tapTimerRef.current) {
      tapTimerRef.current = setTimeout(() => {
        tapCountRef.current = 0;
        tapTimerRef.current = null;
      }, 4000);
    }

    if (tapCountRef.current >= 7) {
      if (tapTimerRef.current) clearTimeout(tapTimerRef.current);
      tapCountRef.current = 0;
      tapTimerRef.current = null;
      onOpenAdminTrigger();
    }
  };

  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const wishlistCount = user?.wishlist?.length || 0;

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all">
      {/* Rotating Announcement Bar */}
      {!isAdminMode && (
        <div className="bg-slate-900 text-white overflow-hidden">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-7 flex items-center justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={announceIdx}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.3 }}
                className="flex items-center gap-1.5 text-[10px] sm:text-[11px] font-semibold tracking-wide text-slate-200"
              >
                {React.createElement(announcements[announceIdx].icon, { className: "w-3 h-3 text-indigo-400" })}
                <span>{announcements[announceIdx].text}</span>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Admin Mode Ribbon (Shown only when in Admin view) */}
      {isAdminMode && (
        <div className="bg-slate-900 text-white px-4 py-1.5 text-xs font-medium flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-emerald-400" />
            <span>Vespo Administrative Portal</span>
          </div>
          <button
            onClick={onExitAdmin}
            className="text-slate-300 hover:text-white underline text-[11px]"
          >
            Return to Customer Storefront &rarr;
          </button>
        </div>
      )}

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo (With Hidden 7-Tap Admin Trigger) */}
          <div className="flex items-center gap-3">
            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.96, rotate: -2 }}
              transition={{ type: "spring", stiffness: 400, damping: 15 }}
              onClick={() => {
                handleLogoTap();
                onNavigate("home");
              }}
              className="text-left group focus:outline-none select-none"
              title="Vespo Storefront"
            >
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center font-extrabold text-lg shadow-md group-hover:bg-indigo-600 transition-colors">
                  V
                </div>
                <div>
                  <span className="text-xl font-extrabold tracking-tight text-slate-900 group-hover:text-indigo-600 transition-colors">
                    {storeInfo.storeName || "Vespo"}
                  </span>
                </div>
              </div>
            </motion.button>
          </div>

          {/* Desktop Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Search products, categories..."
                value={searchQuery}
                onChange={(e) => {
                  onSearchChange(e.target.value);
                  onNavigate("categories");
                }}
                className="w-full pl-10 pr-4 py-2 text-sm bg-slate-100 hover:bg-slate-100/80 focus:bg-white border border-transparent focus:border-slate-300 rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            </div>
          </div>

          {/* Nav Links & Action Controls */}
          <div className="flex items-center gap-2 sm:gap-4">
            <nav className="hidden lg:flex items-center gap-6 text-sm font-semibold text-slate-600">
              <button
                onClick={() => onNavigate("home")}
                className="hover:text-slate-900 transition-colors"
              >
                Home
              </button>
              <button
                onClick={() => onNavigate("categories")}
                className="hover:text-slate-900 transition-colors"
              >
                Shop All
              </button>
              <button
                onClick={() => onNavigate("policies")}
                className="hover:text-slate-900 transition-colors"
              >
                Policies
              </button>
            </nav>

            <div className="h-4 w-[1px] bg-slate-200 hidden lg:block" />

            {/* Country & Currency Selector Badge */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-slate-100 hover:bg-slate-200/80 rounded-full text-xs font-bold text-slate-700 transition-colors border border-slate-200/60">
              <Globe className="w-3.5 h-3.5 text-indigo-600" />
              <span className="hidden xl:inline text-[11px] text-slate-500 font-medium">{countryName}:</span>
              <select
                value={currency}
                onChange={(e) => onCurrencyChange(e.target.value)}
                className="bg-transparent font-extrabold text-slate-900 focus:outline-none cursor-pointer text-xs"
                title="Select Currency"
              >
                {Object.values(CURRENCIES).map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.code} ({c.symbol.trim()})
                  </option>
                ))}
              </select>
            </div>

            {/* Mobile Search Toggle */}
            <button
              onClick={() => setSearchOpen(!searchOpen)}
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 rounded-full hover:bg-slate-100"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Icon */}
            <button
              onClick={() => onNavigate("profile", "wishlist")}
              className="relative p-2 text-slate-700 hover:text-rose-600 rounded-full hover:bg-slate-100 transition-colors"
              title="Wishlist"
            >
              <Heart className="w-5 h-5" />
              <AnimatePresence>
                {wishlistCount > 0 && (
                  <motion.span
                    key={wishlistCount}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 500, damping: 15 }}
                    className="absolute top-0 right-0 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white"
                  >
                    {wishlistCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>

            {/* Cart Icon */}
            <button
              onClick={() => onNavigate("cart")}
              className="relative p-2 text-slate-700 hover:text-indigo-600 rounded-full hover:bg-slate-100 transition-colors"
              title="Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              <AnimatePresence>
                {totalCartCount > 0 && (
                  <motion.span
                    key={totalCartCount}
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    exit={{ scale: 0, opacity: 0 }}
                    transition={{ type: "spring", stiffness: 500, damping: 15 }}
                    className="absolute top-0 right-0 w-4.5 h-4.5 bg-indigo-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white"
                  >
                    {totalCartCount}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>

            {/* Profile / Account Icon */}
            <button
              onClick={() => {
                if (user) {
                  onNavigate("profile");
                } else {
                  onNavigate("auth");
                }
              }}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-full hover:bg-slate-100 text-slate-700 font-semibold text-xs border border-transparent hover:border-slate-200 transition-all"
            >
              {user ? (
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-slate-900 text-white text-[10px] font-bold flex items-center justify-center">
                    {user.name ? user.name.charAt(0).toUpperCase() : "U"}
                  </div>
                  <span className="hidden sm:inline text-xs font-semibold max-w-[90px] truncate">
                    {user.name}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5">
                  <User className="w-4 h-4" />
                  <span className="hidden sm:inline">Sign In</span>
                </div>
              )}
            </button>

            {/* Mobile Menu Hamburger Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input Bar */}
        {searchOpen && (
          <div className="md:hidden pb-3 pt-1">
            <div className="relative">
              <input
                type="text"
                placeholder="Search catalog..."
                value={searchQuery}
                onChange={(e) => {
                  onSearchChange(e.target.value);
                  onNavigate("categories");
                }}
                className="w-full pl-10 pr-4 py-2 text-sm bg-slate-100 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
            </div>
          </div>
        )}
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-2 pb-4 space-y-2 animate-in slide-in-from-top-2 duration-150">
          <button
            onClick={() => {
              onNavigate("home");
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 px-3 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-100"
          >
            Home
          </button>
          <button
            onClick={() => {
              onNavigate("categories");
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 px-3 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-100"
          >
            Categories & Catalog
          </button>
          <button
            onClick={() => {
              onNavigate("policies");
              setMobileMenuOpen(false);
            }}
            className="w-full text-left py-2 px-3 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-100"
          >
            Store Policies
          </button>
          {user && (
            <button
              onClick={() => {
                onNavigate("profile", "help");
                setMobileMenuOpen(false);
              }}
              className="w-full text-left py-2 px-3 rounded-lg text-sm font-semibold text-indigo-600 hover:bg-indigo-50"
            >
              Help & Support Tickets
            </button>
          )}
        </div>
      )}
    </header>
  );
};
