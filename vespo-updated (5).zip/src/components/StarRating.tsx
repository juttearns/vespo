import React from "react";
import { Star } from "lucide-react";

interface StarRatingProps {
  rating: number;
  reviewCount?: number;
  size?: "xs" | "sm" | "md";
  showCount?: boolean;
}

const sizeMap = { xs: "w-2.5 h-2.5", sm: "w-3.5 h-3.5", md: "w-5 h-5" };
const textSizeMap = { xs: "text-[10px]", sm: "text-xs", md: "text-sm" };

export const StarRating: React.FC<StarRatingProps> = ({ rating, reviewCount, size = "sm", showCount = true }) => {
  if (!reviewCount) return null;
  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((i) => (
          <Star
            key={i}
            className={`${sizeMap[size]} ${i <= Math.round(rating) ? "fill-amber-400 text-amber-400" : "text-slate-200"}`}
          />
        ))}
      </div>
      {showCount && (
        <span className={`${textSizeMap[size]} text-slate-500 font-semibold`}>
          {rating.toFixed(1)} ({reviewCount})
        </span>
      )}
    </div>
  );
};

interface StarRatingInputProps {
  value: number;
  onChange: (value: number) => void;
}

export const StarRatingInput: React.FC<StarRatingInputProps> = ({ value, onChange }) => {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          onClick={() => onChange(i)}
          className="p-0.5"
          aria-label={`${i} star`}
        >
          <Star className={`w-6 h-6 transition-colors ${i <= value ? "fill-amber-400 text-amber-400" : "text-slate-300"}`} />
        </button>
      ))}
    </div>
  );
};
