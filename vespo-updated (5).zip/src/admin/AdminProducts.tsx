import React, { useState } from "react";
import { Plus, Edit2, Trash2, Tag, Layers, CheckCircle2, PackageCheck, Image as ImageIcon, FileSpreadsheet, Download, AlertCircle, X, UploadCloud, Link2, Wand2, Loader2 } from "lucide-react";
import * as XLSX from "xlsx";
import { Product, Category } from "../types";
import { api } from "../services/api";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl, handleImageError } from "../utils/image";
import { cleanProductDescription, ProductDescriptionDisplay } from "../utils/descriptionCleaner";
import { getCategoryVisual } from "../utils/categoryIcons";

// A small set of general buckets to classify scraped/imported products into,
// instead of using raw (often overly specific) source category text verbatim.
const GENERAL_CATEGORY_KEYWORDS: Record<string, string[]> = {
  "Apparel": ["shirt", "tee", "t-shirt", "dress", "jean", "denim", "pant", "trouser", "jacket", "coat", "hoodie", "sweater", "sweatshirt", "apparel", "clothing", "outfit", "skirt", "short", "legging", "top", "blouse", "suit", "kurta", "shalwar"],
  "Footwear": ["shoe", "sneaker", "sandal", "boot", "heel", "slipper", "footwear", "flip flop", "flip-flop"],
  "Electronics": ["electronic", "phone", "smartphone", "laptop", "computer", "charger", "cable", "headphone", "earbud", "earphone", "speaker", "camera", "television", " tv ", "gadget", "tablet", "smartwatch", "router", "power bank", "monitor", "keyboard", "mouse"],
  "Home & Living": ["home", "kitchen", "furniture", "decor", "bedding", "storage", "organiz", "bathroom", "rug", "curtain", "lamp", "lighting", "candle", "garden", "appliance", "cookware", "utensil", "furnishing"],
  "Beauty & Personal Care": ["beauty", "makeup", "cosmetic", "skincare", "skin care", "haircare", "hair care", "shampoo", "lotion", "cream", "perfume", "fragrance", "nail"],
  "Accessories": ["bag", "backpack", "handbag", "wallet", "belt", "sunglass", "jewelry", "jewellery", "necklace", "bracelet", "ring", "earring", "hat", "cap ", "scarf", "glove", "watch"],
  "Sports & Outdoors": ["sport", "fitness", "gym", "yoga", "outdoor", "camping", "bike", "bicycle", "hiking", "running"],
  "Kids & Baby": ["kid", "baby", "infant", "toddler", "toy", "children"],
  "Grocery & Food": ["food", "grocery", "snack", "beverage", "drink", "tea", "coffee"],
  "Books & Stationery": ["book", "stationery", "notebook", "pen ", "pencil"],
  "Automotive": ["car ", "auto part", "vehicle", "motorbike", "motorcycle"],
};

/**
 * Maps a raw/scraped category string (which may be a verbose breadcrumb like
 * "Home & Kitchen > Storage & Organization > Baskets") onto an existing store
 * category if one already fits, or otherwise a general bucket — so imported
 * products land in sensible shared categories instead of each spawning its
 * own hyper-specific one.
 */
function normalizeCategory(raw: string | null | undefined, existingCategories: string[], extraText: string = ""): string {
  const segments = (raw || "")
    .split(/[>\/|,•·]/)
    .map((s) => s.trim())
    .filter(Boolean);
  const haystack = [...segments, extraText].join(" ").toLowerCase();

  // 1. Prefer an existing store category if it's a clear match.
  for (const ec of existingCategories) {
    const ecLower = ec.trim().toLowerCase();
    if (!ecLower) continue;
    if (segments.some((seg) => seg.toLowerCase() === ecLower) || haystack.includes(ecLower)) {
      return ec;
    }
  }

  // 2. Otherwise classify into a general bucket by keyword.
  for (const [general, keywords] of Object.entries(GENERAL_CATEGORY_KEYWORDS)) {
    if (keywords.some((kw) => haystack.includes(kw))) {
      const existingMatch = existingCategories.find((ec) => ec.trim().toLowerCase() === general.toLowerCase());
      return existingMatch || general;
    }
  }

  return "General";
}

interface AdminProductsProps {
  products: Product[];
  categories: Category[];
  onRefresh: () => void;
  currency?: string;
  baseCurrency?: string;
}

export const AdminProducts: React.FC<AdminProductsProps> = ({
  products,
  categories,
  onRefresh,
  currency = "PKR",
  baseCurrency = "PKR",
}) => {
  const [modalOpen, setModalOpen] = useState(false);
  const [catModalOpen, setCatModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Excel Import State
  const [excelModalOpen, setExcelModalOpen] = useState(false);
  const [excelFileName, setExcelFileName] = useState<string>("");
  const [parsedRows, setParsedRows] = useState<Partial<Product>[]>([]);
  const [validationErrors, setValidationErrors] = useState<string[]>([]);
  const [importingExcel, setImportingExcel] = useState(false);
  const [importSuccessMsg, setImportSuccessMsg] = useState<string | null>(null);

  // Link Import State (fetch product details from URLs)
  const [linkModalOpen, setLinkModalOpen] = useState(false);
  const [linkUrlsInput, setLinkUrlsInput] = useState("");
  const [fetchingLinks, setFetchingLinks] = useState(false);
  const [linkParsedRows, setLinkParsedRows] = useState<Partial<Product>[]>([]);
  const [linkFetchErrors, setLinkFetchErrors] = useState<string[]>([]);
  const [linkImporting, setLinkImporting] = useState(false);
  const [linkImportSuccessMsg, setLinkImportSuccessMsg] = useState<string | null>(null);

  // Form states
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [salePrice, setSalePrice] = useState("");
  const [category, setCategory] = useState(categories[0]?.name || "Apparel");
  const [stock, setStock] = useState("10");
  const [imageUrls, setImageUrls] = useState<string[]>([""]);
  const [isFeatured, setIsFeatured] = useState(false);
  const [saving, setSaving] = useState(false);

  // Category Form
  const [newCatName, setNewCatName] = useState("");

  const handleOpenAdd = () => {
    setEditingId(null);
    setTitle("");
    setDescription("");
    setPrice("");
    setSalePrice("");
    setCategory(categories[0]?.name || "Apparel");
    setStock("10");
    setImageUrls([""]);
    setIsFeatured(false);
    setModalOpen(true);
  };

  const handleOpenEdit = (p: Product) => {
    setEditingId(p.id);
    setTitle(p.title);
    setDescription(p.description);
    setPrice(p.price.toString());
    setSalePrice(p.salePrice ? p.salePrice.toString() : "");
    setCategory(p.category);
    setStock(p.stock.toString());
    setImageUrls(p.images && p.images.length > 0 ? p.images : [""]);
    setIsFeatured(p.isFeatured || false);
    setModalOpen(true);
  };

  const handleAddImageUrl = () => {
    setImageUrls([...imageUrls, ""]);
  };

  const handleRemoveImageUrl = (index: number) => {
    if (imageUrls.length <= 1) {
      setImageUrls([""]);
    } else {
      setImageUrls(imageUrls.filter((_, i) => i !== index));
    }
  };

  const handleImageChange = (index: number, val: string) => {
    const updated = [...imageUrls];
    updated[index] = val;
    setImageUrls(updated);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const validImages = imageUrls.map(u => optimizeImageUrl(u.trim())).filter(Boolean);
      const payload: Partial<Product> = {
        title: title.trim(),
        description: cleanProductDescription(description),
        price: parseFloat(price) || 0,
        salePrice: salePrice ? parseFloat(salePrice) : undefined,
        category,
        stock: parseInt(stock) || 0,
        images: validImages,
        isFeatured,
      };

      if (editingId) {
        await api.updateProduct(editingId, payload);
      } else {
        await api.createProduct(payload);
      }

      onRefresh();
      setModalOpen(false);
    } catch (err: any) {
      alert("Failed to save product: " + err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this product?")) return;
    try {
      await api.deleteProduct(id);
      onRefresh();
    } catch (err: any) {
      alert("Failed to delete product: " + err.message);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    try {
      await api.createCategory(newCatName.trim());
      setNewCatName("");
      onRefresh();
    } catch (err: any) {
      alert("Error adding category: " + err.message);
    }
  };

  const handleDeleteCategory = async (catId: string) => {
    if (!window.confirm("Delete this category?")) return;
    try {
      await api.deleteCategory(catId);
      onRefresh();
    } catch (err: any) {
      alert("Error deleting category: " + err.message);
    }
  };

  // Download Sample Excel Template
  const handleDownloadSampleExcel = () => {
    const sampleData = [
      {
        Title: "Minimalist Desk Lamp",
        Description: "Dimmable LED architectural desk lamp in matte black finish.",
        Price: 45.00,
        SalePrice: 39.00,
        Category: "Home",
        Stock: 15,
        ImageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800",
        IsFeatured: true,
      },
      {
        Title: "Organic Cotton Canvas Tote",
        Description: "Heavyweight organic cotton tote bag with double stitched handles.",
        Price: 24.50,
        SalePrice: "",
        Category: "Accessories",
        Stock: 25,
        ImageUrl: "https://images.unsplash.com/photo-1544816155-12df9643f363?w=800",
        IsFeatured: false,
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(sampleData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Products");
    XLSX.writeFile(workbook, "vespo_product_import_template.xlsx");
  };

  // Parse Uploaded Excel or CSV File (supports Standard Excel, Shopify CSV, WooCommerce CSV)
  const handleExcelFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExcelFileName(file.name);
    setValidationErrors([]);
    setImportSuccessMsg(null);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const buffer = evt.target?.result;
        const wb = XLSX.read(buffer, { type: "array" });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const rawData: any[] = XLSX.utils.sheet_to_json(ws, { defval: "" });

        if (!rawData || rawData.length === 0) {
          setValidationErrors(["The uploaded file appears to be empty."]);
          setParsedRows([]);
          return;
        }

        const allParsedProducts: Partial<Product>[] = [];
        const warnings: string[] = [];

        // Tracks which row(s) belong to the same product so multi-image /
        // variant rows merge into ONE product instead of creating duplicates.
        // Keyed by Shopify "Handle" when present, otherwise by normalized title.
        const productIndexByKey: Record<string, number> = {};
        const normalizeKey = (s: string) => s.trim().toLowerCase();

        // Categories assigned so far (existing store categories + any created
        // during this import), so similar products in the same file also land
        // in one shared category instead of spawning near-duplicate ones.
        const categoriesSoFar: string[] = categories.map((c) => c.name);
        const registerCategory = (name: string) => {
          if (!categoriesSoFar.some((c) => normalizeKey(c) === normalizeKey(name))) {
            categoriesSoFar.push(name);
          }
        };

        rawData.forEach((row, index) => {
          const rowNum = index + 2;

          // 1. Check if row is completely blank (all values empty or whitespace)
          const nonFields = Object.values(row).filter(
            (v) => v !== undefined && v !== null && String(v).trim() !== ""
          );
          if (nonFields.length === 0) {
            // Completely empty row, ignore
            return;
          }

          // 2. Extract fields with support for Shopify, WooCommerce, and Standard formats
          const titleVal =
            row.Title ||
            row.title ||
            row.Name ||
            row.name ||
            row["Product Name"] ||
            row["Product Title"] ||
            row["Post Title"];

          const descVal =
            row.Description ||
            row.description ||
            row["Body (HTML)"] ||
            row["Body"] ||
            row["Short description"] ||
            row["Post Content"];

          const priceVal =
            row.Price ??
            row.price ??
            row["Variant Price"] ??
            row["Regular price"] ??
            row["Regular Price"];

          const saleVal =
            row.SalePrice ??
            row.salePrice ??
            row["Sale Price"] ??
            row["Sale price"];

          const catVal =
            row.Category ||
            row.category ||
            row["Type"] ||
            row["Product Category"] ||
            row["Categories"];

          const stockVal =
            row.Stock ??
            row.stock ??
            row["Variant Inventory Qty"] ??
            row["Stock quantity"] ??
            row["Quantity"];

          const imageVal =
            row.ImageUrl ||
            row.imageUrl ||
            row.Image ||
            row.image ||
            row.Images ||
            row["Image Src"] ||
            row["Image URL"];

          const handleVal =
            row.Handle || row.handle || row["Item Handle"] || row["Product Handle"];

          const featVal =
            row.IsFeatured ?? row.isFeatured ?? row.Featured;

          // 3. Same-Product Detection — group rows belonging to the same product
          // (extra images, variants) together, whether they're adjacent or the
          // title/handle simply repeats on every row (common in many store
          // exports), instead of only catching the classic "blank title on the
          // row right below" Shopify case. This is what previously caused one
          // product with several images to get imported as several products.
          const lastProduct = allParsedProducts.length > 0 ? allParsedProducts[allParsedProducts.length - 1] : null;

          const isTitleBlank = !titleVal || String(titleVal).trim() === "";
          const isPriceBlank = priceVal === undefined || priceVal === null || priceVal === "" || isNaN(Number(priceVal));

          const groupKey = handleVal
            ? `h:${normalizeKey(String(handleVal))}`
            : !isTitleBlank
            ? `t:${normalizeKey(String(titleVal))}`
            : null;

          const matchIdx = groupKey !== null ? productIndexByKey[groupKey] : undefined;

          if (matchIdx !== undefined) {
            // Same product as one we already parsed (matched by Handle, or by
            // the same title repeating) — merge its image(s) into that ONE
            // product instead of creating a duplicate entry for it.
            const target = allParsedProducts[matchIdx];
            if (imageVal) {
              const newImages = Array.isArray(imageVal)
                ? imageVal
                : String(imageVal).split(",").map((s) => s.trim()).filter(Boolean);
              newImages.forEach((imgUrl) => {
                if (imgUrl && target.images && !target.images.includes(imgUrl)) {
                  target.images.push(imgUrl);
                }
              });
            }
            // Backfill any details the first row of this product was missing.
            if (!target.description && descVal) target.description = cleanProductDescription(String(descVal));
            if ((!target.price || target.price === 0) && !isPriceBlank) target.price = Number(priceVal);
            return; // Merged into an existing product — not a new row.
          }

          // Fallback for exports with no Handle column where extra-image /
          // variant rows simply leave the title blank (classic Shopify shape).
          if (isTitleBlank && lastProduct && imageVal) {
            // Merge image into previous product's image list
            const newImages = Array.isArray(imageVal) ? imageVal : String(imageVal).split(",").map(s => s.trim());
            newImages.forEach(imgUrl => {
              if (imgUrl && lastProduct.images && !lastProduct.images.includes(imgUrl)) {
                lastProduct.images.push(imgUrl);
              }
            });
            return; // Sub-row handled!
          }

          // If both title and price are blank and no description, skip as an invalid or padding row
          if (isTitleBlank && isPriceBlank && !descVal) {
            return;
          }

          // 4. Clean and parse values for new product
          const finalTitle = isTitleBlank ? `Imported Item #${rowNum}` : String(titleVal).trim();
          const finalPrice = isPriceBlank ? 0 : Number(priceVal);

          if (isTitleBlank) {
            warnings.push(`Row ${rowNum}: Title missing — set as '${finalTitle}'. Please edit if needed.`);
          }
          if (isPriceBlank) {
            warnings.push(`Row ${rowNum} ("${finalTitle}"): Price missing or zero — set to 0.00.`);
          }

          const parsedSale =
            saleVal !== "" && saleVal !== undefined && saleVal !== null && !isNaN(Number(saleVal))
              ? Number(saleVal)
              : undefined;

          let imageList: string[] = ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800"];
          if (imageVal) {
            const parsedImg = Array.isArray(imageVal)
              ? imageVal
              : String(imageVal).split(",").map((s) => s.trim()).filter(Boolean);
            if (parsedImg.length > 0) {
              imageList = parsedImg;
            }
          }

          const isFeat =
            String(featVal).toLowerCase() === "true" ||
            String(featVal).toLowerCase() === "yes" ||
            featVal === 1 ||
            featVal === true;

          // Fold the raw/scraped category text into an existing store category
          // when one fits, or a sensible general bucket based on the product
          // itself — instead of creating a fresh near-duplicate category for
          // every import (e.g. "Kids Shoes" vs "Kids' Shoes" vs "Footwear").
          const finalCategory = normalizeCategory(catVal ? String(catVal) : "", categoriesSoFar, finalTitle);
          registerCategory(finalCategory);

          allParsedProducts.push({
            title: finalTitle,
            description: cleanProductDescription(descVal ? String(descVal) : ""),
            price: finalPrice,
            salePrice: parsedSale,
            category: finalCategory,
            stock: stockVal !== undefined && stockVal !== "" && !isNaN(Number(stockVal)) ? Number(stockVal) : 10,
            images: imageList,
            isFeatured: isFeat,
          });

          if (groupKey !== null) {
            productIndexByKey[groupKey] = allParsedProducts.length - 1;
          }
        });

        setParsedRows(allParsedProducts);
        setValidationErrors(warnings);
      } catch (err: any) {
        setValidationErrors(["Failed to read file: " + err.message]);
        setParsedRows([]);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleUpdateParsedRow = (index: number, field: string, value: any) => {
    setParsedRows((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const handleRemoveParsedRow = (index: number) => {
    setParsedRows((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddBlankRowToImport = () => {
    setParsedRows((prev) => [
      ...prev,
      {
        title: "New Custom Product",
        description: "",
        price: 0,
        category: "General",
        stock: 10,
        images: ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800"],
        isFeatured: false,
      },
    ]);
  };

  // Execute Batch Import
  const handleExecuteExcelImport = async () => {
    if (parsedRows.length === 0) return;
    setImportingExcel(true);
    try {
      const res = await api.importBatchProducts(parsedRows);
      
      const updatedProducts = [...res.products, ...products.filter(p => !res.products.some(np => np.id === p.id))];
      localStorage.setItem("vespo_products", JSON.stringify(updatedProducts));

      onRefresh();
      setImportSuccessMsg(`Successfully imported and saved ${res.addedCount} product(s)!`);
      setParsedRows([]);
      setExcelFileName("");
      setTimeout(() => {
        setImportSuccessMsg(null);
        setExcelModalOpen(false);
      }, 2000);
    } catch (err: any) {
      setValidationErrors(["Import failed: " + err.message]);
    } finally {
      setImportingExcel(false);
    }
  };

  // Fetch product details from one or more pasted URLs
  const handleFetchProductLinks = async () => {
    const urls: string[] = Array.from(
      new Set(
        linkUrlsInput
          .split("\n")
          .map((u) => u.trim())
          .filter(Boolean)
      )
    );
    if (urls.length === 0) {
      setLinkFetchErrors(["Paste at least one product URL, one per line."]);
      return;
    }

    setFetchingLinks(true);
    setLinkFetchErrors([]);
    setLinkImportSuccessMsg(null);

    try {
      const res = await api.fetchProductsFromUrls(urls);
      const newRows: Partial<Product>[] = [];
      const errors: string[] = [];

      // Track categories used so far (existing store categories + ones already
      // picked for previously-fetched links in this session) so a batch of
      // pasted URLs converges on shared categories instead of each one
      // spawning its own near-duplicate.
      const categoriesSoFar = [
        ...categories.map((c) => c.name),
        ...linkParsedRows.map((r) => r.category || "").filter(Boolean),
      ];

      res.results.forEach((r) => {
        if (r.success && r.data) {
          const d = r.data;
          const cat = normalizeCategory(d.category, categoriesSoFar, `${d.title || ""} ${d.description || ""}`);
          if (!categoriesSoFar.some((c) => c.toLowerCase() === cat.toLowerCase())) {
            categoriesSoFar.push(cat);
          }
          newRows.push({
            title: d.title || "Untitled Product",
            description: cleanProductDescription(d.description || ""),
            price: d.price ?? 0,
            category: cat,
            stock: 10,
            images: d.images && d.images.length > 0
              ? d.images.slice(0, 6)
              : ["https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800"],
            isFeatured: false,
          });
          if (!d.title) errors.push(`${r.url}: couldn't find a title — please fill it in manually.`);
          if (d.price === null || d.price === undefined) errors.push(`${r.url}: couldn't find a price — please fill it in manually.`);
        } else {
          errors.push(`${r.url}: ${r.error || "Failed to fetch product details."}`);
        }
      });

      setLinkParsedRows((prev) => [...prev, ...newRows]);
      setLinkFetchErrors(errors);
    } catch (err: any) {
      setLinkFetchErrors([err.message || "Failed to fetch product details."]);
    } finally {
      setFetchingLinks(false);
    }
  };

  const handleUpdateLinkRow = (index: number, field: string, value: any) => {
    setLinkParsedRows((prev) => {
      const updated = [...prev];
      updated[index] = { ...updated[index], [field]: value };
      return updated;
    });
  };

  const handleRemoveLinkRow = (index: number) => {
    setLinkParsedRows((prev) => prev.filter((_, i) => i !== index));
  };

  const handleCloseLinkModal = () => {
    setLinkModalOpen(false);
    setLinkUrlsInput("");
    setLinkParsedRows([]);
    setLinkFetchErrors([]);
    setLinkImportSuccessMsg(null);
  };

  // Execute Batch Import of link-fetched products
  const handleExecuteLinkImport = async () => {
    if (linkParsedRows.length === 0) return;
    setLinkImporting(true);
    try {
      const res = await api.importBatchProducts(linkParsedRows);
      onRefresh();
      setLinkImportSuccessMsg(`Successfully added ${res.addedCount} product(s)!`);
      setLinkParsedRows([]);
      setLinkUrlsInput("");
      setTimeout(() => {
        setLinkImportSuccessMsg(null);
        setLinkModalOpen(false);
      }, 1800);
    } catch (err: any) {
      setLinkFetchErrors([`Import failed: ${err.message}`]);
    } finally {
      setLinkImporting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Products & Categories</h1>
          <p className="text-xs text-slate-500 mt-0.5">Manage store inventory, categories, pricing, and sale badges.</p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setLinkModalOpen(true)}
            className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-300 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Link2 className="w-4 h-4 text-indigo-600" />
            <span>Add via Link</span>
          </button>
          <button
            onClick={() => {
              setExcelModalOpen(true);
              setValidationErrors([]);
              setImportSuccessMsg(null);
            }}
            className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-300 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Import Excel</span>
          </button>
          <button
            onClick={() => setCatModalOpen(true)}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl border border-slate-300 transition-colors flex items-center gap-1.5"
          >
            <Layers className="w-4 h-4" />
            <span>Categories ({categories.length})</span>
          </button>
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Product</span>
          </button>
        </div>
      </div>

      {/* Product Table */}
      {products.length === 0 ? (
        <div className="p-12 bg-white rounded-3xl border border-dashed border-slate-300 text-center space-y-3">
          <PackageCheck className="w-8 h-8 text-slate-400 mx-auto" />
          <h3 className="text-sm font-bold text-slate-800">No Products in Store Catalog</h3>
          <p className="text-xs text-slate-500">Click "Add Product" above or seed sample catalog in Store Info settings.</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200/80 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200">
                  <th className="p-4">Product</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Price</th>
                  <th className="p-4">Stock</th>
                  <th className="p-4">Featured</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {products.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-4 flex items-center gap-3">
                      <img
                        src={optimizeImageUrl(p.images?.[0])}
                        alt=""
                        className="w-10 h-10 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0"
                        referrerPolicy="no-referrer"
                        onError={handleImageError}
                      />
                      <div>
                        <span className="font-bold text-slate-900 block">{p.title}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] text-slate-400 line-clamp-1">{p.description}</span>
                          {p.images && p.images.length > 1 && (
                            <span className="bg-indigo-50 text-indigo-700 font-bold px-1.5 py-0.5 rounded text-[9px] shrink-0 border border-indigo-100/80">
                              {p.images.length} photos
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="p-4 font-semibold text-indigo-600">
                      <span className="inline-flex items-center gap-1.5">
                        {(() => {
                          const v = getCategoryVisual(p.category);
                          const Icon = v.icon;
                          return (
                            <span className={`w-5 h-5 rounded-md ${v.bg} ${v.text} flex items-center justify-center shrink-0`}>
                              <Icon className="w-3 h-3" />
                            </span>
                          );
                        })()}
                        {p.category}
                      </span>
                    </td>
                    <td className="p-4">
                      {p.salePrice ? (
                        <div>
                          <span className="font-bold text-slate-900">{formatPrice(p.salePrice, currency, baseCurrency)}</span>
                          <span className="text-[10px] text-slate-400 line-through block">{formatPrice(p.price, currency, baseCurrency)}</span>
                        </div>
                      ) : (
                        <span className="font-bold text-slate-900">{formatPrice(p.price, currency, baseCurrency)}</span>
                      )}
                    </td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        p.stock <= 5 ? "bg-rose-100 text-rose-800" : "bg-emerald-100 text-emerald-800"
                      }`}>
                        {p.stock} units
                      </span>
                    </td>
                    <td className="p-4">
                      {p.isFeatured ? (
                        <span className="text-xs font-bold text-indigo-600">Yes</span>
                      ) : (
                        <span className="text-slate-400">No</span>
                      )}
                    </td>
                    <td className="p-4 text-right space-x-2">
                      <button
                        onClick={() => handleOpenEdit(p)}
                        className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(p.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Product Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white max-w-lg w-full rounded-3xl p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-extrabold text-slate-900">
              {editingId ? "Edit Product" : "Add New Product"}
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                >
                  {categories.map((c) => (
                    <option key={c.id} value={c.name}>{c.name}</option>
                  ))}
                  {categories.length === 0 && <option value="General">General</option>}
                </select>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Price ({baseCurrency})</label>
                  <input
                    type="number"
                    step="0.01"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Sale Price ({baseCurrency})</label>
                  <input
                    type="number"
                    step="0.01"
                    value={salePrice}
                    onChange={(e) => setSalePrice(e.target.value)}
                    placeholder="Optional"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Stock</label>
                  <input
                    type="number"
                    value={stock}
                    onChange={(e) => setStock(e.target.value)}
                    required
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                  />
                </div>
              </div>

              {/* Multiple Images Management */}
              <div className="space-y-2 border-t border-slate-100 pt-3">
                <div className="flex justify-between items-center">
                  <label className="block font-bold text-slate-800 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-indigo-600" />
                    <span>Product Gallery Images</span>
                    <span className="text-[10px] text-slate-400 font-normal">({imageUrls.filter(Boolean).length} added)</span>
                  </label>
                  <button
                    type="button"
                    onClick={handleAddImageUrl}
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1 rounded-lg transition-colors"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Image URL</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                  {imageUrls.map((url, idx) => (
                    <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2 rounded-xl border border-slate-200">
                      {url.trim() ? (
                        <img
                          src={optimizeImageUrl(url)}
                          alt={`Preview ${idx + 1}`}
                          className="w-10 h-10 object-cover rounded-lg border border-slate-200 bg-white flex-shrink-0"
                          referrerPolicy="no-referrer"
                          onError={handleImageError}
                        />
                      ) : (
                        <div className="w-10 h-10 bg-slate-200 rounded-lg flex items-center justify-center text-slate-400 text-[10px] font-bold flex-shrink-0">
                          #{idx + 1}
                        </div>
                      )}
                      <input
                        type="url"
                        value={url}
                        onChange={(e) => handleImageChange(idx, e.target.value)}
                        placeholder={idx === 0 ? "Main image URL (https://...)" : `Additional image URL #${idx + 1}`}
                        className="flex-1 px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-mono focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemoveImageUrl(idx)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title="Remove image"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Description</label>
                <textarea
                  rows={3}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl"
                />
              </div>

              <label className="flex items-center gap-2 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={isFeatured}
                  onChange={(e) => setIsFeatured(e.target.checked)}
                  className="rounded text-indigo-600"
                />
                <span className="font-bold">Feature on Homepage Showcase</span>
              </label>

              <div className="pt-3 flex gap-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saving}
                  className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow"
                >
                  {saving ? "Saving..." : "Save Product"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Categories Manager Modal */}
      {catModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4">
          <div className="bg-white max-w-md w-full rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <h3 className="text-base font-extrabold text-slate-900">Manage Categories</h3>
              <button onClick={() => setCatModalOpen(false)} className="text-slate-400 hover:text-slate-600 font-bold text-xs">Close</button>
            </div>

            <form onSubmit={handleAddCategory} className="flex gap-2 items-center">
              <span className={`w-9 h-9 rounded-xl ${getCategoryVisual(newCatName).bg} ${getCategoryVisual(newCatName).text} flex items-center justify-center shrink-0 transition-colors`}>
                {(() => {
                  const Icon = getCategoryVisual(newCatName).icon;
                  return <Icon className="w-4 h-4" />;
                })()}
              </span>
              <input
                type="text"
                placeholder="New Category Name..."
                value={newCatName}
                onChange={(e) => setNewCatName(e.target.value)}
                className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl"
              />
              <button type="submit" className="px-3 py-2 bg-slate-900 text-white font-bold text-xs rounded-xl shrink-0">Add</button>
            </form>
            <p className="text-[10px] text-slate-400 -mt-2">The matching icon is assigned automatically based on the name.</p>

            <div className="space-y-2 max-h-60 overflow-y-auto pt-2">
              {categories.map((c) => {
                const v = getCategoryVisual(c.name);
                const Icon = v.icon;
                return (
                  <div key={c.id} className="flex justify-between items-center p-2.5 bg-slate-50 rounded-xl text-xs">
                    <span className="flex items-center gap-2 font-bold text-slate-800">
                      <span className={`w-6 h-6 rounded-lg ${v.bg} ${v.text} flex items-center justify-center shrink-0`}>
                        <Icon className="w-3.5 h-3.5" />
                      </span>
                      {c.name}
                    </span>
                    <button onClick={() => handleDeleteCategory(c.id)} className="text-rose-600 hover:text-rose-800 font-bold">Delete</button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Excel Import Modal */}
      {excelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white max-w-xl w-full rounded-3xl p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-50 rounded-xl">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Import Products via Excel / CSV</h3>
                  <p className="text-xs text-slate-500">Upload bulk product spreadsheets to update store catalog live.</p>
                </div>
              </div>
              <button
                onClick={() => setExcelModalOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Template Download Prompt */}
            <div className="p-4 bg-emerald-50/60 border border-emerald-200/80 rounded-2xl flex items-center justify-between gap-3">
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-emerald-900 block">Need a starting template?</span>
                <p className="text-[11px] text-emerald-700">Download our formatted Excel sheet with header schema & sample rows.</p>
              </div>
              <button
                type="button"
                onClick={handleDownloadSampleExcel}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow transition-colors flex items-center gap-1.5 shrink-0"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Sample</span>
              </button>
            </div>

            {/* File Dropzone / Input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">Select Spreadsheet File (.xlsx, .xls, .csv)</label>
              <div className="relative border-2 border-dashed border-slate-300 hover:border-emerald-500 bg-slate-50/50 hover:bg-emerald-50/30 rounded-2xl p-6 text-center transition-colors cursor-pointer group">
                <input
                  type="file"
                  accept=".xlsx, .xls, .csv"
                  onChange={handleExcelFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <UploadCloud className="w-8 h-8 text-slate-400 group-hover:text-emerald-600 mx-auto transition-colors mb-2" />
                {excelFileName ? (
                  <div>
                    <span className="text-xs font-bold text-emerald-700 block">{excelFileName}</span>
                    <span className="text-[10px] text-slate-400">Click or drag another file to replace</span>
                  </div>
                ) : (
                  <div>
                    <span className="text-xs font-bold text-slate-700 block">Click or Drag & Drop Excel file here</span>
                    <span className="text-[10px] text-slate-400">Supports .xlsx, .xls, and .csv files</span>
                  </div>
                )}
              </div>
            </div>

            {/* Validation Errors Notification */}
            {validationErrors.length > 0 && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs space-y-1 max-h-36 overflow-y-auto">
                <div className="flex items-center gap-1.5 font-bold">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>Parsing / Validation Warnings ({validationErrors.length})</span>
                </div>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-rose-600 pl-1">
                  {validationErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Success Message Banner */}
            {importSuccessMsg && (
              <div className="p-3 bg-emerald-100 border border-emerald-300 rounded-2xl text-emerald-800 text-xs flex items-center gap-2 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{importSuccessMsg}</span>
              </div>
            )}

            {/* Interactive Preview & Manual Data Entry Grid */}
            {parsedRows.length > 0 && (
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <div>
                    <span className="font-extrabold text-slate-800">Review & Edit Imported Items ({parsedRows.length})</span>
                    <p className="text-[10px] text-slate-500">Edit titles, prices, or categories inline before committing to catalog.</p>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddBlankRowToImport}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 text-[11px] font-bold rounded-lg transition-colors flex items-center gap-1 border border-slate-300"
                  >
                    <Plus className="w-3 h-3" />
                    <span>Add Row</span>
                  </button>
                </div>

                <div className="border border-slate-200 rounded-2xl divide-y divide-slate-200 max-h-64 overflow-y-auto bg-slate-50/50 p-2 space-y-2">
                  {parsedRows.map((p, idx) => (
                    <div key={idx} className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-sm space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex-1">
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Product Title *</label>
                          <input
                            type="text"
                            value={p.title || ""}
                            onChange={(e) => handleUpdateParsedRow(idx, "title", e.target.value)}
                            placeholder="Enter product title..."
                            className={`w-full text-xs font-semibold px-2.5 py-1.5 rounded-lg border focus:ring-2 focus:outline-none transition-all ${
                              !p.title || p.title.startsWith("Imported Item #")
                                ? "border-amber-400 bg-amber-50/50 text-amber-900 focus:ring-amber-400"
                                : "border-slate-300 focus:ring-indigo-500 text-slate-900"
                            }`}
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveParsedRow(idx)}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors shrink-0 mt-4"
                          title="Remove row"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Price ($) *</label>
                          <input
                            type="number"
                            step="0.01"
                            value={p.price ?? 0}
                            onChange={(e) => handleUpdateParsedRow(idx, "price", parseFloat(e.target.value) || 0)}
                            className={`w-full text-xs font-bold px-2 py-1 rounded-lg border focus:ring-2 focus:outline-none ${
                              p.price === 0 ? "border-amber-400 bg-amber-50/50 text-amber-900" : "border-slate-300 text-slate-900"
                            }`}
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Sale Price ($)</label>
                          <input
                            type="number"
                            step="0.01"
                            value={p.salePrice ?? ""}
                            onChange={(e) => handleUpdateParsedRow(idx, "salePrice", e.target.value ? parseFloat(e.target.value) : undefined)}
                            placeholder="Optional"
                            className="w-full text-xs px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Category</label>
                          <input
                            type="text"
                            value={p.category || "General"}
                            onChange={(e) => handleUpdateParsedRow(idx, "category", e.target.value)}
                            className="w-full text-xs px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Stock</label>
                          <input
                            type="number"
                            value={p.stock ?? 10}
                            onChange={(e) => handleUpdateParsedRow(idx, "stock", parseInt(e.target.value) || 0)}
                            className="w-full text-xs px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Description</label>
                          <input
                            type="text"
                            value={p.description || ""}
                            onChange={(e) => handleUpdateParsedRow(idx, "description", e.target.value)}
                            placeholder="Brief item summary..."
                            className="w-full text-[11px] px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Image URL</label>
                          <input
                            type="text"
                            value={p.images?.[0] || ""}
                            onChange={(e) => handleUpdateParsedRow(idx, "images", [e.target.value])}
                            placeholder="https://..."
                            className="w-full text-[11px] px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Modal Action Footer */}
            <div className="pt-2 flex gap-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setExcelModalOpen(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={parsedRows.length === 0 || importingExcel}
                onClick={handleExecuteExcelImport}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>{importingExcel ? "Importing & Saving..." : `Import ${parsedRows.length} Products`}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add via Link Modal */}
      {linkModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4">
          <div className="bg-white max-w-xl w-full rounded-3xl p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-indigo-50 rounded-xl">
                  <Link2 className="w-5 h-5 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-base font-extrabold text-slate-900">Add Products via Link</h3>
                  <p className="text-xs text-slate-500">Paste one or more product page URLs — we'll fetch the title, price, images & description automatically.</p>
                </div>
              </div>
              <button
                onClick={handleCloseLinkModal}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* URL Input */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-slate-700">Product URLs (one per line)</label>
              <textarea
                value={linkUrlsInput}
                onChange={(e) => setLinkUrlsInput(e.target.value)}
                rows={4}
                placeholder={"https://example.com/products/some-item\nhttps://example.com/products/another-item"}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
              />
              <p className="text-[10px] text-slate-400">Works best on store product pages with standard Open Graph / product metadata. Sites that block automated requests or need JavaScript to load may not return full details — review & edit before importing.</p>
              <button
                type="button"
                onClick={handleFetchProductLinks}
                disabled={fetchingLinks || !linkUrlsInput.trim()}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5"
              >
                {fetchingLinks ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Fetching product details...</span>
                  </>
                ) : (
                  <>
                    <Wand2 className="w-4 h-4" />
                    <span>Fetch Details</span>
                  </>
                )}
              </button>
            </div>

            {/* Fetch Errors / Warnings */}
            {linkFetchErrors.length > 0 && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-xs space-y-1 max-h-36 overflow-y-auto">
                <div className="flex items-center gap-1.5 font-bold">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>Fetch Warnings ({linkFetchErrors.length})</span>
                </div>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-rose-600 pl-1">
                  {linkFetchErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Success Message Banner */}
            {linkImportSuccessMsg && (
              <div className="p-3 bg-emerald-100 border border-emerald-300 rounded-2xl text-emerald-800 text-xs flex items-center gap-2 font-bold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{linkImportSuccessMsg}</span>
              </div>
            )}

            {/* Review & Edit Fetched Products */}
            {linkParsedRows.length > 0 && (
              <div className="space-y-3">
                <div>
                  <span className="text-xs font-extrabold text-slate-800">Review & Edit Fetched Items ({linkParsedRows.length})</span>
                  <p className="text-[10px] text-slate-500">Check titles, prices, and images before adding them to your catalog.</p>
                </div>

                <div className="border border-slate-200 rounded-2xl divide-y divide-slate-200 max-h-72 overflow-y-auto bg-slate-50/50 p-2 space-y-2">
                  {linkParsedRows.map((p, idx) => (
                    <div key={idx} className="p-3 bg-white rounded-xl border border-slate-200/80 shadow-sm space-y-2">
                      <div className="flex items-center gap-3">
                        <img
                          src={optimizeImageUrl(p.images?.[0])}
                          alt=""
                          className="w-12 h-12 rounded-lg object-cover bg-slate-100 border border-slate-200 shrink-0"
                          referrerPolicy="no-referrer"
                          onError={handleImageError}
                        />
                        <div className="flex-1">
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Product Title *</label>
                          <input
                            type="text"
                            value={p.title || ""}
                            onChange={(e) => handleUpdateLinkRow(idx, "title", e.target.value)}
                            placeholder="Enter product title..."
                            className={`w-full text-xs font-semibold px-2.5 py-1.5 rounded-lg border focus:ring-2 focus:outline-none transition-all ${
                              !p.title ? "border-amber-400 bg-amber-50/50 text-amber-900 focus:ring-amber-400" : "border-slate-300 focus:ring-indigo-500 text-slate-900"
                            }`}
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveLinkRow(idx)}
                          className="p-1.5 text-rose-500 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors shrink-0 self-start mt-4"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Price *</label>
                          <input
                            type="number"
                            step="0.01"
                            value={p.price ?? 0}
                            onChange={(e) => handleUpdateLinkRow(idx, "price", parseFloat(e.target.value) || 0)}
                            className={`w-full text-xs font-bold px-2 py-1 rounded-lg border focus:ring-2 focus:outline-none ${
                              !p.price ? "border-amber-400 bg-amber-50/50 text-amber-900" : "border-slate-300 text-slate-900"
                            }`}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Sale Price</label>
                          <input
                            type="number"
                            step="0.01"
                            value={p.salePrice ?? ""}
                            onChange={(e) => handleUpdateLinkRow(idx, "salePrice", e.target.value ? parseFloat(e.target.value) : undefined)}
                            placeholder="Optional"
                            className="w-full text-xs px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Category</label>
                          <input
                            type="text"
                            value={p.category || "General"}
                            onChange={(e) => handleUpdateLinkRow(idx, "category", e.target.value)}
                            className="w-full text-xs px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Stock</label>
                          <input
                            type="number"
                            value={p.stock ?? 10}
                            onChange={(e) => handleUpdateLinkRow(idx, "stock", parseInt(e.target.value) || 0)}
                            className="w-full text-xs px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-0.5">Description</label>
                        <input
                          type="text"
                          value={p.description || ""}
                          onChange={(e) => handleUpdateLinkRow(idx, "description", e.target.value)}
                          placeholder="Brief item summary..."
                          className="w-full text-[11px] px-2 py-1 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 text-slate-900"
                        />
                      </div>

                      {p.images && p.images.length > 1 && (
                        <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
                          {p.images.slice(0, 6).map((img, i) => (
                            <img
                              key={i}
                              src={optimizeImageUrl(img)}
                              alt=""
                              onClick={() => {
                                const reordered = [img, ...(p.images || []).filter((_, ii) => ii !== i)];
                                handleUpdateLinkRow(idx, "images", reordered);
                              }}
                              referrerPolicy="no-referrer"
                              onError={handleImageError}
                              title="Click to use as main image"
                              className={`w-8 h-8 rounded-md object-cover border cursor-pointer ${i === 0 ? "border-indigo-500 ring-2 ring-indigo-200" : "border-slate-200"}`}
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Modal Action Footer */}
            <div className="pt-2 flex gap-3 border-t border-slate-100">
              <button
                type="button"
                onClick={handleCloseLinkModal}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={linkParsedRows.length === 0 || linkImporting}
                onClick={handleExecuteLinkImport}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-1.5"
              >
                <Link2 className="w-4 h-4" />
                <span>{linkImporting ? "Adding & Saving..." : `Add ${linkParsedRows.length} Product${linkParsedRows.length === 1 ? "" : "s"}`}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
