import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { Footer } from "./components/Footer";
import { AdminTriggerModal } from "./components/AdminTriggerModal";
import { HomeView } from "./views/HomeView";
import { CategoryListingView } from "./views/CategoryListingView";
import { ProductDetailView } from "./views/ProductDetailView";
import { CartView } from "./views/CartView";
import { CheckoutView } from "./views/CheckoutView";
import { OrderConfirmationView } from "./views/OrderConfirmationView";
import { AuthView } from "./views/AuthView";
import { ProfileView } from "./views/ProfileView";
import { PoliciesView } from "./views/PoliciesView";
import { AdminView } from "./views/AdminView";
import { api } from "./services/api";
import { supabase } from "./services/supabaseClient";
import { StoreInfo, Policies, Product, Category, CartItem, UserProfile, Order } from "./types";
import { detectUserCurrency } from "./utils/currency";

export default function App() {
  const [currentView, setCurrentView] = useState<string>("home");
  const [viewParam, setViewParam] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Currency & Location Detection
  const [currency, setCurrency] = useState<string>("PKR");
  const [countryName, setCountryName] = useState<string>("Pakistan");

  // Global State
  const [storeInfo, setStoreInfo] = useState<StoreInfo>(() => {
    const saved = localStorage.getItem("vespo_store_info");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      storeName: "Vespo",
      tagline: "Elevated Daily Essentials",
      bannerTitle: "Essential objects for modern simplicity.",
      bannerSubtitle: "Discover handcrafted minimalist pieces designed for effortless daily living.",
      heroImageUrl: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1600",
      deliveryFee: 5.0,
      codFee: 2.0,
      bankName: "Vespo Central Reserve Bank",
      accountName: "Vespo Global Retail Inc.",
      accountNumber: "9901-4458-2990-112",
      ibanRouting: "VSPOUS33XXX",
      supportEmail: "support@vespo.com",
      supportPhone: "+1 (800) 555-VESPO",
      googleClientId: "",
      baseCurrency: "PKR",
    };
  });

  const [policies, setPolicies] = useState<Policies>(() => {
    const saved = localStorage.getItem("vespo_policies");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      privacyPolicy: "At Vespo, we protect user location data and order history securely.",
      shippingPolicy: "Orders are dispatched within 24 hours. GPS map pins are cross-checked for location precision.",
      returnPolicy: "Items can be returned within 14 days of delivery.",
      termsOfService: "Standard terms of service apply to all purchases.",
      updatedAt: new Date().toISOString(),
    };
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem("vespo_products");
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return [];
  });

  const [categories, setCategories] = useState<Category[]>([]);
  const [siteReviews, setSiteReviews] = useState<import("./types").SiteReview[]>([]);
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem("vespo_cart");
    return saved ? JSON.parse(saved) : [];
  });
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem("vespo_user");
    return saved ? JSON.parse(saved) : null;
  });

  const [adminModalOpen, setAdminModalOpen] = useState(false);
  const [lastPlacedOrder, setLastPlacedOrder] = useState<Order | null>(null);

  // Load initial data from backend API with localStorage fail-safe sync
  const refreshData = async () => {
    try {
      const [sInfo, pols, prods, cats, ratingSummaries, siteRevs] = await Promise.all([
        api.getStoreInfo(),
        api.getPolicies(),
        api.getProducts(),
        api.getCategories(),
        api.getRatingSummaries(),
        api.getSiteReviews(),
      ]);

      setStoreInfo(sInfo);
      localStorage.setItem("vespo_store_info", JSON.stringify(sInfo));

      setPolicies(pols);
      localStorage.setItem("vespo_policies", JSON.stringify(pols));

      const prodsWithRatings = prods.map((p) => ({
        ...p,
        avgRating: ratingSummaries[p.id]?.avgRating,
        reviewCount: ratingSummaries[p.id]?.reviewCount,
      }));
      setProducts(prodsWithRatings);
      localStorage.setItem("vespo_products", JSON.stringify(prodsWithRatings));

      setCategories(cats);
      setSiteReviews(siteRevs);
    } catch (err) {
      console.error("Error loading store data:", err);
    }
  };

  useEffect(() => {
    refreshData();
    detectUserCurrency().then((res) => {
      setCurrency(res.currency);
      setCountryName(res.countryName);
    });
  }, []);

  // Sync user state with localStorage
  useEffect(() => {
    if (user) {
      localStorage.setItem("vespo_user", JSON.stringify(user));
    } else {
      localStorage.removeItem("vespo_user");
    }
  }, [user]);

  // Sync cart state with localStorage
  useEffect(() => {
    localStorage.setItem("vespo_cart", JSON.stringify(cart));
  }, [cart]);

  // Navigation Helper
  const handleNavigate = (view: string, param?: string) => {
    setCurrentView(view);
    setViewParam(param);
    refreshData();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Cart Handlers
  const handleAddToCart = (product: Product, quantityToAdd: number = 1) => {
    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex((item) => item.productId === product.id);
      if (existingIdx > -1) {
        const updated = [...prevCart];
        updated[existingIdx].quantity += quantityToAdd;
        return updated;
      }
      return [...prevCart, { productId: product.id, product, quantity: quantityToAdd }];
    });
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) => (item.productId === productId ? { ...item, quantity } : item))
    );
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.productId !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Wishlist Handler
  const handleToggleWishlist = async (productId: string) => {
    if (!user) {
      handleNavigate("auth");
      return;
    }

    try {
      const res = await api.toggleWishlist(user.id, productId);
      setUser({ ...user, wishlist: res.wishlist });
    } catch (err) {
      console.error("Wishlist error:", err);
    }
  };

  // Auth Handlers
  const handleAuthSuccess = (token: string, authUser: UserProfile) => {
    setUser(authUser);
    localStorage.setItem("vespo_token", token);
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem("vespo_token");
    localStorage.removeItem("vespo_user");
    handleNavigate("home");
    // Fire-and-forget: clear the real Supabase session too, so a stale
    // session can't be reused (e.g. via devtools or a stray API call)
    // after the UI has already logged the user out.
    api.logout().catch((err) => {
      console.error("Supabase sign-out failed:", err);
    });
  };

  // Pick up the session Supabase creates after a Google OAuth redirect
  // (or any other future OAuth provider) completes. Email/password login
  // already calls handleAuthSuccess directly, so this fires again for
  // that case too — harmless, it just re-sets the same user.
  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if ((event === "SIGNED_IN" || event === "INITIAL_SESSION") && session) {
        try {
          const result = await api.getSessionUser();
          if (result) {
            handleAuthSuccess(result.token, result.user);
          }
        } catch (err) {
          console.error("Failed to load profile after sign-in:", err);
        }
      }
      if (event === "SIGNED_OUT") {
        setUser(null);
      }
    });
    return () => subscription.unsubscribe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);


  // User Profile Update Handler
  const handleUpdateUserProfile = async (data: any) => {
    const updatedUser = await api.updateProfile(data);
    setUser(updatedUser);
    return updatedUser;
  };

  const featuredProducts = products.filter((p) => p.isFeatured);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans flex flex-col justify-between selection:bg-slate-900 selection:text-white">
      {/* If in admin view, render AdminView directly */}
      {currentView === "admin" ? (
        <AdminView
          storeInfo={storeInfo}
          onRefreshStoreInfo={refreshData}
          onNavigateStorefront={() => handleNavigate("home")}
          onLogout={handleLogout}
          currency={currency}
        />
      ) : (
        <>
          {/* Main Customer Storefront Header */}
          <Header
            storeInfo={storeInfo}
            cart={cart}
            user={user}
            onNavigate={handleNavigate}
            onOpenAdminTrigger={() => {
              if (user && user.role === "admin") {
                handleNavigate("admin");
              } else {
                setAdminModalOpen(true);
              }
            }}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            isAdminMode={user?.role === "admin"}
            onExitAdmin={() => handleNavigate("admin")}
            currency={currency}
            onCurrencyChange={(c) => setCurrency(c)}
            countryName={countryName}
          />

          {/* Main Content Area */}
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {currentView === "home" && (
              <HomeView
                storeInfo={storeInfo}
                categories={categories}
                featuredProducts={featuredProducts}
                allProducts={products}
                user={user}
                onNavigate={handleNavigate}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                currency={currency}
                siteReviews={siteReviews}
              />
            )}

            {currentView === "categories" && (
              <CategoryListingView
                products={products}
                categories={categories}
                selectedCategory={viewParam}
                searchQuery={searchQuery}
                onSelectCategory={(cat) => setViewParam(cat)}
                onSearchChange={setSearchQuery}
                user={user}
                onNavigate={handleNavigate}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                currency={currency}
                baseCurrency={storeInfo?.baseCurrency || "PKR"}
              />
            )}

            {currentView === "product" && (
              <ProductDetailView
                product={products.find(p => p.id === viewParam) || products[0]}
                user={user}
                onNavigate={handleNavigate}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                currency={currency}
                baseCurrency={storeInfo?.baseCurrency || "PKR"}
              />
            )}

            {currentView === "cart" && (
              <CartView
                cart={cart}
                storeInfo={storeInfo}
                user={user}
                onUpdateQuantity={handleUpdateQuantity}
                onRemoveItem={handleRemoveFromCart}
                onNavigate={handleNavigate}
                currency={currency}
              />
            )}

            {currentView === "checkout" && (
              <CheckoutView
                cart={cart}
                user={user}
                storeInfo={storeInfo}
                onNavigate={handleNavigate}
                onUpdateUserProfile={handleUpdateUserProfile}
                onOrderPlaced={(order) => {
                  setLastPlacedOrder(order);
                  handleClearCart();
                  handleNavigate("order-confirmation", order.id);
                }}
                currency={currency}
              />
            )}

            {currentView === "order-confirmation" && (
              <OrderConfirmationView
                order={
                  lastPlacedOrder || {
                    id: viewParam || "ORD-DEMO",
                    orderCode: "VESPO-DEMO-9912",
                    customerId: user?.id || "guest",
                    customerName: user?.name || "Customer",
                    customerEmail: user?.email || "customer@example.com",
                    items: cart.map((c) => ({
                      productId: c.productId,
                      productTitle: c.product.title,
                      price: c.product.salePrice || c.product.price,
                      quantity: c.quantity,
                      image: c.product.images?.[0],
                    })),
                    subtotal: 99.0,
                    discountAmount: 0,
                    codCharge: storeInfo.codFee,
                    totalAmount: 101.0,
                    paymentMethod: "cod",
                    paymentConfirmed: false,
                    shippingAddressText: user?.addressText || "123 Main Street, San Francisco, CA",
                    shippingPin: user?.locationPin || { lat: 37.7749, lng: -122.4194 },
                    gpsCheck: { matched: true, distanceKm: 0.12 },
                    status: "processing",
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString(),
                  }
                }
                onNavigate={handleNavigate}
                currency={currency}
                baseCurrency={storeInfo?.baseCurrency || "PKR"}
              />
            )}

            {currentView === "auth" && (
              <AuthView
                storeInfo={storeInfo}
                onAuthSuccess={handleAuthSuccess}
                onNavigate={handleNavigate}
                redirectView={viewParam}
              />
            )}

            {currentView === "profile" && user && (
              <ProfileView
                user={user}
                activeTab={viewParam || "orders"}
                allProducts={products}
                onLogout={handleLogout}
                onNavigate={handleNavigate}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                onUpdateUserProfile={handleUpdateUserProfile}
                currency={currency}
                baseCurrency={storeInfo?.baseCurrency || "PKR"}
              />
            )}

            {currentView === "policies" && (
              <PoliciesView
                policies={policies}
                storeInfo={storeInfo}
              />
            )}
          </main>

          {/* Customer Storefront Footer */}
          <Footer
            storeInfo={storeInfo}
            onNavigate={handleNavigate}
            onOpenAdminTrigger={() => setAdminModalOpen(true)}
          />
        </>
      )}

      {/* Secret 7-Tap Admin Authorization Modal */}
      <AdminTriggerModal
        isOpen={adminModalOpen}
        onClose={() => setAdminModalOpen(false)}
        onAdminAuthenticated={(adminUser) => {
          // Use the real, authenticated profile returned by the login
          // call — not a stand-in object — so user.id matches the
          // Supabase auth session and RLS-scoped queries resolve correctly.
          setUser(adminUser);
          handleNavigate("admin");
        }}
      />
    </div>
  );
}
