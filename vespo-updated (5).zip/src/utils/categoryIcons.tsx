import {
  Shirt,
  Footprints,
  Cpu,
  Home,
  Sparkles,
  Watch,
  Dumbbell,
  Baby,
  ShoppingBasket,
  BookOpen,
  Car,
  Camera,
  Binoculars,
  Flashlight,
  Sofa,
  Gem,
  ShoppingBag,
  Wrench,
  Lightbulb,
  Music,
  Briefcase,
  HeartPulse,
  Flower2,
  Gamepad2,
  Luggage,
  PawPrint,
  Palette,
  Smartphone,
  Layers,
  type LucideIcon,
} from "lucide-react";

interface CategoryVisual {
  icon: LucideIcon;
  bg: string;
  text: string;
}

// Each bucket: a canonical name (matched first), a set of keywords matched
// against the category's own text, an icon, and a soft badge color so the
// category grid reads as a set of distinct little "departments" rather than
// one repeated indigo tile.
const CATEGORY_RULES: { name: string; keywords: string[]; icon: LucideIcon; bg: string; text: string }[] = [
  { name: "Apparel", keywords: ["shirt", "tee", "t-shirt", "dress", "jean", "denim", "pant", "trouser", "jacket", "coat", "hoodie", "sweater", "sweatshirt", "apparel", "clothing", "outfit", "skirt", "short", "legging", "top", "blouse", "suit", "kurta", "shalwar", "fashion"], icon: Shirt, bg: "bg-rose-50", text: "text-rose-600" },
  { name: "Footwear", keywords: ["shoe", "sneaker", "sandal", "boot", "heel", "slipper", "footwear", "flip flop", "flip-flop"], icon: Footprints, bg: "bg-orange-50", text: "text-orange-600" },
  { name: "Electronics", keywords: ["electronic", "phone", "smartphone", "laptop", "computer", "charger", "cable", "gadget", "tablet", "smartwatch", "router", "power bank", "monitor", "keyboard", "mouse", "pc "], icon: Cpu, bg: "bg-blue-50", text: "text-blue-600" },
  { name: "Mobile Accessories", keywords: ["mobile accessor", "phone case", "screen protector", "phone cover"], icon: Smartphone, bg: "bg-sky-50", text: "text-sky-600" },
  { name: "Audio", keywords: ["headphone", "earbud", "earphone", "speaker", "audio", "headset"], icon: Music, bg: "bg-violet-50", text: "text-violet-600" },
  { name: "Security & Surveillance", keywords: ["security camera", "cctv", "surveillance", "security", "360 view"], icon: Camera, bg: "bg-slate-100", text: "text-slate-700" },
  { name: "Binoculars", keywords: ["binocular", "telescope", "spotting scope"], icon: Binoculars, bg: "bg-emerald-50", text: "text-emerald-700" },
  { name: "Flashlight", keywords: ["flashlight", "torch", "headlamp"], icon: Flashlight, bg: "bg-amber-50", text: "text-amber-600" },
  { name: "Lighting", keywords: ["lamp", "lighting", "led light", "bulb", "night light", "string light", "fairy light"], icon: Lightbulb, bg: "bg-yellow-50", text: "text-yellow-600" },
  { name: "Furniture", keywords: ["furniture", "sofa", "chair", "table", "desk", "shelf", "cabinet", "wardrobe"], icon: Sofa, bg: "bg-amber-50", text: "text-amber-700" },
  { name: "Home & Living", keywords: ["home", "kitchen", "decor", "bedding", "storage", "organiz", "bathroom", "rug", "curtain", "candle", "appliance", "cookware", "utensil", "furnishing", "living"], icon: Home, bg: "bg-teal-50", text: "text-teal-600" },
  { name: "Beauty & Personal Care", keywords: ["beauty", "makeup", "cosmetic", "skincare", "skin care", "haircare", "hair care", "shampoo", "lotion", "cream", "perfume", "fragrance", "nail"], icon: Sparkles, bg: "bg-pink-50", text: "text-pink-600" },
  { name: "Jewelry", keywords: ["jewelry", "jewellery", "necklace", "bracelet", "ring", "earring", "gemstone"], icon: Gem, bg: "bg-fuchsia-50", text: "text-fuchsia-600" },
  { name: "Watches", keywords: ["watch"], icon: Watch, bg: "bg-cyan-50", text: "text-cyan-600" },
  { name: "Accessories", keywords: ["bag", "backpack", "handbag", "wallet", "belt", "sunglass", "hat", "cap ", "scarf", "glove", "accessor"], icon: ShoppingBag, bg: "bg-indigo-50", text: "text-indigo-600" },
  { name: "Sports & Outdoors", keywords: ["sport", "fitness", "gym", "yoga", "outdoor", "camping", "bike", "bicycle", "hiking", "running"], icon: Dumbbell, bg: "bg-lime-50", text: "text-lime-700" },
  { name: "Kids & Baby", keywords: ["kid", "baby", "infant", "toddler", "toy", "children"], icon: Baby, bg: "bg-sky-50", text: "text-sky-600" },
  { name: "Toys & Games", keywords: ["toy", "game", "puzzle", "action figure", "gaming", "console", "controller"], icon: Gamepad2, bg: "bg-purple-50", text: "text-purple-600" },
  { name: "Grocery & Food", keywords: ["food", "grocery", "snack", "beverage", "drink", "tea", "coffee"], icon: ShoppingBasket, bg: "bg-orange-50", text: "text-orange-700" },
  { name: "Books & Stationery", keywords: ["book", "stationery", "notebook", "pen ", "pencil"], icon: BookOpen, bg: "bg-stone-100", text: "text-stone-700" },
  { name: "Automotive", keywords: ["car ", "auto part", "vehicle", "motorbike", "motorcycle"], icon: Car, bg: "bg-red-50", text: "text-red-600" },
  { name: "Tools & Hardware", keywords: ["tool", "hardware", "drill", "wrench", "screwdriver"], icon: Wrench, bg: "bg-zinc-100", text: "text-zinc-700" },
  { name: "Health & Wellness", keywords: ["health", "wellness", "medical", "supplement", "vitamin", "fitness tracker"], icon: HeartPulse, bg: "bg-red-50", text: "text-red-500" },
  { name: "Garden & Outdoor Living", keywords: ["garden", "plant", "gardening", "patio", "lawn"], icon: Flower2, bg: "bg-green-50", text: "text-green-600" },
  { name: "Pets", keywords: ["pet ", "dog ", "cat ", "leash", "pet food", "aquarium"], icon: PawPrint, bg: "bg-amber-50", text: "text-amber-800" },
  { name: "Art & Craft", keywords: ["art ", "craft", "paint", "drawing", "canvas"], icon: Palette, bg: "bg-fuchsia-50", text: "text-fuchsia-700" },
  { name: "Travel & Luggage", keywords: ["luggage", "suitcase", "travel bag", "trolley"], icon: Luggage, bg: "bg-blue-50", text: "text-blue-700" },
  { name: "Office Supplies", keywords: ["office", "desk organiz", "file folder", "stapler"], icon: Briefcase, bg: "bg-slate-100", text: "text-slate-700" },
];

const FALLBACK: CategoryVisual = { icon: Layers, bg: "bg-indigo-50", text: "text-indigo-600" };

/** Picks the best-fitting icon + color for a category name, falling back to a generic icon. */
export function getCategoryVisual(categoryName: string): CategoryVisual {
  const name = (categoryName || "").trim().toLowerCase();
  if (!name) return FALLBACK;

  // 1. Exact/near-exact bucket name match.
  const exact = CATEGORY_RULES.find((r) => r.name.toLowerCase() === name);
  if (exact) return exact;

  // 2. Keyword match against the category's own text.
  const keywordHit = CATEGORY_RULES.find((r) => r.keywords.some((kw) => name.includes(kw)));
  if (keywordHit) return keywordHit;

  return FALLBACK;
}

export function CategoryIcon({ name, className }: { name: string; className?: string }) {
  const { icon: Icon } = getCategoryVisual(name);
  return <Icon className={className} />;
}
