import React from "react";
import { Trash2, ArrowRight, ShoppingBag, Truck, ShieldCheck } from "lucide-react";
import { CartItem, StoreInfo, UserProfile } from "../types";
import { formatPrice } from "../utils/currency";
import { optimizeImageUrl, handleImageError } from "../utils/image";

interface CartViewProps {
  cart: CartItem[];
  storeInfo: StoreInfo;
  user?: UserProfile | null;
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onNavigate: (view: string, param?: string) => void;
  currency?: string;
}

export const CartView: React.FC<CartViewProps> = ({
  cart,
  storeInfo,
  user,
  onUpdateQuantity,
  onRemoveItem,
  onNavigate,
  currency = "PKR",
}) => {
  const subtotal = cart.reduce((sum, item) => {
    const price = item.product.salePrice || item.product.price;
    return sum + price * item.quantity;
  }, 0);

  const deliveryFee = subtotal > 0 ? storeInfo.deliveryFee || 5.0 : 0;

  if (cart.length === 0) {
    return (
      <div className="max-w-md mx-auto py-16 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto border border-indigo-100">
          <ShoppingBag className="w-8 h-8" />
        </div>
        <div>
          <h2 className="text-xl font-extrabold text-slate-900">Your Cart is Empty</h2>
          <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
            Explore our curated catalog and add handcrafted items to your shopping cart.
          </p>
        </div>
        <button
          onClick={() => onNavigate("categories")}
          className="px-6 py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs shadow-md transition-colors inline-flex items-center gap-2"
        >
          <span>Explore Products</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-16">
      <div className="flex items-center justify-between border-b border-slate-200 pb-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Shopping Cart</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Review {cart.length} item(s) before proceeding to location-verified checkout.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left: Cart Item List */}
        <div className="lg:col-span-2 space-y-4">
          {cart.map((item) => {
            const price = item.product.salePrice || item.product.price;
            const lineTotal = price * item.quantity;

            return (
              <div
                key={item.productId}
                className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/80 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4"
              >
                <div className="flex items-center gap-4 w-full sm:w-auto">
                  <img
                    src={optimizeImageUrl(item.product.images?.[0])}
                    alt={item.product.title}
                    className="w-16 h-16 rounded-xl object-cover bg-slate-100 border border-slate-200 shrink-0"
                    referrerPolicy="no-referrer"
                    onError={handleImageError}
                  />
                  <div>
                    <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider">
                      {item.product.category || "General"}
                    </span>
                    <button
                      onClick={() => onNavigate("product", item.product.id)}
                      className="block text-sm font-bold text-slate-900 hover:text-indigo-600 transition-colors text-left line-clamp-1"
                    >
                      {item.product.title}
                    </button>
                    <p className="text-xs text-slate-500 font-semibold mt-0.5">
                      {formatPrice(price, currency)} each
                    </p>
                  </div>
                </div>

                {/* Quantity Controls & Line Total */}
                <div className="flex items-center justify-between w-full sm:w-auto gap-3 sm:gap-6 border-t sm:border-t-0 pt-3 sm:pt-0">
                  <div className="flex items-center bg-slate-100 rounded-xl border border-slate-200 p-1">
                    <button
                      type="button"
                      onClick={() => onUpdateQuantity(item.productId, item.quantity - 1)}
                      className="w-9 h-9 sm:w-7 sm:h-7 flex items-center justify-center font-bold text-slate-700 hover:bg-white rounded-md transition-colors text-xs"
                    >
                      -
                    </button>
                    <span className="w-8 text-center text-xs font-bold text-slate-900">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => onUpdateQuantity(item.productId, item.quantity + 1)}
                      className="w-9 h-9 sm:w-7 sm:h-7 flex items-center justify-center font-bold text-slate-700 hover:bg-white rounded-md transition-colors text-xs"
                    >
                      +
                    </button>
                  </div>

                  <div className="text-right">
                    <span className="text-sm font-extrabold text-slate-900">
                      {formatPrice(lineTotal, currency, storeInfo.baseCurrency || "PKR")}
                    </span>
                  </div>

                  <button
                    onClick={() => onRemoveItem(item.productId)}
                    className="p-2.5 sm:p-2 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right: Order Summary */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-md h-fit space-y-6">
          <h3 className="text-base font-extrabold text-slate-900 tracking-tight">Order Summary</h3>

          <div className="space-y-3 text-xs text-slate-600 border-b border-slate-100 pb-4">
            <div className="flex justify-between">
              <span>Subtotal</span>
              <span className="font-bold text-slate-900">{formatPrice(subtotal, currency, storeInfo.baseCurrency || "PKR")}</span>
            </div>
            <div className="flex justify-between">
              <span>Estimated Delivery Fee</span>
              <span className="font-bold text-slate-900">{formatPrice(deliveryFee, currency, storeInfo.baseCurrency || "PKR")}</span>
            </div>
            <div className="flex justify-between text-indigo-700 bg-indigo-50 p-2.5 rounded-xl border border-indigo-100">
              <span>COD Option Charge</span>
              <span className="font-bold">+{formatPrice(storeInfo.codFee || 3.5, currency, storeInfo.baseCurrency || "PKR")} (If COD selected)</span>
            </div>
          </div>

          <div className="flex justify-between items-baseline">
            <span className="text-sm font-bold text-slate-900">Est. Total (excl. COD)</span>
            <span className="text-2xl font-extrabold text-slate-900">
              {formatPrice(subtotal + deliveryFee, currency, storeInfo.baseCurrency || "PKR")}
            </span>
          </div>

          <button
            onClick={() => {
              if (user) {
                onNavigate("checkout");
              } else {
                onNavigate("auth", "checkout");
              }
            }}
            className="w-full py-3.5 px-4 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl shadow-lg shadow-indigo-600/30 transition-all flex items-center justify-center gap-2"
          >
            <span>Proceed to Checkout</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="space-y-2 text-[11px] text-slate-400 border-t border-slate-100 pt-4">
            <div className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-slate-500" />
              <span>Location GPS check verified at order step</span>
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-500" />
              <span>Supports COD or Manual Bank Transfer</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
