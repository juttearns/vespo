-- Optional: run this FIRST only if you already ran an older reviews script
-- and want the generic (non-product-specific) seeded reviews replaced.
-- This only removes auto-seeded reviews (is_seeded = true) — real
-- customer reviews are never touched.
delete from public.reviews where is_seeded = true;
