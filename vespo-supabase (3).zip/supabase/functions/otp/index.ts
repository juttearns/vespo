import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const supabaseAdmin = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
);

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS_HEADERS });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: CORS_HEADERS });
  }

  const body = await req.json().catch(() => ({}));
  const { action, phone, code } = body;

  const cleanPhone = String(phone || "").trim().replace(/\s+/g, "");

  // -------- SEND --------
  if (action === "send") {
    if (!cleanPhone || cleanPhone.length < 7) {
      return new Response(JSON.stringify({ error: "Please enter a valid mobile phone number." }), { status: 400, headers: CORS_HEADERS });
    }
    const newCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    const { error } = await supabaseAdmin.from("otp_codes").upsert({ phone: cleanPhone, code: newCode, expires_at: expiresAt });
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: CORS_HEADERS });
    }
    console.log(`[OTP] Code for ${cleanPhone}: ${newCode}`);
    return new Response(
      JSON.stringify({ success: true, message: `OTP code dispatched to ${cleanPhone}.`, otpCode: newCode }),
      { headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
    );
  }

  // -------- VERIFY --------
  if (action === "verify") {
    if (!cleanPhone || !code) {
      return new Response(JSON.stringify({ verified: false, message: "Phone number and OTP code are required." }), { status: 400, headers: CORS_HEADERS });
    }
    const { data: record, error } = await supabaseAdmin.from("otp_codes").select("*").eq("phone", cleanPhone).maybeSingle();
    if (error) {
      return new Response(JSON.stringify({ verified: false, message: error.message }), { status: 500, headers: CORS_HEADERS });
    }
    if (!record) {
      return new Response(JSON.stringify({ verified: false, message: "No OTP request found for this phone number." }), { status: 400, headers: CORS_HEADERS });
    }
    if (new Date(record.expires_at) < new Date()) {
      await supabaseAdmin.from("otp_codes").delete().eq("phone", cleanPhone);
      return new Response(JSON.stringify({ verified: false, message: "OTP code has expired. Please request a new code." }), { status: 400, headers: CORS_HEADERS });
    }
    if (record.code !== String(code).trim()) {
      return new Response(JSON.stringify({ verified: false, message: "Invalid OTP code. Please check and try again." }), { status: 400, headers: CORS_HEADERS });
    }
    await supabaseAdmin.from("otp_codes").delete().eq("phone", cleanPhone);
    return new Response(
      JSON.stringify({ verified: true, message: "Phone number successfully verified!" }),
      { headers: { ...CORS_HEADERS, "Content-Type": "application/json" } }
    );
  }

  return new Response(JSON.stringify({ error: "action must be 'send' or 'verify'" }), { status: 400, headers: CORS_HEADERS });
});
