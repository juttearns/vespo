import React, { useState, useEffect } from "react";
import { MapPin, Tag, CreditCard, Banknote, ShieldCheck, CheckCircle2, AlertTriangle, ArrowRight, Smartphone, Info, Copy, Check, Send, Mail, RefreshCw } from "lucide-react";
import { CartItem, StoreInfo, UserProfile, UserLocation, GpsCheckResult } from "../types";
import { MapPicker, calculateDistanceKm } from "../components/MapPicker";
import { api } from "../services/api";
import { formatPrice } from "../utils/currency";

interface CheckoutViewProps {
  cart: CartItem[];
  user: UserProfile | null;
  storeInfo: StoreInfo;
  onOrderPlaced?: (order: any) => void;
  onOrderCompleted?: (order: any) => void;
  onNavigate: (view: string, param?: string) => void;
  onUpdateUserProfile?: (data: any) => Promise<any>;
  currency?: string;
}

export const CheckoutView: React.FC<CheckoutViewProps> = ({
  cart,
  user,
  storeInfo,
  onOrderPlaced,
  onOrderCompleted,
  onNavigate,
  onUpdateUserProfile,
  currency = "PKR",
}) => {
  // Contact details
  const [customerName, setCustomerName] = useState(user?.name || "");
  const [customerEmail, setCustomerEmail] = useState(user?.email || "");
  const [customerPhone, setCustomerPhone] = useState(user?.phone || "");
  const [phoneVerified, setPhoneVerified] = useState(user?.phoneVerified || false);

  // OTP Verification state
  const [sendingOtp, setSendingOtp] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpCodeInput, setOtpCodeInput] = useState("");
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  const [otpNotice, setOtpNotice] = useState<string | null>(null);
  const [otpError, setOtpError] = useState<string | null>(null);
  const [smsToast, setSmsToast] = useState<string | null>(null);

  // Info Callout state
  const [showWhyContactInfo, setShowWhyContactInfo] = useState(true);

  // Address & Map Pin
  const [addressText, setAddressText] = useState(user?.addressText || "");
  const [locationPin, setLocationPin] = useState<UserLocation>(
    user?.locationPin || { lat: 37.7749, lng: -122.4194 }
  );

  // GPS Cross Check state
  const [gpsCheck, setGpsCheck] = useState<GpsCheckResult>({
    matched: true,
    distanceKm: 0,
  });

  // Discount code
  const [discountCodeInput, setDiscountCodeInput] = useState("");
  const [appliedDiscount, setAppliedDiscount] = useState<{
    code: string;
    discountAmount: number;
  } | null>(null);
  const [discountError, setDiscountError] = useState<string | null>(null);
  const [validatingCode, setValidatingCode] = useState(false);

  // Payment Method State
  const [paymentMethod, setPaymentMethod] = useState<"cod" | "jazzcash" | "easypaisa" | "bank_transfer">("cod");
  const [walletSenderMobile, setWalletSenderMobile] = useState("");
  const [walletTransactionId, setWalletTransactionId] = useState("");
  const [bankTransactionId, setBankTransactionId] = useState("");

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const [submittingOrder, setSubmittingOrder] = useState(false);
  const [orderError, setOrderError] = useState<string | null>(null);

  // Calculate Subtotal & Charges
  const subtotal = cart.reduce((sum, item) => {
    const price = item.product.salePrice || item.product.price;
    return sum + price * item.quantity;
  }, 0);

  const deliveryFee = storeInfo.deliveryFee || 5.0;
  const codCharge = paymentMethod === "cod" ? storeInfo.codFee || 3.5 : 0;
  const discountAmount = appliedDiscount ? appliedDiscount.discountAmount : 0;

  const totalAmount = Math.max(0, subtotal + deliveryFee + codCharge - discountAmount);

  // Send OTP handler
  const handleSendOtp = async () => {
    if (!customerPhone || customerPhone.trim().length < 7) {
      setOtpError("Please enter a valid phone number before verifying.");
      return;
    }
    setSendingOtp(true);
    setOtpError(null);
    setOtpNotice(null);

    try {
      const res = await api.sendOTP(customerPhone.trim());
      setOtpSent(true);
      setOtpNotice(`OTP code sent to ${customerPhone.trim()}`);
      if (res.otpCode) {
        setSmsToast(`[SMS Carrier] Your Vespo OTP Verification Code is: ${res.otpCode}`);
        setTimeout(() => setSmsToast(null), 12000);
      }
    } catch (err: any) {
      setOtpError(err.message || "Failed to send OTP code.");
    } finally {
      setSendingOtp(false);
    }
  };

  // Verify OTP handler
  const handleVerifyOtp = async () => {
    if (!otpCodeInput || otpCodeInput.trim().length < 4) {
      setOtpError("Please enter the OTP verification code.");
      return;
    }
    setVerifyingOtp(true);
    setOtpError(null);

    try {
      const res = await api.verifyOTP(customerPhone.trim(), otpCodeInput.trim());
      if (res.verified) {
        setPhoneVerified(true);
        setOtpNotice("✓ Phone number successfully verified via OTP!");
        setSmsToast(null);

        // Auto-save verified phone to profile
        if (user && onUpdateUserProfile) {
          await onUpdateUserProfile({
            userId: user.id,
            phone: customerPhone.trim(),
            phoneVerified: true,
          });
        }
      } else {
        setOtpError(res.message || "Invalid OTP code.");
      }
    } catch (err: any) {
      setOtpError(err.message || "Failed to verify OTP.");
    } finally {
      setVerifyingOtp(false);
    }
  };

  // Copy helper
  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Apply Discount Code handler
  const handleApplyDiscount = async () => {
    if (!discountCodeInput.trim()) return;
    setValidatingCode(true);
    setDiscountError(null);

    try {
      const res = await api.validateDiscount(discountCodeInput.trim(), subtotal);
      if (res.valid && res.discountAmount !== undefined) {
        setAppliedDiscount({
          code: res.code || discountCodeInput.trim().toUpperCase(),
          discountAmount: res.discountAmount,
        });
      } else {
        setDiscountError(res.message || "Invalid discount code.");
      }
    } catch (err: any) {
      setDiscountError(err.message || "Unable to validate discount code.");
    } finally {
      setValidatingCode(false);
    }
  };

  const handleGpsCheckResult = (result: { matched: boolean; distanceKm: number; currentGps?: UserLocation }) => {
    setGpsCheck({
      matched: result.matched,
      distanceKm: result.distanceKm,
      userGps: result.currentGps,
      savedPin: locationPin,
    });
  };

  // Place Order Handler
  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!addressText.trim()) {
      setOrderError("Please enter your free-text delivery address.");
      return;
    }

    if (paymentMethod === "bank_transfer" && !bankTransactionId.trim()) {
      setOrderError("Please enter your Bank Transfer Transaction ID for admin confirmation.");
      return;
    }

    if ((paymentMethod === "jazzcash" || paymentMethod === "easypaisa") && !walletTransactionId.trim()) {
      setOrderError(`Please enter your ${paymentMethod === "jazzcash" ? "JazzCash" : "EasyPaisa"} Transaction ID (TID).`);
      return;
    }

    setSubmittingOrder(true);
    setOrderError(null);

    try {
      // Save updated address, phone, email & pin to profile if logged in
      if (user && onUpdateUserProfile) {
        await onUpdateUserProfile({
          userId: user.id,
          name: customerName,
          email: customerEmail,
          phone: customerPhone,
          phoneVerified,
          addressText,
          locationPin,
        });
      }

      const paymentDetails = (paymentMethod === "jazzcash" || paymentMethod === "easypaisa")
        ? {
            senderMobile: walletSenderMobile.trim() || customerPhone,
            transactionId: walletTransactionId.trim(),
            accountName: paymentMethod === "jazzcash" ? (storeInfo.jazzCashTitle || "JazzCash Account") : (storeInfo.easyPaisaTitle || "EasyPaisa Account"),
          }
        : paymentMethod === "bank_transfer"
        ? {
            transactionId: bankTransactionId.trim(),
            accountName: storeInfo.accountName,
          }
        : undefined;

      const orderData = {
        customerId: user?.id || "guest-" + Date.now(),
        customerName: customerName || "Customer",
        customerEmail: customerEmail || "guest@vespo.com",
        customerPhone,
        customerPhoneVerified: phoneVerified,
        items: cart.map(i => ({
          productId: i.productId,
          productTitle: i.product.title,
          price: i.product.salePrice || i.product.price,
          quantity: i.quantity,
          image: i.product.images?.[0],
        })),
        subtotal,
        deliveryFee,
        discountCode: appliedDiscount?.code,
        discountAmount,
        codCharge,
        totalAmount,
        paymentMethod,
        paymentDetails,
        bankTransactionId: paymentMethod === "bank_transfer" ? bankTransactionId.trim() : walletTransactionId.trim() || undefined,
        shippingAddressText: addressText,
        shippingPin: locationPin,
        gpsCheck,
      };

      const createdOrder = await api.createOrder(orderData);
      if (onOrderPlaced) {
        onOrderPlaced(createdOrder);
      } else if (onOrderCompleted) {
        onOrderCompleted(createdOrder);
      }
    } catch (err: any) {
      setOrderError(err.message || "Failed to place order. Please try again.");
    } finally {
      setSubmittingOrder(false);
    }
  };

  return (
    <div className="space-y-8 pb-16">
      {/* Live Carrier SMS Toast Notification */}
      {smsToast && (
        <div className="fixed top-4 right-4 z-50 max-w-sm bg-slate-900 text-white p-4 rounded-2xl shadow-2xl border border-indigo-500/50 animate-bounce">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center shrink-0">
              <Smartphone className="w-4 h-4 text-white" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[11px] text-indigo-300 font-bold">
                <span>SMS VERIFICATION DISPATCH</span>
                <span>JUST NOW</span>
              </div>
              <p className="text-xs font-semibold font-mono text-emerald-300 leading-snug">{smsToast}</p>
              <p className="text-[10px] text-slate-400">Copy or type this 6-digit code into the box below.</p>
            </div>
          </div>
        </div>
      )}

      <div className="border-b border-slate-200 pb-4">
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Checkout</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          Verify contact details via OTP, set delivery GPS location, and select manual payment option.
        </p>
      </div>

      <form onSubmit={handlePlaceOrder} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left & Middle Column: Customer Info, Address & Payment */}
        <div className="lg:col-span-2 space-y-6">
          {orderError && (
            <div className="p-4 text-xs font-bold text-rose-800 bg-rose-50 rounded-2xl border border-rose-200 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0" />
              <span>{orderError}</span>
            </div>
          )}

          {/* Section 1: Customer & Contact Info */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <span>1. Customer & Contact Info</span>
              </h2>

              <button
                type="button"
                onClick={() => setShowWhyContactInfo(!showWhyContactInfo)}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1.5 bg-indigo-50 px-3 py-1 rounded-full border border-indigo-100"
              >
                <Info className="w-3.5 h-3.5" />
                <span>Why collect Phone & Email?</span>
              </button>
            </div>

            {/* Explanation Callout Banner */}
            {showWhyContactInfo && (
              <div className="p-4 bg-gradient-to-r from-indigo-50/80 via-slate-50 to-indigo-50/50 border border-indigo-100 rounded-2xl text-xs space-y-2 text-slate-700 animate-in fade-in">
                <div className="font-extrabold text-indigo-900 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-indigo-600" />
                  <span>Why we collect and save your contact details:</span>
                </div>
                <ul className="space-y-1.5 pl-5 list-disc text-[11px] text-slate-600">
                  <li>
                    <strong className="text-slate-900 font-bold">Email Address:</strong> Used to instantly dispatch your official digital receipt, PDF invoice, and order tracking updates directly to your inbox.
                  </li>
                  <li>
                    <strong className="text-slate-900 font-bold">Mobile Phone Number:</strong> Enables real-time SMS OTP verification to secure your order and allows courier dispatch drivers to coordinate local arrival.
                  </li>
                  <li>
                    <strong className="text-slate-900 font-bold">Auto-Saved to Profile:</strong> Your updated contact info is securely saved to your account profile for fast, seamless future checkouts.
                  </li>
                </ul>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  required
                  placeholder="e.g. Alex Morgan"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Email Address (For Real Receipt) *</label>
                <input
                  type="email"
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  required
                  placeholder="alex@example.com"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium"
                />
              </div>

              {/* Mobile Phone + Real OTP Verification Section */}
              <div className="sm:col-span-2 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="block font-semibold text-slate-700">
                    Mobile Phone Number (SMS OTP Verification) *
                  </label>
                  {phoneVerified && (
                    <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-full flex items-center gap-1 border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      Phone OTP Verified
                    </span>
                  )}
                </div>

                <div className="flex gap-2">
                  <div className="relative flex-1">
                    <input
                      type="tel"
                      value={customerPhone}
                      onChange={(e) => {
                        setCustomerPhone(e.target.value);
                        if (phoneVerified) setPhoneVerified(false);
                      }}
                      required
                      placeholder="e.g. 0300-1234567 or +92 300 1234567"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                    />
                  </div>

                  {!phoneVerified ? (
                    <button
                      type="button"
                      onClick={handleSendOtp}
                      disabled={sendingOtp || !customerPhone.trim()}
                      className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-colors shrink-0 flex items-center gap-1.5 disabled:opacity-50"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>{sendingOtp ? "Sending..." : otpSent ? "Resend OTP" : "Send OTP"}</span>
                    </button>
                  ) : (
                    <div className="px-4 py-2.5 bg-emerald-50 text-emerald-700 font-bold rounded-xl border border-emerald-200 flex items-center gap-1.5 shrink-0 text-xs">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      <span>Verified</span>
                    </div>
                  )}
                </div>

                {/* OTP Code Entry Drawer */}
                {otpSent && !phoneVerified && (
                  <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-3 animate-in fade-in">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="font-bold text-xs text-indigo-300 flex items-center gap-1.5">
                        <Smartphone className="w-4 h-4 text-indigo-400" />
                        Enter 6-Digit SMS Verification Code
                      </span>
                      <span className="text-[10px] text-slate-400">Valid for 5 mins</span>
                    </div>

                    <div className="flex gap-2">
                      <input
                        type="text"
                        maxLength={6}
                        value={otpCodeInput}
                        onChange={(e) => setOtpCodeInput(e.target.value)}
                        placeholder="e.g. 482091"
                        className="flex-1 px-3.5 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono text-center tracking-widest text-base font-black focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                      <button
                        type="button"
                        onClick={handleVerifyOtp}
                        disabled={verifyingOtp || !otpCodeInput.trim()}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl transition-colors disabled:opacity-50 text-xs flex items-center gap-1"
                      >
                        {verifyingOtp ? "Verifying..." : "Verify Code"}
                      </button>
                    </div>

                    {otpNotice && <p className="text-[11px] text-emerald-400 font-bold">{otpNotice}</p>}
                    {otpError && <p className="text-[11px] text-rose-400 font-bold">{otpError}</p>}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Section 2: Address & GPS Map Pin */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-indigo-600" />
                <span>2. Delivery Address & GPS Map Pin</span>
              </h2>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Full Delivery Address (Free-Text Field) *
              </label>
              <textarea
                rows={2}
                value={addressText}
                onChange={(e) => setAddressText(e.target.value)}
                required
                placeholder="Enter complete street name, house/building number, area, city, and postal code..."
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Pinpoint Delivery Location on Map (Cross-Checked at Order Time)
              </label>
              <p className="text-[11px] text-slate-500 mb-2">
                Click map or press GPS button to lock in coordinates so the dispatch driver delivers directly to your location.
              </p>
              <MapPicker
                value={locationPin}
                onChange={(newLoc) => setLocationPin(newLoc)}
                compareWithGps={true}
                onGpsCheckResult={handleGpsCheckResult}
                height="h-64"
              />
            </div>
          </div>

          {/* Section 3: Select Payment Method (COD, JazzCash, EasyPaisa, Bank) */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-sm space-y-4">
            <h2 className="text-base font-extrabold text-slate-900">3. Select Payment Method</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              {/* Option 1: Cash on Delivery */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3 ${
                  paymentMethod === "cod"
                    ? "border-indigo-600 bg-indigo-50/50"
                    : "border-slate-200 bg-white hover:border-slate-300"
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="cod"
                  checked={paymentMethod === "cod"}
                  onChange={() => setPaymentMethod("cod")}
                  className="mt-1 text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                    <Banknote className="w-4 h-4 text-emerald-600" />
                    <span>Cash on Delivery (COD)</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Pay cash upon order arrival. Small verification fee of <strong>+{formatPrice(storeInfo.codFee || 3.5, currency)}</strong>.
                  </p>
                </div>
              </label>

              {/* Option 2: JazzCash Manual Transfer */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3 ${
                  paymentMethod === "jazzcash"
                    ? "border-red-600 bg-red-50/50"
                    : "border-slate-200 bg-white hover:border-slate-300"
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="jazzcash"
                  checked={paymentMethod === "jazzcash"}
                  onChange={() => setPaymentMethod("jazzcash")}
                  className="mt-1 text-red-600 focus:ring-red-500"
                />
                <div>
                  <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                    <Smartphone className="w-4 h-4 text-red-600" />
                    <span>JazzCash Manual Transfer</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Direct transfer via JazzCash app. Enter your Sender Number & TID below.
                  </p>
                </div>
              </label>

              {/* Option 3: EasyPaisa Manual Transfer */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3 ${
                  paymentMethod === "easypaisa"
                    ? "border-emerald-600 bg-emerald-50/50"
                    : "border-slate-200 bg-white hover:border-slate-300"
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="easypaisa"
                  checked={paymentMethod === "easypaisa"}
                  onChange={() => setPaymentMethod("easypaisa")}
                  className="mt-1 text-emerald-600 focus:ring-emerald-500"
                />
                <div>
                  <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                    <Smartphone className="w-4 h-4 text-emerald-600" />
                    <span>EasyPaisa Manual Transfer</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Direct transfer via EasyPaisa app. Enter your Sender Number & TID below.
                  </p>
                </div>
              </label>

              {/* Option 4: Manual Bank Transfer */}
              <label
                className={`p-4 rounded-2xl border-2 cursor-pointer transition-all flex items-start gap-3 ${
                  paymentMethod === "bank_transfer"
                    ? "border-indigo-600 bg-indigo-50/50"
                    : "border-slate-200 bg-white hover:border-slate-300"
                }`}
              >
                <input
                  type="radio"
                  name="paymentMethod"
                  value="bank_transfer"
                  checked={paymentMethod === "bank_transfer"}
                  onChange={() => setPaymentMethod("bank_transfer")}
                  className="mt-1 text-indigo-600 focus:ring-indigo-500"
                />
                <div>
                  <div className="flex items-center gap-2 font-bold text-sm text-slate-900">
                    <CreditCard className="w-4 h-4 text-indigo-600" />
                    <span>Manual Bank Transfer</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">
                    Transfer via IBFT bank account. Submit your transaction ID for admin verification.
                  </p>
                </div>
              </label>
            </div>

            {/* JazzCash Manual Instructions & TID Input */}
            {paymentMethod === "jazzcash" && (
              <div className="p-5 bg-gradient-to-br from-slate-900 via-slate-900 to-red-950 text-white rounded-2xl space-y-4 text-xs animate-in fade-in border border-red-500/30">
                <div className="font-bold text-red-400 border-b border-slate-800 pb-2 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-red-500" />
                    Official JazzCash Transfer Instructions
                  </span>
                  <span className="px-2 py-0.5 bg-red-500/20 text-red-300 rounded text-[10px] font-mono">JazzCash</span>
                </div>

                <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">Account Title</span>
                      <strong className="text-white text-sm">{storeInfo.jazzCashTitle || "Vespo Store (JazzCash)"}</strong>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-slate-700/50">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">JazzCash Number / Till ID</span>
                      <strong className="text-red-300 font-mono text-base">{storeInfo.jazzCashNumber || "0300-1234567"}</strong>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(storeInfo.jazzCashNumber || "0300-1234567", "jc")}
                      className="px-3 py-1.5 bg-red-600/30 hover:bg-red-600/50 text-red-200 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors border border-red-500/40"
                    >
                      {copiedKey === "jc" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === "jc" ? "Copied!" : "Copy Number"}</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block font-bold text-slate-200 mb-1">
                      Sender Mobile Number
                    </label>
                    <input
                      type="text"
                      value={walletSenderMobile}
                      onChange={(e) => setWalletSenderMobile(e.target.value)}
                      placeholder="e.g. 0300-9876543"
                      className="w-full px-3.5 py-2.5 bg-slate-800 text-white placeholder-slate-400 border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-200 mb-1">
                      JazzCash Transaction ID (TID) *
                    </label>
                    <input
                      type="text"
                      value={walletTransactionId}
                      onChange={(e) => setWalletTransactionId(e.target.value)}
                      required
                      placeholder="e.g. 1098402941"
                      className="w-full px-3.5 py-2.5 bg-slate-800 text-white placeholder-slate-400 border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* EasyPaisa Manual Instructions & TID Input */}
            {paymentMethod === "easypaisa" && (
              <div className="p-5 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 text-white rounded-2xl space-y-4 text-xs animate-in fade-in border border-emerald-500/30">
                <div className="font-bold text-emerald-400 border-b border-slate-800 pb-2 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Smartphone className="w-4 h-4 text-emerald-500" />
                    Official EasyPaisa Transfer Instructions
                  </span>
                  <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 rounded text-[10px] font-mono">EasyPaisa</span>
                </div>

                <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">Account Title</span>
                      <strong className="text-white text-sm">{storeInfo.easyPaisaTitle || "Vespo Store (EasyPaisa)"}</strong>
                    </div>
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-slate-700/50">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold block uppercase">EasyPaisa Mobile / Till Number</span>
                      <strong className="text-emerald-300 font-mono text-base">{storeInfo.easyPaisaNumber || "0345-7654321"}</strong>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy(storeInfo.easyPaisaNumber || "0345-7654321", "ep")}
                      className="px-3 py-1.5 bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 rounded-lg text-[11px] font-bold flex items-center gap-1 transition-colors border border-emerald-500/40"
                    >
                      {copiedKey === "ep" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedKey === "ep" ? "Copied!" : "Copy Number"}</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block font-bold text-slate-200 mb-1">
                      Sender Mobile Number
                    </label>
                    <input
                      type="text"
                      value={walletSenderMobile}
                      onChange={(e) => setWalletSenderMobile(e.target.value)}
                      placeholder="e.g. 0345-1122334"
                      className="w-full px-3.5 py-2.5 bg-slate-800 text-white placeholder-slate-400 border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-200 mb-1">
                      EasyPaisa Transaction ID (TID) *
                    </label>
                    <input
                      type="text"
                      value={walletTransactionId}
                      onChange={(e) => setWalletTransactionId(e.target.value)}
                      required
                      placeholder="e.g. 98201948"
                      className="w-full px-3.5 py-2.5 bg-slate-800 text-white placeholder-slate-400 border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 text-xs font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Bank Transfer Details & Transaction ID Input */}
            {paymentMethod === "bank_transfer" && (
              <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-3 text-xs animate-in fade-in">
                <div className="font-bold text-indigo-300 border-b border-slate-800 pb-2 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  <span>Store Bank Account Details</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
                  <p><strong className="text-white">Bank Name:</strong> {storeInfo.bankName || "Vespo Commercial Bank"}</p>
                  <p><strong className="text-white">Account Name:</strong> {storeInfo.accountName || "Vespo Store LLC"}</p>
                  <p><strong className="text-white">Account Number:</strong> {storeInfo.accountNumber || "9876-5432-1098"}</p>
                  <p><strong className="text-white">IBAN/Routing:</strong> {storeInfo.ibanRouting || "VESPOUS33XXXX"}</p>
                </div>

                <div className="pt-2 border-t border-slate-800">
                  <label className="block font-bold text-white mb-1">
                    Enter Your Bank Transfer Transaction ID / Reference No. *
                  </label>
                  <input
                    type="text"
                    value={bankTransactionId}
                    onChange={(e) => setBankTransactionId(e.target.value)}
                    required={paymentMethod === "bank_transfer"}
                    placeholder="e.g. TXN-98402941"
                    className="w-full px-3.5 py-2.5 bg-slate-800 text-white placeholder-slate-400 border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-xs font-mono"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Checkout Summary & Discount Code */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-md space-y-6">
            <h3 className="text-base font-extrabold text-slate-900 tracking-tight">Order Items & Summary</h3>

            {/* Item List Preview */}
            <div className="space-y-3 max-h-56 overflow-y-auto pr-1">
              {cart.map((item) => {
                const price = item.product.salePrice || item.product.price;
                return (
                  <div key={item.productId} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2.5 truncate pr-2">
                      <span className="w-5 h-5 bg-slate-100 font-bold rounded flex items-center justify-center text-[10px] text-slate-700">
                        {item.quantity}x
                      </span>
                      <span className="font-semibold text-slate-800 truncate">{item.product.title}</span>
                    </div>
                    <span className="font-bold text-slate-900">{formatPrice(price * item.quantity, currency, storeInfo.baseCurrency || "PKR")}</span>
                  </div>
                );
              })}
            </div>

            {/* Discount Code Input */}
            <div className="pt-4 border-t border-slate-100 space-y-2">
              <label className="block text-xs font-bold text-slate-700">Apply Promo / Discount Code</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g. WELCOME10"
                  value={discountCodeInput}
                  onChange={(e) => setDiscountCodeInput(e.target.value)}
                  className="flex-1 px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 uppercase font-mono"
                />
                <button
                  type="button"
                  onClick={handleApplyDiscount}
                  disabled={validatingCode}
                  className="px-3.5 py-2 text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl transition-colors disabled:opacity-50"
                >
                  {validatingCode ? "Checking..." : "Apply"}
                </button>
              </div>

              {appliedDiscount && (
                <div className="p-2.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-xl text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Tag className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Code {appliedDiscount.code} applied!</span>
                  </div>
                  <span>-{formatPrice(appliedDiscount.discountAmount, currency, storeInfo.baseCurrency || "PKR")}</span>
                </div>
              )}

              {discountError && (
                <p className="text-[11px] text-rose-600 font-semibold">{discountError}</p>
              )}
            </div>

            {/* Financial Breakdown */}
            <div className="pt-4 border-t border-slate-100 space-y-2 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Items Subtotal</span>
                <span className="font-bold text-slate-900">{formatPrice(subtotal, currency, storeInfo.baseCurrency || "PKR")}</span>
              </div>
              <div className="flex justify-between">
                <span>Shipping & Handing</span>
                <span className="font-bold text-slate-900">{formatPrice(deliveryFee, currency, storeInfo.baseCurrency || "PKR")}</span>
              </div>
              {paymentMethod === "cod" && (
                <div className="flex justify-between text-indigo-700 font-semibold">
                  <span>COD Charge</span>
                  <span>+{formatPrice(codCharge, currency, storeInfo.baseCurrency || "PKR")}</span>
                </div>
              )}
              {appliedDiscount && (
                <div className="flex justify-between text-emerald-700 font-semibold">
                  <span>Discount</span>
                  <span>-{formatPrice(discountAmount, currency, storeInfo.baseCurrency || "PKR")}</span>
                </div>
              )}
              <div className="pt-3 border-t border-slate-200 flex justify-between items-baseline">
                <span className="text-sm font-extrabold text-slate-900">Final Order Total</span>
                <span className="text-2xl font-extrabold text-slate-900">{formatPrice(totalAmount, currency, storeInfo.baseCurrency || "PKR")}</span>
              </div>
            </div>

            {/* Place Order Submit Button */}
            <button
              type="submit"
              disabled={submittingOrder}
              className="w-full py-4 px-6 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-2xl shadow-xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 text-sm"
            >
              {submittingOrder ? (
                <span>Generating Order & Receipt...</span>
              ) : (
                <>
                  <span>Confirm & Place Order</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
